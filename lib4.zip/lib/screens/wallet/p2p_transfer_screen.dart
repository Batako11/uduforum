import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';
import '/services/coin_service.dart';

class P2PTransferScreen extends StatefulWidget {
  final int userCoins; // Current user's coin balance
  const P2PTransferScreen({super.key, required this.userCoins});

  @override
  State<P2PTransferScreen> createState() => _P2PTransferScreenState();
}

class _P2PTransferScreenState extends State<P2PTransferScreen> {
  final supabase = Supabase.instance.client;
  final CoinService _coinService = CoinService(Supabase.instance.client);
  final TextEditingController _recipientController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  List<Map<String, dynamic>> _userSuggestions = [];
  bool _isLoading = false;
  String? _errorMessage;
  static const int adminFee = 2; // 2-coin fee for admin

  @override
  void dispose() {
    _recipientController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _searchUsers(String query) async {
    if (query.isEmpty) {
      setState(() => _userSuggestions = []);
      return;
    }
    try {
      final response = await supabase
          .from('users')
          .select('id, username, email')
          .or('username.ilike.%$query%,email.ilike.%$query%')
          .neq('id', supabase.auth.currentUser?.id ?? '')
          .limit(5);
      setState(() {
        _userSuggestions = List<Map<String, dynamic>>.from(response);
        _errorMessage = null;
      });
    } catch (e) {
      setState(() => _errorMessage = 'Error searching users: $e');
    }
  }

  Future<void> _confirmTransfer() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('Please login first');
      return;
    }
    final recipientInput = _recipientController.text.trim();
    final amountText = _amountController.text.trim();
    if (recipientInput.isEmpty) {
      showToast('Please enter a recipient username or email');
      return;
    }
    if (amountText.isEmpty) {
      showToast('Please enter an amount');
      return;
    }
    final amount = int.tryParse(amountText);
    if (amount == null || amount <= 0) {
      showToast('Please enter a valid amount');
      return;
    }
    if (amount + adminFee > widget.userCoins) {
      showToast(
        'Insufficient coins (Need ${amount + adminFee}, Have ${widget.userCoins})',
      );
      return;
    }

    // Verify recipient exists by username or email
    try {
      final recipient = await supabase
          .from('users')
          .select('id, username')
          .or('username.eq.$recipientInput,email.eq.$recipientInput')
          .single();
      final recipientId = recipient['id'] as String;
      final recipientUsername = recipient['username'] as String;

      // Show confirmation dialog
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text('Confirm Transfer'),
          content: Text(
            'Send $amount coins to $recipientUsername?\nA $adminFee-coin fee will be charged.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Confirm'),
            ),
          ],
        ),
      );

      if (confirmed != true) return;

      setState(() => _isLoading = true);
      try {
        // Perform transfer with fee
        final transferSuccess = await _coinService.transferBetweenUsersWithFee(
          fromUser: user.id,
          toUser: recipientId,
          amount: amount,
          adminFee: adminFee,
        );
        if (!transferSuccess) {
          showToast('Transfer failed: Insufficient coins');
          setState(() => _isLoading = false);
          return;
        }

        // Log transactions
        // LOG TRANSACTIONS — NOW 100% SAFE AND CORRECT
        await supabase.from('wallet_transactions').insert([
          // 1. Sender: debit for sent amount
          {
            'user_id': user.id,
            'type': 'coin_debit',
            'amount': amount,
            'description': 'Sent $amount coins to @$recipientUsername',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
          // 2. Sender: debit for fee
          {
            'user_id': user.id,
            'type': 'coin_debit',
            'amount': adminFee,
            'description': 'P2P transfer fee',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
          // 3. Recipient: real credit log (now allowed by policy above)
          {
            'user_id': recipientId,
            'type': 'coin_credit',
            'amount': amount,
            'description':
                'Received $amount coins from @${user.email?.split('@')[0] ?? 'user'}',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
        ]);

        // Send notifications
        await supabase.from('notifications').insert([
          {
            'user_id': user.id,
            'actor_id': user.id,
            'type': 'p2p_transfer_sent',
            'message':
                'You sent $amount coins to $recipientUsername ($adminFee-coin fee)',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
          {
            'user_id': recipientId,
            'actor_id': user.id,
            'type': 'p2p_transfer_received',
            'message':
                'You received $amount coins from ${user.email?.split('@')[0]}',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
        ]);

        showToast('✅ Transferred $amount coins to $recipientUsername!');
        _recipientController.clear();
        _amountController.clear();
        Navigator.pop(
          context,
          true,
        ); // Return to WalletScreen to refresh balance
      } catch (e) {
        showToast('Transfer failed: $e');
      } finally {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      showToast('Recipient not found');
      return;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'P2P Transfer',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.lightBlue),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          // Main scrollable content
          SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.red, fontSize: 14),
                    ),
                  ),
                // ... all your existing widgets (balance card, text fields, etc.)
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: const BorderSide(color: Color(0xFF1DA1F2)),
                  ),
                  elevation: 2,
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Your Balance',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${widget.userCoins} Coins',
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueAccent,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'A $adminFee-coin fee applies per transfer',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _recipientController,
                  decoration: InputDecoration(
                    labelText: 'Recipient Username or Email',
                    hintText: 'Enter username or email',
                    prefixIcon: const Icon(Icons.person, color: Colors.orange),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: Colors.orange.shade50,
                  ),
                  onChanged: _searchUsers,
                ),
                if (_userSuggestions.isNotEmpty)
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 150),
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: _userSuggestions.length,
                      itemBuilder: (context, index) {
                        final user = _userSuggestions[index];
                        final username = user['username'] ?? 'Unknown';
                        final email = user['email'] ?? '';
                        return ListTile(
                          title: Text(username),
                          subtitle: Text(
                            email,
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 12,
                            ),
                          ),
                          onTap: () {
                            _recipientController.text = username;
                            setState(() => _userSuggestions = []);
                          },
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 16),
                TextField(
                  controller: _amountController,
                  decoration: InputDecoration(
                    labelText: 'Amount (Coins)',
                    hintText: 'Enter amount',
                    prefixIcon: const Icon(
                      Icons.monetization_on,
                      color: Colors.orange,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: Colors.orange.shade50,
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _isLoading ? null : _confirmTransfer,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.lightBlue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    minimumSize: const Size(double.infinity, 48),
                    elevation: 4,
                    shadowColor: Colors.blueGrey.withValues(alpha: 0.3),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation(Colors.white),
                          ),
                        )
                      : const Text(
                          'Transfer Coins',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ), // Add extra padding so content isn't hidden behind banner
                const SizedBox(height: 80), // <-- Important: clears the banner
              ],
            ),
          ),

          // Fixed Banner Ad at Bottom
          if (AdManager().bannerEnabled)
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.only(top: 4),
                child: const BannerAdWidget(height: 60),
              ),
            ),
        ],
      ),
    );
  }
}
