import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/rewarded_ad_widget.dart';
import '/utils/level_utils.dart';
import 'p2p_transfer_screen.dart';
import '../../services/user_service.dart';
import '../market/marketplace_screen.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  final supabase = Supabase.instance.client;
  int xp = 0;
  int coins = 0;
  List<Map<String, dynamic>> transactions = [];
  bool loading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    debugPrint('DEBUG: Initializing WalletScreen');
    _loadWalletData();
    final user = supabase.auth.currentUser;
    if (user != null) {
      supabase
          .from('wallet_transactions')
          .stream(primaryKey: ['id'])
          .eq('user_id', user.id)
          .listen((List<Map<String, dynamic>> data) {
            if (!mounted) return;
            setState(() {
              transactions = data;
            });
          });
    }
  }

  void _watchAdForCoins() async {
    // ← ADD async here!

    await RewardedAdManager().show(
      // ← ADD await here!
      context: context,
      onReward: () async {
        final user = Supabase.instance.client.auth.currentUser;
        if (user == null) {
          showToast('Login required');
          return;
        }

        try {
          // 1. Get admin balance
          final adminData = await Supabase.instance.client
              .from('admin_balance')
              .select('id, coins')
              .single();

          final adminCoins = (adminData['coins'] as int?) ?? 0;
          if (adminCoins < 5) {
            showToast('Not enough coins in system. Try later.');
            return;
          }

          // 2. Deduct from admin
          await Supabase.instance.client
              .from('admin_balance')
              .update({'coins': adminCoins - 5})
              .eq('id', adminData['id']);

          // 3. Credit user +5 coins (FIXED: No FieldValue in Supabase!)
          final userData = await Supabase.instance.client
              .from('users')
              .select('coins')
              .eq('id', user.id)
              .single();

          final currentUserCoins = (userData['coins'] as int?) ?? 0;

          await Supabase.instance.client
              .from('users')
              .update({'coins': currentUserCoins + 5})
              .eq('id', user.id);

          // 4. Record transaction
          await Supabase.instance.client.from('wallet_transactions').insert({
            'user_id': user.id,
            'type': 'coin_credit',
            'amount': 5,
            'description': 'Watched rewarded ad',
            'created_at': DateTime.now().toIso8601String(),
          });

          // 5. Refresh UI
          await _loadWalletData();
          showToast('You earned 5 coins!');
        } catch (e) {
          debugPrint('Ad reward error: $e');
          showToast('Failed to reward coins. Try again.');
        }
      },
    );
  }

  Future<void> _loadWalletData() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      debugPrint('DEBUG: No user logged in');
      if (mounted) {
        setState(() {
          errorMessage = 'You must be logged in';
          loading = false;
        });
      }
      return;
    }

    try {
      debugPrint('DEBUG: Loading wallet data for user ID: ${user.id}');
      final userResponse = await supabase
          .from('users')
          .select('xp, coins')
          .eq('id', user.id)
          .single();

      final txResponse = await supabase
          .from('wallet_transactions')
          .select()
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(20);

      if (!mounted) return;
      setState(() {
        xp = (userResponse['xp'] as int?) ?? 0;
        coins = (userResponse['coins'] as int?) ?? 0;
        transactions = List<Map<String, dynamic>>.from(txResponse);
        loading = false;
        errorMessage = null;
      });

      // Log specific transactions for debugging
      for (final tx in transactions) {
        if (tx['type'] == 'coin_credit' &&
            tx['amount'] == 5 &&
            tx['description'] == 'Post creation reward') {
          debugPrint(
            'DEBUG: User earned +5 coins from post creation at ${tx['created_at']}',
          );
        } else if (tx['type'] == 'gift_sent') {
          debugPrint(
            'DEBUG: User sent gift at ${tx['created_at']}: ${tx['description']}',
          );
        }
      }
    } catch (e) {
      debugPrint('DEBUG: Wallet fetch error: $e');
      if (!mounted) return;
      setState(() {
        errorMessage = 'Failed to load wallet data: $e';
        loading = false;
      });
    }
  }

  Future<void> _convertXpToCoins() async {
    if (xp < 100) {
      if (mounted) showToast('You need at least 100 XP to convert.');
      return;
    }

    final user = supabase.auth.currentUser;
    if (user == null) {
      if (mounted) showToast('You must be logged in.');
      return;
    }

    final int coinsToAdd = (xp ~/ 100) * 4;
    final int xpToDeduct = (xp ~/ 100) * 100;

    setState(() => loading = true);

    try {
      debugPrint('DEBUG: Converting $xpToDeduct XP to $coinsToAdd coins');

      // Fetch admin balance
      final adminData = await supabase
          .from('admin_balance')
          .select('id, coins')
          .single();
      final adminCoins = (adminData['coins'] as int?) ?? 0;

      // Check if admin has enough coins
      if (adminCoins < coinsToAdd) {
        if (mounted) showToast('Insufficient admin coins for conversion.');
        setState(() => loading = false);
        return;
      }

      // Update admin balance
      await supabase
          .from('admin_balance')
          .update({'coins': adminCoins - coinsToAdd})
          .eq('id', adminData['id']);

      // Update user balance
      await supabase
          .from('users')
          .update({'xp': xp - xpToDeduct, 'coins': coins + coinsToAdd})
          .eq('id', user.id);

      // Record transactions
      await supabase.from('wallet_transactions').insert([
        {
          'user_id': user.id,
          'type': 'xp_debit',
          'amount': xpToDeduct,
          'description': 'XP to coin conversion',
          'created_at': DateTime.now().toIso8601String(),
        },
        {
          'user_id': user.id,
          'type': 'coin_credit',
          'amount': coinsToAdd,
          'description': 'XP to coin conversion',
          'created_at': DateTime.now().toIso8601String(),
        },
      ]);

      await _loadWalletData();
      if (!mounted) return;
      showToast('✅ Converted $xpToDeduct XP to $coinsToAdd coins!');
      Navigator.pop(context, true);
    } catch (e) {
      debugPrint('DEBUG: XP to coin conversion error: $e');
      if (mounted) showToast('Failed to convert XP: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _purchaseBlueTick() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('You must be logged in.');
      return;
    }
    if (coins < 500) {
      showToast('You need at least 500 coins to purchase a Blue Tick.');
      return;
    }
    setState(() => loading = true);
    try {
      final userData = await supabase
          .from('users')
          .select('coins, blue_tick, blue_tick_expiry')
          .eq('id', user.id)
          .single();

      if (userData['blue_tick'] == true &&
          userData['blue_tick_expiry'] != null &&
          DateTime.parse(
            userData['blue_tick_expiry'],
          ).isAfter(DateTime.now())) {
        if (mounted) showToast('You already have an active Blue Tick.');
        if (mounted) setState(() => loading = false);
        return;
      }

      final adminBalance = await supabase
          .from('admin_balance')
          .select('id, coins')
          .single();

      await supabase.rpc(
        'purchase_blue_tick',
        params: {
          'user_id': user.id,
          'user_coins': userData['coins'],
          'admin_balance_id': adminBalance['id'],
          'admin_coins': adminBalance['coins'],
        },
      );

      await supabase.from('wallet_transactions').insert({
        'user_id': user.id,
        'type': 'blue_tick_purchase',
        'amount': 500,
        'description': 'Blue Tick purchase for 30 days',
        'created_at': DateTime.now().toIso8601String(),
      });

      await _loadWalletData();
      await UserService.isUserVerified();
      if (!mounted) return;
      showToast('✅ Blue Tick purchased for 30 days!');
    } catch (e) {
      debugPrint('DEBUG: Blue Tick purchase error: $e');
      if (!mounted) return;

      if (e is PostgrestException) {
        showToast(e.message.isNotEmpty ? e.message : 'Something went wrong.');
      } else {
        showToast('An unexpected error occurred.');
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _purchaseGoldTick() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('You must be logged in.');
      return;
    }
    if (coins < 1500) {
      showToast('You need at least 1500 coins to purchase a Gold Tick.');
      return;
    }

    setState(() => loading = true);
    try {
      final userData = await supabase
          .from('users')
          .select('coins, gold_tick, gold_tick_expiry')
          .eq('id', user.id)
          .single();

      if (userData['gold_tick'] == true &&
          userData['gold_tick_expiry'] != null &&
          DateTime.parse(
            userData['gold_tick_expiry'],
          ).isAfter(DateTime.now())) {
        showToast('You already have an active Gold Tick.');
        setState(() => loading = false);
        return;
      }

      final adminBalance = await supabase
          .from('admin_balance')
          .select('id, coins')
          .single();

      // ---- ONLY THIS LINE CALLS THE RPC ----
      await supabase.rpc(
        'purchase_gold_tick',
        params: {
          'user_id': user.id,
          'user_coins': userData['coins'],
          'admin_balance_id': adminBalance['id'],
          'admin_coins': adminBalance['coins'],
        },
      );

      await _loadWalletData();
      await UserService.isUserVerified();
      showToast('Gold Tick purchased for 60 days!');
    } catch (e) {
      debugPrint('DEBUG: Gold Tick purchase error: $e');
      if (e is PostgrestException) {
        showToast(e.message.isNotEmpty ? e.message : 'Something went wrong.');
      } else {
        showToast('An unexpected error occurred.');
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final levelInfo = getLevelInfo(xp);
    final color = levelInfo['color'];
    final font = levelInfo['font'] as TextStyle;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Text(
          'My Wallet',
          style: font.copyWith(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: (font.fontSize ?? 16.0).toDouble(),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1E88E5)),
          onPressed: () {
            debugPrint('DEBUG: Navigating back from WalletScreen');
            Navigator.pop(context, true);
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.store, color: Color(0xFF1E88E5)),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MarketplaceScreen()),
              );
            },
            tooltip: 'Go to Marketplace',
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : RefreshIndicator(
              onRefresh: _loadWalletData,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (errorMessage != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Text(
                        errorMessage!,
                        style: const TextStyle(color: Colors.red, fontSize: 14),
                      ),
                    ),
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: const BorderSide(color: Color(0xFFE0E0E0)),
                    ),
                    elevation: 2,
                    color: color.withValues(alpha: 0.1),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Text(
                            'Wallet Overview',
                            style: font.copyWith(
                              fontSize: (font.fontSize ?? 18.0).toDouble(),
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _buildStat(
                                'XP',
                                '$xp',
                                Colors.deepPurple,
                                Icons.star,
                              ),
                              _buildStat(
                                'Coins',
                                '$coins',
                                Colors.amber[800]!,
                                Icons.monetization_on,
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                _buildStat(
                                  'Coin Price',
                                  '₦1',
                                  Colors.green,
                                  Icons.attach_money,
                                ),
                                const SizedBox(width: 16),
                                _buildStat(
                                  'Circulating Supply',
                                  '500,000',
                                  Colors.blue[600]!,
                                  Icons.currency_exchange,
                                ),
                                const SizedBox(width: 16),
                                _buildStat(
                                  'Max Supply',
                                  '1,000,000',
                                  Colors.blue[600]!,
                                  Icons.currency_exchange,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _convertXpToCoins,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.amber[700],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 12,
                            ),
                            elevation: 4,
                            shadowColor: Colors.amber.withValues(alpha: 0.3),
                          ),
                          icon: const Icon(Icons.monetization_on, size: 20),
                          label: const Text(
                            'Convert XP',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _watchAdForCoins, // ← Just this one line
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.purple[600],
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 12,
                            ),
                            elevation: 4,
                          ),
                          icon: const Icon(Icons.play_circle, size: 20),
                          label: Text(
                            AdManager().canWatchRewardedAd()
                                ? 'Get 5 Coins'
                                : 'Wait ${AdManager().minIntervalMinutes} min',
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            showModalBottomSheet(
                              context: context,
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(20),
                                ),
                              ),
                              builder: (_) => _buildActionDialog(context),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blueGrey[800],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 14,
                            ),
                            elevation: 4,
                            shadowColor: Colors.blueGrey.withValues(alpha: 0.3),
                          ),
                          icon: const Icon(Icons.verified_user),
                          label: const Text(
                            'Verification',
                            style: TextStyle(fontSize: 15),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    P2PTransferScreen(userCoins: coins),
                              ),
                            ).then((result) {
                              if (result == true) {
                                _loadWalletData(); // Refresh balance
                              }
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green[600],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 12,
                            ),
                            elevation: 4,
                            shadowColor: Colors.green.withValues(alpha: 0.3),
                          ),
                          icon: const Icon(Icons.send, size: 20),
                          label: const Text(
                            'Send Coin',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Recent Transactions',
                    style: font.copyWith(
                      fontSize: (font.fontSize ?? 18.0).toDouble(),
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (transactions.isEmpty)
                    Text(
                      'No transactions yet.',
                      style: TextStyle(color: Colors.grey[600]),
                    )
                  else
                    ...transactions.asMap().entries.map((entry) {
                      final int index = entry.key;
                      final Map<String, dynamic> tx = entry.value;

                      // Determine transaction display (same as before)
                      String title;
                      Color titleColor;

                      switch (tx['type']) {
                        case 'xp_credit':
                          title = 'XP +${tx['amount']}';
                          titleColor = Colors.green;
                          break;
                        case 'xp_debit':
                          title = 'XP -${tx['amount']}';
                          titleColor = Colors.red;
                          break;
                        case 'coin_credit':
                          title = 'Coins +${tx['amount']}';
                          titleColor = Colors.green;
                          break;
                        case 'coin_debit':
                          title = 'Coins -${tx['amount']}';
                          titleColor = Colors.red;
                          break;
                        case 'poll':
                          title = 'Poll -${tx['amount']} coins';
                          titleColor = Colors.red;
                          break;
                        case 'boost':
                          title = 'Boost -${tx['amount']} coins';
                          titleColor = Colors.red;
                          break;
                        case 'blue_tick_purchase':
                          title = 'Blue Tick -${tx['amount']} coins';
                          titleColor = Colors.red;
                          break;
                        case 'gold_tick_purchase':
                          title = 'Gold Tick -${tx['amount']} coins';
                          titleColor = Colors.red;
                          break;
                        case 'p2p_transfer_sent':
                          title = 'P2P Sent -${tx['amount']} coins';
                          titleColor = Colors.red;
                          break;
                        case 'p2p_transfer_received':
                          title = 'P2P Received +${tx['amount']} coins';
                          titleColor = Colors.green;
                          break;
                        default:
                          title = 'Unknown ${tx['amount']}';
                          titleColor = Colors.grey;
                      }

                      // Check if we should show a banner AFTER this transaction
                      final bool showBannerAfter = AdManager()
                          .shouldShowWalletBanner(index);

                      return Column(
                        children: [
                          // Transaction Card
                          Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: const BorderSide(color: Color(0xFFE0E0E0)),
                            ),
                            elevation: 2,
                            color: Colors.white,
                            child: ListTile(
                              title: Text(
                                title,
                                style: TextStyle(
                                  color: titleColor,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              subtitle: Text(
                                '${tx['description'] ?? 'Transaction'} • ${DateTime.parse(tx['created_at']).toLocal().toString().substring(0, 16)}',
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),

                          // Banner Ad (only if enabled and at correct frequency)
                          if (showBannerAfter)
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 12),
                              child: BannerAdWidget(height: 60),
                            ),
                        ],
                      );
                    }),
                ],
              ),
            ),
    );
  }

  Widget _buildActionDialog(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Choose Action',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          const SizedBox(height: 20),
          ListTile(
            leading: const Icon(Icons.verified, color: Colors.blue),
            title: const Text('Buy Blue Tick (500 coins)'),
            onTap: () {
              Navigator.pop(context);
              _purchaseBlueTick();
            },
          ),
          ListTile(
            leading: const Icon(Icons.verified, color: Colors.amber),
            title: const Text('Buy Gold Tick (1500 coins)'),
            onTap: () {
              Navigator.pop(context);
              _purchaseGoldTick();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildStat(String label, String value, Color color, IconData icon) {
    return Column(
      children: [
        CircleAvatar(
          radius: 24,
          backgroundColor: color.withValues(alpha: 0.15),
          child: Icon(icon, color: color, size: 24),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 14, color: Colors.grey[700])),
      ],
    );
  }
}
