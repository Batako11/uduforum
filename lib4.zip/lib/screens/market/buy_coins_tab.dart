import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class BuyCoinsTab extends StatefulWidget {
  const BuyCoinsTab({super.key});

  @override
  State<BuyCoinsTab> createState() => _BuyCoinsTabState();
}

class _BuyCoinsTabState extends State<BuyCoinsTab> {
  final supabase = Supabase.instance.client;
  final TextEditingController _amountController = TextEditingController();
  bool _isSubmitting = false;
  String? _errorMessage;

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _submitPurchaseRequest() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('Please login first');
      return;
    }
    final amountText = _amountController.text.trim();
    if (amountText.isEmpty) {
      showToast('Please enter an amount');
      return;
    }
    final amount = int.tryParse(amountText);
    if (amount == null || amount <= 0) {
      showToast('Please enter a valid amount');
      return;
    }

    setState(() {
      _isSubmitting = true;
      _errorMessage = null;
    });
    try {
      await supabase.from('coin_purchase_requests').insert({
        'user_id': user.id,
        'amount': amount,
        'status': 'pending',
      });
      showToast('Purchase request submitted! Await admin confirmation.');
      _amountController.clear();
    } catch (e) {
      setState(() => _errorMessage = 'Failed to submit request: $e');
    } finally {
      setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_errorMessage != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Text(
                  _errorMessage!,
                  style: const TextStyle(
                    color: Colors.red,
                    fontSize: 14,
                    fontFamily: 'Roboto',
                  ),
                ),
              ),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(color: Color(0xFFE0E0E0)),
              ),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Buy Coins',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                        fontFamily: 'Roboto',
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Pay to: 9037509571, opay, Umar mohammed (Admin)\n1 coin = ₦1',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                        fontFamily: 'Roboto',
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _amountController,
                      decoration: InputDecoration(
                        labelText: 'Amount (Coins)',
                        hintText: 'Enter coins to buy',
                        prefixIcon: const Icon(
                          Icons.monetization_on,
                          color: Colors.orange,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: Colors.orange.shade50,
                      ),
                      keyboardType: TextInputType.number,
                      style: const TextStyle(fontFamily: 'Roboto'),
                      onChanged: (value) {
                        setState(
                          () {},
                        ); // Just trigger rebuild — no parsing needed here
                      },
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Cost: ₦${_amountController.text.isEmpty ? 0 : (int.tryParse(_amountController.text) ?? 0)}',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.amber,
                        fontFamily: 'Roboto',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isSubmitting ? null : _submitPurchaseRequest,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                minimumSize: const Size(double.infinity, 48),
                elevation: 4,
                shadowColor: Colors.orange.withValues(alpha: 0.3),
              ),
              child: _isSubmitting
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation(Colors.white),
                      ),
                    )
                  : const Text(
                      'Confirm Payment',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Roboto',
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
