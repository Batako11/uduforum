import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'telco_screen.dart';
import 'gift_card_gifting_screen.dart';
import 'buy_coins_tab.dart';

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});

  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen>
    with SingleTickerProviderStateMixin {
  final supabase = Supabase.instance.client;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 3, // Updated to 3 tabs: Telco, Gift Cards, Buy Coins
      vsync: this,
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Marketplace'),
        backgroundColor: Colors.white,
        elevation: 0.5,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.orange,
          labelColor: Colors.orange,
          unselectedLabelColor: Colors.black,
          tabs: const [
            Tab(icon: Icon(Icons.phone_android), text: 'Telco'),
            Tab(icon: Icon(Icons.card_giftcard), text: 'Gift Cards'),
            Tab(icon: Icon(Icons.monetization_on), text: 'Buy Coins'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [TelcoScreen(), GiftCardGiftingScreen(), BuyCoinsTab()],
      ),
    );
  }
}
