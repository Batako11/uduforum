import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '/services/coin_service.dart';

class GiftCardGiftingScreen extends StatefulWidget {
  const GiftCardGiftingScreen({super.key});

  @override
  State<GiftCardGiftingScreen> createState() => _GiftCardGiftingScreenState();
}

class _GiftCardGiftingScreenState extends State<GiftCardGiftingScreen> {
  final supabase = Supabase.instance.client;
  final CoinService _coinService = CoinService(Supabase.instance.client);
  String? _currentUserId;
  int? _userCoins;
  final TextEditingController _recipientController = TextEditingController();
  String? _recipientId;
  final List<Map<String, dynamic>> _giftCards = [
    {
      'label': 'Amazon ₦1000 Gift Card',
      'coins': 1000,
      'category': 'gift_cards',
      'validity': '1 year',
      'code': 'AMZN-1000',
    },
    {
      'label': 'Google Play ₦2000 Gift Card',
      'coins': 2000,
      'category': 'gift_cards',
      'validity': '1 year',
      'code': 'GPLAY-2000',
    },
    {
      'label': 'Amazon ₦5000 Gift Card',
      'coins': 5000,
      'category': 'gift_cards',
      'validity': '1 year',
      'code': 'AMZN-5000',
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadCurrentUser();
  }

  @override
  void dispose() {
    _recipientController.dispose();
    super.dispose();
  }

  Future<void> _loadCurrentUser() async {
    final user = supabase.auth.currentUser;
    setState(() => _currentUserId = user?.id);
    if (_currentUserId != null) await _fetchUserCoins();
  }

  Future<void> _fetchUserCoins() async {
    if (_currentUserId != null) {
      final coins = await _coinService.getUserCoins(_currentUserId!);
      setState(() => _userCoins = coins);
    }
  }

  Future<void> _validateRecipient(String username) async {
    try {
      final response = await supabase
          .from('users')
          .select('id')
          .eq('username', username)
          .maybeSingle();
      if (response == null) {
        showToast('Recipient not found');
        setState(() => _recipientId = null);
      } else {
        setState(() => _recipientId = response['id'] as String);
      }
    } catch (e) {
      showToast('Error finding recipient: $e');
      setState(() => _recipientId = null);
    }
  }

  Future<void> _showGiftCardDetails(Map<String, dynamic> card) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(card['label']),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Cost: ${card['coins']} coins'),
            Text('Validity: ${card['validity']}'),
            Text('Code: ${card['code']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Future<void> _sendGiftCard(Map<String, dynamic> card) async {
    if (_currentUserId == null) {
      showToast('Please login first');
      return;
    }
    if (_recipientId == null) {
      showToast('Please enter a valid recipient username');
      return;
    }
    if (_currentUserId == _recipientId) {
      showToast('Cannot send gift to yourself');
      return;
    }
    if (_userCoins == null || _userCoins! < card['coins']) {
      showToast('Insufficient coins (Need ${card['coins']}, Have $_userCoins)');
      return;
    }
    try {
      final price = card['coins'] as int;
      if (await _coinService.transferBetweenUsers(
        fromUser: _currentUserId!,
        toUser: _recipientId!,
        amount: price,
      )) {
        await supabase.from('gift_card_transactions').insert({
          'sender_id': _currentUserId,
          'recipient_id': _recipientId,
          'card_name': card['label'],
          'price': price,
          'code': card['code'],
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });

        await supabase.from('wallet_transactions').insert([
          {
            'user_id': _currentUserId,
            'type': 'coin_debit',
            'amount': price,
            'description': 'Sent ${card['label']} to $_recipientId',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
          {
            'user_id': _recipientId,
            'type': 'coin_credit',
            'amount': price,
            'description': 'Received ${card['label']} from $_currentUserId',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
        ]);

        await supabase.from('notifications').insert([
          {
            'user_id': _currentUserId,
            'actor_id': _currentUserId,
            'type': 'gift_card_sent',
            'message': 'You sent ${card['label']} to $_recipientId',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
          {
            'user_id': _recipientId,
            'actor_id': _currentUserId,
            'type': 'gift_card_received',
            'message':
                'You received ${card['label']} (Code: ${card['code']}) from $_currentUserId',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          },
        ]);

        await _fetchUserCoins();
        showToast('Gift card sent: ${card['code']} 🎉');
        _recipientController.clear();
        setState(() => _recipientId = null);
      } else {
        showToast('Transaction failed (insufficient coins) 💸');
      }
    } catch (e) {
      showToast('Error sending gift card: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gift Card Gifting'),
        backgroundColor: Colors.white,
        elevation: 0.5,
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _recipientController,
              decoration: const InputDecoration(
                labelText: 'Recipient Username',
                border: OutlineInputBorder(),
                hintText: 'Enter recipient username',
              ),
              onChanged: _validateRecipient,
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: _giftCards
                  .map(
                    (c) => Card(
                      child: ListTile(
                        title: Text(c['label']),
                        subtitle: Text('Cost: ${c['coins']} coins'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.info_outline),
                              onPressed: () => _showGiftCardDetails(c),
                            ),
                            ElevatedButton(
                              onPressed: _recipientId == null
                                  ? null
                                  : () => _sendGiftCard(c),
                              child: const Text('Send'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}
