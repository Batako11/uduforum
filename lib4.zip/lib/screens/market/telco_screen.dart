import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import '/services/coin_service.dart';
import 'dart:convert';

class TelcoScreen extends StatefulWidget {
  const TelcoScreen({super.key});

  @override
  State<TelcoScreen> createState() => _TelcoScreenState();
}

class _TelcoScreenState extends State<TelcoScreen> {
  final supabase = Supabase.instance.client;
  final CoinService _coinService = CoinService(Supabase.instance.client);
  String? _detectedNetwork = 'MTN';
  String _selectedProductType = 'airtime';
  final TextEditingController _numberController = TextEditingController();
  Map<String, List<Map<String, dynamic>>> _plans = {};
  String? _currentUserId;
  int? _userCoins;
  bool _isLoading = false;

  // TODO: Replace with your Telco API key when obtained
  static const String _telcoApiKey = 'YOUR_TELCO_API_KEY_HERE';
  // TODO: Replace with the actual Telco API endpoint (e.g., VTpass, Reloadly)
  static const String _telcoApiUrl =
      'https://api.telcoprovider.com/v1/purchase';

  @override
  void initState() {
    super.initState();
    _loadCurrentUser();
    _initPlans();
    _fetchUserCoins();
  }

  @override
  void dispose() {
    _numberController.dispose();
    super.dispose();
  }

  Future<void> _loadCurrentUser() async {
    final user = supabase.auth.currentUser;
    setState(() => _currentUserId = user?.id);
    if (_currentUserId != null) await _fetchUserCoins();
  }

  Future<void> _fetchUserCoins() async {
    if (_currentUserId != null) {
      final coins = await _coinService.getUserCoins(_currentUserId!);
      setState(() => _userCoins = coins);
    }
  }

  void _initPlans() {
    _plans = {
      'MTN': [
        {
          'label': '₦100 Airtime',
          'coins': 100,
          'type': 'airtime',
          'validity': '1 day',
          'bonus': 'None',
          'api_code': 'MTN_AIR_100',
        },
        {
          'label': '₦200 Airtime',
          'coins': 200,
          'type': 'airtime',
          'validity': '1 day',
          'bonus': 'None',
          'api_code': 'MTN_AIR_200',
        },
        {
          'label': '₦500 Airtime',
          'coins': 500,
          'type': 'airtime',
          'validity': '3 days',
          'bonus': '10% extra',
          'api_code': 'MTN_AIR_500',
        },
        {
          'label': '₦1000 Airtime',
          'coins': 1000,
          'type': 'airtime',
          'validity': '7 days',
          'bonus': '20% extra',
          'api_code': 'MTN_AIR_1000',
        },
        {
          'label': '1GB Data',
          'coins': 400,
          'type': 'data',
          'validity': '30 days',
          'bonus': 'None',
          'api_code': 'MTN_DATA_1GB',
        },
        {
          'label': '2GB Data',
          'coins': 800,
          'type': 'data',
          'validity': '30 days',
          'bonus': '100MB bonus',
          'api_code': 'MTN_DATA_2GB',
        },
        {
          'label': '5GB Data',
          'coins': 1600,
          'type': 'data',
          'validity': '30 days',
          'bonus': '500MB bonus',
          'api_code': 'MTN_DATA_5GB',
        },
        {
          'label': '10GB Data',
          'coins': 3000,
          'type': 'data',
          'validity': '60 days',
          'bonus': '1GB bonus',
          'api_code': 'MTN_DATA_10GB',
        },
      ],
      'Airtel': [
        {
          'label': '₦100 Airtime',
          'coins': 100,
          'type': 'airtime',
          'validity': '1 day',
          'bonus': 'None',
          'api_code': 'AIRTEL_AIR_100',
        },
        {
          'label': '₦200 Airtime',
          'coins': 200,
          'type': 'airtime',
          'validity': '1 day',
          'bonus': 'None',
          'api_code': 'AIRTEL_AIR_200',
        },
        {
          'label': '₦500 Airtime',
          'coins': 500,
          'type': 'airtime',
          'validity': '3 days',
          'bonus': '10% extra',
          'api_code': 'AIRTEL_AIR_500',
        },
        {
          'label': '₦1000 Airtime',
          'coins': 1000,
          'type': 'airtime',
          'validity': '7 days',
          'bonus': '20% extra',
          'api_code': 'AIRTEL_AIR_1000',
        },
        {
          'label': '1GB Data',
          'coins': 350,
          'type': 'data',
          'validity': '30 days',
          'bonus': 'None',
          'api_code': 'AIRTEL_DATA_1GB',
        },
        {
          'label': '2GB Data',
          'coins': 700,
          'type': 'data',
          'validity': '30 days',
          'bonus': '100MB bonus',
          'api_code': 'AIRTEL_DATA_2GB',
        },
        {
          'label': '5GB Data',
          'coins': 1500,
          'type': 'data',
          'validity': '30 days',
          'bonus': '500MB bonus',
          'api_code': 'AIRTEL_DATA_5GB',
        },
        {
          'label': '10GB Data',
          'coins': 2800,
          'type': 'data',
          'validity': '60 days',
          'bonus': '1GB bonus',
          'api_code': 'AIRTEL_DATA_10GB',
        },
      ],
      'Glo': [
        {
          'label': '₦200 Airtime',
          'coins': 200,
          'type': 'airtime',
          'validity': '1 day',
          'bonus': 'None',
          'api_code': 'GLO_AIR_200',
        },
        {
          'label': '₦500 Airtime',
          'coins': 500,
          'type': 'airtime',
          'validity': '3 days',
          'bonus': '10% extra',
          'api_code': 'GLO_AIR_500',
        },
        {
          'label': '₦1000 Airtime',
          'coins': 1000,
          'type': 'airtime',
          'validity': '7 days',
          'bonus': '20% extra',
          'api_code': 'GLO_AIR_1000',
        },
        {
          'label': '1GB Data',
          'coins': 300,
          'type': 'data',
          'validity': '30 days',
          'bonus': 'None',
          'api_code': 'GLO_DATA_1GB',
        },
        {
          'label': '2.5GB Data',
          'coins': 700,
          'type': 'data',
          'validity': '30 days',
          'bonus': '200MB bonus',
          'api_code': 'GLO_DATA_2.5GB',
        },
        {
          'label': '5GB Data',
          'coins': 1400,
          'type': 'data',
          'validity': '30 days',
          'bonus': '500MB bonus',
          'api_code': 'GLO_DATA_5GB',
        },
        {
          'label': '10GB Data',
          'coins': 2600,
          'type': 'data',
          'validity': '60 days',
          'bonus': '1GB bonus',
          'api_code': 'GLO_DATA_10GB',
        },
      ],
      '9mobile': [
        {
          'label': '₦200 Airtime',
          'coins': 200,
          'type': 'airtime',
          'validity': '1 day',
          'bonus': 'None',
          'api_code': '9MOBILE_AIR_200',
        },
        {
          'label': '₦500 Airtime',
          'coins': 500,
          'type': 'airtime',
          'validity': '3 days',
          'bonus': '10% extra',
          'api_code': '9MOBILE_AIR_500',
        },
        {
          'label': '₦1000 Airtime',
          'coins': 1000,
          'type': 'airtime',
          'validity': '7 days',
          'bonus': '20% extra',
          'api_code': '9MOBILE_AIR_1000',
        },
        {
          'label': '1.5GB Data',
          'coins': 500,
          'type': 'data',
          'validity': '30 days',
          'bonus': 'None',
          'api_code': '9MOBILE_DATA_1.5GB',
        },
        {
          'label': '4.5GB Data',
          'coins': 1200,
          'type': 'data',
          'validity': '30 days',
          'bonus': '400MB bonus',
          'api_code': '9MOBILE_DATA_4.5GB',
        },
        {
          'label': '10GB Data',
          'coins': 2500,
          'type': 'data',
          'validity': '60 days',
          'bonus': '1GB bonus',
          'api_code': '9MOBILE_DATA_10GB',
        },
        {
          'label': '15GB Data',
          'coins': 3500,
          'type': 'data',
          'validity': '90 days',
          'bonus': '2GB bonus',
          'api_code': '9MOBILE_DATA_15GB',
        },
      ],
    };
  }

  String? detectNetworkFromNumber(String phone) {
    final s = phone.replaceAll(RegExp(r'\s+'), '');
    if (s.length != 11) return null;
    if (s.startsWith('0803') || s.startsWith('0703')) return 'MTN';
    if (s.startsWith('0802') || s.startsWith('0701')) return 'Airtel';
    if (s.startsWith('0805') || s.startsWith('0705')) return 'Glo';
    if (s.startsWith('0809') || s.startsWith('0818')) return '9mobile';
    return null;
  }

  Future<void> _showPlanDetails(Map<String, dynamic> plan) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          plan['label'],
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Cost: ${plan['coins']} coins',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8),
            Text(
              'Validity: ${plan['validity']}',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8),
            Text(
              'Bonus: ${plan['bonus']}',
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Colors.orange)),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmPurchase(Map<String, dynamic> plan) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Confirm Purchase'),
        content: Text(
          'Purchase ${plan['label']} for ${_numberController.text} using ${plan['coins']} coins?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      setState(() => _isLoading = true);
      await _buyTelcoPlan(plan);
      setState(() => _isLoading = false);
    }
  }

  Future<void> _buyTelcoPlan(Map<String, dynamic> plan) async {
    if (_currentUserId == null) {
      showToast('Please login first');
      return;
    }
    final phone = _numberController.text.replaceAll(RegExp(r'\s+'), '');
    if (phone.isEmpty) {
      showToast('Please enter a phone number');
      return;
    }
    if (phone.length != 11) {
      showToast('Phone number must be 11 digits');
      return;
    }
    if (_userCoins == null || _userCoins! < plan['coins']) {
      showToast('Insufficient coins (Need ${plan['coins']}, Have $_userCoins)');
      return;
    }

    // Declare price outside try block to ensure it's available in catch
    final price = plan['coins'] as int;

    try {
      // Step 1: Deduct coins and credit admin
      if (!await _coinService.spendCoinsToAdmin(
        userId: _currentUserId!,
        amount: price,
      )) {
        showToast('Transaction failed (insufficient user coins) 💸');
        return;
      }

      // Step 2: Call Telco API
      final response = await http.post(
        Uri.parse(_telcoApiUrl),
        headers: {
          'Authorization': 'Bearer $_telcoApiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'network': _detectedNetwork,
          'phone_number': phone,
          'plan_code': plan['api_code'],
          'amount': plan['type'] == 'airtime'
              ? plan['label'].split(' ')[0].replaceAll('₦', '')
              : null,
        }),
      );

      if (response.statusCode == 200) {
        // Step 3: Log transaction
        await supabase.from('telecom_transactions').insert({
          'user_id': _currentUserId,
          'plan_name': plan['label'],
          'price': price,
          'phone_number': phone,
          'api_response': jsonDecode(response.body),
        });

        await supabase.from('wallet_transactions').insert({
          'user_id': _currentUserId,
          'type': 'coin_debit',
          'amount': price,
          'description': 'Purchased ${plan['label']} for $phone',
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });

        await supabase.from('notifications').insert({
          'user_id': _currentUserId,
          'actor_id': _currentUserId,
          'type': 'telecom_purchase',
          'message': 'Purchased ${plan['label']} for $phone',
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });

        await _fetchUserCoins();
        showToast('Plan purchased successfully for $phone 🎉');
        _numberController.clear();
      } else {
        // Rollback coin transaction if API fails
        await _coinService.transferBetweenUsers(
          fromUser: CoinService.adminUid,
          toUser: _currentUserId!,
          amount: price,
        );
        showToast('Purchase failed: ${response.body}');
      }
    } catch (e) {
      // Rollback on error
      await _coinService.transferBetweenUsers(
        fromUser: CoinService.adminUid,
        toUser: _currentUserId!,
        amount: price,
      );
      showToast('Error buying plan: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    _detectedNetwork =
        _detectedNetwork ?? detectNetworkFromNumber(_numberController.text);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.orange.shade50, Colors.white],
        ),
      ),
      child: Column(
        children: [
          // Header with Coin Balance
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.orange.shade100,
              borderRadius: const BorderRadius.vertical(
                bottom: Radius.circular(16),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Buy Airtime & Data',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '$_userCoins Coins',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Phone Number Input
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _numberController,
              decoration: InputDecoration(
                labelText: 'Phone Number',
                hintText: '0803 XXX XXXX',
                prefixIcon: const Icon(Icons.phone, color: Colors.orange),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.white,
                suffixIcon: _detectedNetwork != null
                    ? Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset(
                          'assets/images/networks/${_detectedNetwork!.toLowerCase()}.png',
                          width: 32,
                          height: 32,
                        ),
                      )
                    : null,
              ),
              keyboardType: TextInputType.phone,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(11),
              ],
              onChanged: (value) => setState(() {
                _detectedNetwork = detectNetworkFromNumber(value);
              }),
            ),
          ),
          const SizedBox(height: 16),
          // Network Selection Grid
          SizedBox(
            height: 120,
            child: GridView.count(
              crossAxisCount: 4,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 1,
              children: _plans.keys.map((net) {
                return GestureDetector(
                  onTap: () => setState(() => _detectedNetwork = net),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _detectedNetwork == net
                            ? Colors.orange
                            : Colors.grey.shade300,
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          'assets/images/networks/${net.toLowerCase()}.png',
                          width: 40,
                          height: 40,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          net,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: _detectedNetwork == net
                                ? FontWeight.bold
                                : FontWeight.normal,
                            color: _detectedNetwork == net
                                ? Colors.orange
                                : Colors.black87,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 16),
          // Airtime/Data Toggle
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildTypeButton('Airtime', Icons.phone),
                const SizedBox(width: 12),
                _buildTypeButton('Data', Icons.wifi),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Plans List
          Expanded(
            child: _detectedNetwork == null
                ? const Center(
                    child: Text(
                      'Enter a valid phone number or select a network',
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _plans[_detectedNetwork]!
                        .where((p) => p['type'] == _selectedProductType)
                        .length,
                    itemBuilder: (context, index) {
                      final plan = _plans[_detectedNetwork]!
                          .where((p) => p['type'] == _selectedProductType)
                          .toList()[index];
                      return AnimatedOpacity(
                        opacity: _isLoading ? 0.5 : 1.0,
                        duration: const Duration(milliseconds: 300),
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 8,
                            ),
                            title: Text(
                              plan['label'],
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                Text('Cost: ${plan['coins']} coins'),
                                Text('Validity: ${plan['validity']}'),
                                Text('Bonus: ${plan['bonus']}'),
                              ],
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(
                                    Icons.info_outline,
                                    color: Colors.orange,
                                  ),
                                  onPressed: () => _showPlanDetails(plan),
                                ),
                                ElevatedButton(
                                  onPressed: _isLoading
                                      ? null
                                      : () => _confirmPurchase(plan),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.orange,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 8,
                                    ),
                                  ),
                                  child: _isLoading
                                      ? const SizedBox(
                                          width: 20,
                                          height: 20,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            valueColor: AlwaysStoppedAnimation(
                                              Colors.white,
                                            ),
                                          ),
                                        )
                                      : const Text(
                                          'Buy',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildTypeButton(String type, IconData icon) {
    final isSelected = _selectedProductType == type.toLowerCase();
    return GestureDetector(
      onTap: () => setState(() => _selectedProductType = type.toLowerCase()),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.orange : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? Colors.orange : Colors.grey.shade300,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.white : Colors.orange,
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(
              type,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.black87,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
