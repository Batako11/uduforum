import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';

class BannedScreen extends StatefulWidget {
  final String? reason;
  final DateTime? expiresAt;

  const BannedScreen({super.key, this.reason, this.expiresAt});

  @override
  State<BannedScreen> createState() => _BannedScreenState();
}

class _BannedScreenState extends State<BannedScreen> {
  final _appealController = TextEditingController();
  bool _isSubmitting = false;
  bool _hasAppealed = false;

  @override
  void initState() {
    super.initState();
    _checkExistingAppeal();
  }

  Future<void> _checkExistingAppeal() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final response = await Supabase.instance.client
          .from('ban_appeals')
          .select()
          .eq('user_id', userId)
          .maybeSingle();

      if (response != null) {
        if (mounted) {
          setState(() => _hasAppealed = true);
        }
      }
    } catch (e) {
      debugPrint('Error checking appeal: $e');
    }
  }

  Future<void> _submitAppeal() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null || _appealController.text.trim().isEmpty) return;

    setState(() => _isSubmitting = true);

    try {
      // Insert appeal
      await Supabase.instance.client.from('ban_appeals').insert({
        'user_id': userId,
        'reason': widget.reason,
        'appeal_text': _appealController.text.trim(),
        'status': 'pending',
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });

      // Notify admins
      final admins = await Supabase.instance.client.rpc(
        'get_admins',
        params: {
          'roles': ['admin', 'superadmin', 'moderator'],
        },
      );

      for (final admin in admins) {
        await Supabase.instance.client.from('notifications').insert({
          'user_id': admin['id'],
          'actor_id': userId,
          'type': 'appeal',
          'message': 'New ban appeal submitted',
          'created_at': DateTime.now().toUtc().toIso8601String(),
          'is_read': false,
        });
      }

      if (mounted) {
        setState(() {
          _hasAppealed = true;
          _isSubmitting = false;
        });
        showToast('Appeal submitted! We\'ll review it soon.');
      }
    } catch (e) {
      debugPrint('Error submitting appeal: $e');
      if (mounted) {
        setState(() => _isSubmitting = false);
        showToast('Failed to submit appeal. Try again.');
      }
    }
  }

  @override
  void dispose() {
    _appealController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.block, color: Colors.red, size: 80),
              const SizedBox(height: 20),
              const Text(
                "Account Banned",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              if (widget.reason != null)
                Text(
                  "Reason: ${widget.reason}",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                  textAlign: TextAlign.center,
                ),
              if (widget.expiresAt != null) ...[
                const SizedBox(height: 8),
                Text(
                  "Ban expires on: ${widget.expiresAt!.toLocal().toString().split(' ')[0]}",
                  style: const TextStyle(fontSize: 15, color: Colors.grey),
                ),
              ] else
                const Text(
                  "This ban is currently under review.",
                  style: TextStyle(fontSize: 15, color: Colors.grey),
                ),
              const SizedBox(height: 32),

              // APPEAL SECTION
              if (!_hasAppealed) ...[
                TextField(
                  controller: _appealController,
                  maxLines: 4,
                  decoration: InputDecoration(
                    hintText: 'Explain why your ban should be lifted...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    filled: true,
                    fillColor: Colors.grey[50],
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: _isSubmitting
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.send),
                    label: Text(
                      _isSubmitting ? 'Submitting...' : 'Submit Appeal',
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _isSubmitting ? null : _submitAppeal,
                  ),
                ),
                const SizedBox(height: 16),
              ] else
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.green[50],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.green),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.check_circle, color: Colors.green),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Appeal submitted. Awaiting review.',
                          style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 24),

              // LOGOUT BUTTON
              ElevatedButton.icon(
                icon: const Icon(Icons.logout),
                label: const Text("Logout"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () async {
                  await Supabase.instance.client.auth.signOut();
                  if (context.mounted) {
                    Navigator.pushReplacementNamed(context, '/login');
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
