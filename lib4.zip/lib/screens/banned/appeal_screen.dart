import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import 'package:timeago/timeago.dart' as timeago;

class AppealScreen extends StatefulWidget {
  final Map<String, dynamic> appeal;

  const AppealScreen({super.key, required this.appeal});

  @override
  State<AppealScreen> createState() => _AppealScreenState();
}

class _AppealScreenState extends State<AppealScreen> {
  final supabase = Supabase.instance.client;
  bool _isProcessing = false;

  Future<void> _respondToAppeal(String status) async {
    if (_isProcessing) return;
    setState(() => _isProcessing = true);

    try {
      // 1. Update the appeal status (and responded_at)
      await supabase
          .from('ban_appeals')
          .update({
            'status': status,
            'responded_at': DateTime.now().toUtc().toIso8601String(),
          })
          .eq('id', widget.appeal['id']);

      // 2. If approved → unban the user
      if (status == 'approved') {
        await supabase
            .from('users')
            .update({'banned': false})
            .eq('id', widget.appeal['user_id']);
        showToast('User unbanned!');
      } else {
        showToast('Appeal rejected.');
      }

      // 3. **Delete the appeal row** – it will disappear from the list instantly
      await supabase.from('ban_appeals').delete().eq('id', widget.appeal['id']);

      // 4. Pop back to the admin screen (the list will be refreshed automatically)
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      debugPrint('Error responding to appeal: $e');
      showToast('Failed to process appeal.');
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.appeal['users'] as Map<String, dynamic>?;
    final createdAt =
        DateTime.tryParse(widget.appeal['created_at'] ?? '') ?? DateTime.now();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ban Appeal'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.5,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // User Info
            Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundImage: user?['profile_image_url'] != null
                      ? NetworkImage(user!['profile_image_url'])
                            as ImageProvider
                      : const AssetImage('assets/default_avatar.png')
                            as ImageProvider,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user?['username'] ?? 'Unknown User',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      Text(
                        '@${user?['handle'] ?? 'unknown'} • ${timeago.format(createdAt)}',
                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Ban Reason
            if (widget.appeal['reason'] != null) ...[
              const Text(
                'Ban Reason:',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.red[200]!),
                ),
                child: Text(
                  widget.appeal['reason'],
                  style: TextStyle(color: Colors.red[800]),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Appeal Text
            const Text(
              'Appeal Message:',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue[200]!),
              ),
              child: Text(
                widget.appeal['appeal_text'] ?? 'No message provided.',
                style: const TextStyle(fontSize: 15),
              ),
            ),
            const SizedBox(height: 32),

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isProcessing
                        ? null
                        : () => _respondToAppeal('approved'),
                    icon: _isProcessing
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.check, size: 20),
                    label: const Text('Approve & Unban'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isProcessing
                        ? null
                        : () => _respondToAppeal('rejected'),
                    icon: const Icon(Icons.close, size: 20),
                    label: const Text('Reject'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.redAccent,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
