import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:confetti/confetti.dart';
import 'package:image_picker/image_picker.dart';
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/user_service.dart';
import '/models/post_model.dart';

class PostCreateScreen extends StatefulWidget {
  final Post? post;
  final String? trendingHashtag;
  final String? initialChannelId;

  const PostCreateScreen({
    super.key,
    this.post,
    this.trendingHashtag,
    this.initialChannelId,
  });

  @override
  State<PostCreateScreen> createState() => _PostCreateScreenState();
}

class _PostCreateScreenState extends State<PostCreateScreen> {
  final TextEditingController _textController = TextEditingController();
  final List<TextEditingController> _pollOptionControllers = [];
  File? _selectedImage;
  String? _existingImageUrl;
  bool _isLoading = false;
  String? _selectedChannelId;
  List<Map<String, dynamic>> _availableChannels = [];
  bool _loadingChannels = true;
  bool _isPollEnabled = false;
  int _pollOptionsCount = 2;
  bool _canUseFreePoll = false;
  bool _canEditImage = true;
  Timer? _tagDebounce;
  bool _hasCheckedImagePermission = false;
  late final ConfettiController confettiController;
  List<String> _taggedUserIds = [];
  final Map<String, List<String>> _tags = {
    'hashtags': [],
    'cashtags': [],
    'customtags': [],
  };
  bool _isValidCustomTag(String tag) {
    // Custom tags: 3–15 chars, letters/numbers/_, no real user
    final validPattern = RegExp(r'^[a-zA-Z0-9_]{3,15}$');
    return validPattern.hasMatch(tag);
  }

  @override
  void initState() {
    super.initState();
    confettiController = ConfettiController(
      duration: const Duration(seconds: 3),
    );
    _textController.addListener(() {
      _tagDebounce?.cancel();
      _tagDebounce = Timer(const Duration(milliseconds: 300), () {
        if (mounted) _detectTags();
      });
    });
    _fetchUserChannels();
    _selectedChannelId = widget.initialChannelId;
    // ← BONUS: Load existing post data
    // ──────────────────────────────────────────────────────
    if (widget.post != null) {
      _textController.text = widget.post!.content;
      _existingImageUrl = widget.post!.imageUrl;

      // Poll handling …
      if (widget.post!.pollOptions != null &&
          widget.post!.pollOptions!.isNotEmpty) {
        _isPollEnabled = true;
        _pollOptionsCount = widget.post!.pollOptions!.length;
        for (var option in widget.post!.pollOptions!) {
          _pollOptionControllers.add(TextEditingController(text: option));
        }
      }
      _taggedUserIds = List<String>.from(
        (widget.post!.taggedUserIds ?? []).map((id) => id.toString()),
      ).where((id) => id.isNotEmpty).toList();

      // Tags — safe conversions to List<String>
      _tags['hashtags'] = (widget.post!.tags?['hashtags'] is List)
          ? List<String>.from(widget.post!.tags!['hashtags'] as List)
          : <String>[];
      _tags['cashtags'] = (widget.post!.tags?['cashtags'] is List)
          ? List<String>.from(widget.post!.tags!['cashtags'] as List)
          : <String>[];
      _tags['customtags'] = (widget.post!.tags?['customtags'] is List)
          ? List<String>.from(widget.post!.tags!['customtags'] as List)
          : <String>[];

      // ← BONUS: Decide if the current user may edit the image
      _checkImageEditPermission();
    }
    _checkFreePollEligibility();
    _detectTags();
  }

  @override
  void dispose() {
    confettiController.dispose();
    _textController.dispose();
    _tagDebounce?.cancel();
    for (var controller in _pollOptionControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _checkImageEditPermission() async {
    if (_hasCheckedImagePermission) return;
    _hasCheckedImagePermission = true;

    final canPost = await _isUserVerified(); // true for Blue/Gold

    if (mounted) {
      setState(() {
        // If the post already has an image, non-verified users cannot touch it
        _canEditImage = canPost || _existingImageUrl == null;
      });
    }
  }

  Future<bool> _isUserVerified() => UserService.isUserVerified();

  Future<void> _checkFreePollEligibility() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      final lastPoll = await Supabase.instance.client
          .from('posts')
          .select('created_at')
          .eq('user_id', user.id)
          .not('poll_options', 'is', null)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      setState(() {
        _canUseFreePoll =
            lastPoll == null ||
            DateTime.now()
                    .difference(DateTime.parse(lastPoll['created_at']))
                    .inHours >=
                24;
      });
    } catch (e) {
      debugPrint('Error checking free poll eligibility: $e');
      showToast('Error checking poll eligibility');
      setState(() => _canUseFreePoll = false);
    }
  }

  Future<void> _fetchUserChannels() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      // Fetch channels the user owns or follows
      final response = await Supabase.instance.client
          .from('channels')
          .select('id, name')
          .or('creator_id.eq.${user.id},followers.cs."{${user.id}}"')
          .order('created_at', ascending: false);

      if (mounted) {
        setState(() {
          _availableChannels = List<Map<String, dynamic>>.from(response);
          _loadingChannels = false;
        });
      }
    } catch (e) {
      debugPrint('Error fetching user channels: $e');
      if (mounted) setState(() => _loadingChannels = false);
    }
  }

  Future<void> _pickImage() async {
    final canPost = await _isUserVerified();
    if (!canPost) {
      showToast('Only Blue or Gold Verified users can post images!');
      return;
    }

    // ← BONUS: If we are editing a protected image, block picking a new one
    if (!_canEditImage) {
      showToast('You cannot change the image on this post.');
      return;
    }

    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _selectedImage = File(picked.path);
        _existingImageUrl = null;
      });
    }
  }

  void _updatePollOptions(int count) {
    setState(() {
      _pollOptionsCount = count.clamp(2, 6);
      while (_pollOptionControllers.length < _pollOptionsCount) {
        _pollOptionControllers.add(TextEditingController());
      }
      while (_pollOptionControllers.length > _pollOptionsCount) {
        _pollOptionControllers.removeLast().dispose();
      }
    });
  }

  void _detectTags() {
    final text = _textController.text;

    // Regex patterns
    final userTagExp = RegExp(r'@([a-zA-Z0-9_]+)');
    final hashTagExp = RegExp(r'#([a-zA-Z0-9_]+)');
    final cashTagExp = RegExp(r'\$([A-Z]{1,6})\b'); // $BTC, $AAPL
    final customTagExp = RegExp(
      r'@([a-zA-Z0-9_]+)',
    ); // @news, @funny (same as user, but we’ll filter)

    setState(() {
      _taggedUserIds = [];
      _tags['hashtags'] = [];
      _tags['cashtags'] = [];
      _tags['customtags'] = [];

      // 1. User Tags (@username) → validate & store ID
      for (var match in userTagExp.allMatches(text)) {
        final username = match.group(1)!;
        if (!_isValidCustomTag(username)) {
          _validateAndAddUserTag(username); // Real user
        }
      }

      // 2. Hashtags
      for (var match in hashTagExp.allMatches(text)) {
        final hashtag = match.group(1)!;
        if (!_tags['hashtags']!.contains(hashtag)) {
          _tags['hashtags']!.add(hashtag);
        }
      }

      // 3. Cashtags ($BTC)
      for (var match in cashTagExp.allMatches(text)) {
        final cashtag = match.group(1)!;
        if (!_tags['cashtags']!.contains(cashtag)) {
          _tags['cashtags']!.add(cashtag);
        }
      }

      // 4. Custom Tags (@group) → only if NOT a real user
      for (var match in customTagExp.allMatches(text)) {
        final tag = match.group(1)!;
        if (_isValidCustomTag(tag)) {
          final lowerTag = tag.toLowerCase();
          if (!_tags['customtags']!.contains(lowerTag)) {
            _tags['customtags']!.add(lowerTag);
          }
        }
      }
    });
  }

  Future<void> _validateAndAddUserTag(String username) async {
    try {
      final response = await Supabase.instance.client
          .from('users')
          .select('id')
          .eq('username', username)
          .maybeSingle();

      if (response != null) {
        final String userId = response['id'] as String;
        if (!_taggedUserIds.contains(userId)) {
          setState(() {
            _taggedUserIds.add(userId);
          });
        }
      }
    } catch (e) {
      debugPrint('Error validating user tag @$username: $e');
    }
  }

  void _addTrendingHashtag() {
    if (widget.trendingHashtag != null &&
        !_tags['hashtags']!.contains(widget.trendingHashtag)) {
      setState(() {
        _tags['hashtags']!.add(widget.trendingHashtag!);
        final text = _textController.text.trim();
        _textController.text = text.isEmpty
            ? '#${widget.trendingHashtag}'
            : '$text #${widget.trendingHashtag}';
      });
    }
  }

  Future<void> _submitPost() async {
    if (_textController.text.trim().isEmpty) {
      showToast('Please enter some content');
      return;
    }

    if (_isPollEnabled &&
        _pollOptionControllers.any((c) => c.text.trim().isEmpty)) {
      showToast('Please fill all poll options');
      return;
    }

    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('You must be logged in to post');
      return;
    }

    setState(() => _isLoading = true);
    String? imageUrl = _existingImageUrl;
    List<String>? pollOptions;

    try {
      // Image upload logic (unchanged — your code is perfect)
      if (_selectedImage != null) {
        final canPost = await _isUserVerified();
        if (!canPost) {
          showToast('Only Blue or Gold Verified users can post images!');
          setState(() {
            _isLoading = false;
            _selectedImage = null;
          });
          return;
        }
        if (!_canEditImage) {
          showToast('You cannot change the image on this post.');
          setState(() {
            _isLoading = false;
            _selectedImage = null;
          });
          return;
        }

        final fileExt = _selectedImage!.path.split('.').last.toLowerCase();
        final timestamp = DateTime.now().millisecondsSinceEpoch;
        final fileName = '${user.id}_$timestamp.$fileExt';
        final filePath = 'posts/${user.id}/$fileName';

        final bytes = await _selectedImage!.readAsBytes();

        await supabase.storage
            .from('post-images')
            .uploadBinary(
              filePath,
              bytes,
              fileOptions: FileOptions(
                cacheControl: '3600',
                upsert: false,
                contentType: 'image/$fileExt',
              ),
            );

        imageUrl = supabase.storage.from('post-images').getPublicUrl(filePath);

        if (widget.post?.imageUrl != null) {
          final oldPath = widget.post!.imageUrl!.split('/post-images/').last;
          try {
            await supabase.storage.from('post-images').remove([oldPath]);
          } catch (e) {
            debugPrint('Failed to delete old image: $e');
          }
        }
      }

      // Poll cost logic (unchanged — perfect)
      if (_isPollEnabled) {
        pollOptions = _pollOptionControllers.map((c) => c.text.trim()).toList();
        final coinCost = _pollOptionsCount == 2 && _canUseFreePoll
            ? 0
            : _pollOptionsCount == 3
            ? 50
            : _pollOptionsCount == 4
            ? 70
            : 100;

        if (coinCost > 0) {
          final userData = await supabase
              .from('users')
              .select('coins')
              .eq('id', user.id)
              .single();
          final currentCoins = (userData['coins'] as int?) ?? 0;
          if (currentCoins < coinCost) {
            showToast('Insufficient coins for poll (need $coinCost coins)');
            setState(() => _isLoading = false);
            return;
          }

          await supabase
              .from('users')
              .update({'coins': currentCoins - coinCost})
              .eq('id', user.id);

          final adminData = await supabase
              .from('admin_balance')
              .select('id, coins')
              .limit(1)
              .single();
          final adminCoins = (adminData['coins'] as int?) ?? 0;

          await supabase
              .from('admin_balance')
              .update({
                'coins': adminCoins + coinCost,
                'updated_at': DateTime.now().toIso8601String(),
              })
              .eq('id', adminData['id']);

          await supabase.from('wallet_transactions').insert({
            'user_id': user.id,
            'type': 'poll',
            'amount': coinCost,
            'description': 'Created poll with $_pollOptionsCount options',
            'created_at': DateTime.now().toIso8601String(),
          });
        }
      }

      // Ensure tags is a valid JSONB object
      final tagsData = {
        'hashtags': _tags['hashtags'] ?? [],
        'cashtags': _tags['cashtags'] ?? [],
        'customtags': _tags['customtags'] ?? [],
      };

      if (_selectedChannelId != null &&
          !_availableChannels.any((c) => c['id'] == _selectedChannelId)) {
        showToast('You can only post in channels you follow or own.');
        setState(() => _isLoading = false);
        return;
      }

      if (widget.post != null) {
        await supabase
            .from('posts')
            .update({
              'content': _textController.text.trim(),
              'channel_id': _selectedChannelId,
              'image_url': imageUrl,
              'poll_options': pollOptions,
              'tagged_user_ids': _taggedUserIds.isEmpty ? null : _taggedUserIds,
              'tags':
                  (tagsData['hashtags']!.isNotEmpty ||
                      tagsData['cashtags']!.isNotEmpty ||
                      tagsData['customtags']!.isNotEmpty)
                  ? tagsData
                  : null,
              'updated_at': DateTime.now().toIso8601String(),
            })
            .eq('id', widget.post!.id);
        showToast('Post updated successfully!');
      } else {
        final response = await supabase
            .from('posts')
            .insert({
              'user_id': user.id,
              'channel_id': _selectedChannelId,
              'content': _textController.text.trim(),
              'image_url': imageUrl,
              'poll_options': pollOptions,
              'tagged_user_ids': _taggedUserIds.isEmpty ? null : _taggedUserIds,
              'tags':
                  (tagsData['hashtags']!.isNotEmpty ||
                      tagsData['cashtags']!.isNotEmpty ||
                      tagsData['customtags']!.isNotEmpty)
                  ? tagsData
                  : null,
              'created_at': DateTime.now().toIso8601String(),
            })
            .select()
            .single();

        final newPostId = response['id'];

        // DAILY 5-POST COIN LIMIT — FINAL VERSION
        int todayPostCount = 0;
        try {
          final countRes = await supabase
              .from('posts')
              .select('id')
              .eq('user_id', user.id)
              .gte(
                'created_at',
                DateTime(
                  DateTime.now().year,
                  DateTime.now().month,
                  DateTime.now().day,
                ),
              )
              .count();
          todayPostCount = countRes.count;
        } catch (e) {
          debugPrint('Failed to count today\'s posts: $e');
        }

        final bool canEarnCoins =
            todayPostCount <= 5; // First 5 posts = +5 coins
        final int coinReward = canEarnCoins ? 5 : 0;
        final int xpReward = 15;

        final adminData = await supabase
            .from('admin_balance')
            .select('id, coins')
            .limit(1)
            .single();
        final adminCoins = (adminData['coins'] as int?) ?? 0;

        if (canEarnCoins && adminCoins >= 5) {
          await supabase
              .from('admin_balance')
              .update({
                'coins': adminCoins - 5,
                'updated_at': DateTime.now().toIso8601String(),
              })
              .eq('id', adminData['id']);
        }

        final userData = await supabase
            .from('users')
            .select('coins, xp')
            .eq('id', user.id)
            .single();
        final currentCoins = (userData['coins'] as int?) ?? 0;
        final currentXp = (userData['xp'] as int?) ?? 0;

        await supabase
            .from('users')
            .update({
              'coins': currentCoins + coinReward,
              'xp': currentXp + xpReward,
            })
            .eq('id', user.id);

        final List<Map<String, dynamic>> transactions = [
          {
            'user_id': user.id,
            'type': 'xp_credit',
            'amount': xpReward,
            'description': 'Post creation reward',
            'created_at': DateTime.now().toIso8601String(),
          },
        ];
        if (coinReward > 0) {
          transactions.add({
            'user_id': user.id,
            'type': 'coin_credit',
            'amount': coinReward,
            'description': 'Post creation reward',
            'created_at': DateTime.now().toIso8601String(),
          });
        }
        await supabase.from('wallet_transactions').insert(transactions);

        showToast(
          canEarnCoins
              ? 'Post created! +15 XP and +5 coins'
              : 'Post created! +15 XP (daily coin limit reached)',
        );

        // Notifications (unchanged)
        for (final taggedUserId in _taggedUserIds) {
          if (taggedUserId != user.id) {
            await supabase.from('notifications').insert({
              'user_id': taggedUserId,
              'actor_id': user.id,
              'type': 'tag',
              'post_id': newPostId,
              'created_at': DateTime.now().toIso8601String(),
            });
          }
        }

        final followers = await supabase
            .from('follows')
            .select('follower_id')
            .eq('followed_id', user.id);
        for (final follower in followers) {
          await supabase.from('notifications').insert({
            'user_id': follower['follower_id'],
            'actor_id': user.id,
            'type': 'post',
            'post_id': newPostId,
            'created_at': DateTime.now().toIso8601String(),
          });
        }
      }

      if (mounted) Navigator.pop(context);
    } catch (e) {
      debugPrint(
        "${widget.post != null ? 'Update' : 'Create'} post failed: $e",
      );
      showToast('Failed to ${widget.post != null ? 'update' : 'create'} post');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return OKToast(
      child: Stack(
        children: [
          Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
              backgroundColor: Colors.white,
              elevation: 0.5,
              title: Text(
                widget.post != null ? 'Edit Post' : 'Create Post',
                style: const TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Roboto',
                ),
              ),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black87),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            body: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.trendingHashtag != null) ...[
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Row(
                        children: [
                          Flexible(
                            child: Text(
                              '🔥 Trending: #${widget.trendingHashtag} (+20 XP)',
                              style: const TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Roboto',
                              ),
                              overflow:
                                  TextOverflow.ellipsis, // Truncate long text
                              maxLines: 1,
                            ),
                          ),
                          const SizedBox(width: 8),
                          TextButton(
                            onPressed: _addTrendingHashtag,
                            style: TextButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              backgroundColor: Colors.green.withValues(
                                alpha: 0.1,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'Add',
                              style: TextStyle(
                                color: Colors.green,
                                fontFamily: 'Roboto',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  if (_loadingChannels)
                    const Center(
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  else if (_availableChannels.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: DropdownButtonFormField<String>(
                        initialValue: _selectedChannelId,
                        decoration: InputDecoration(
                          labelText: 'Post to Channel (optional)',
                          labelStyle: const TextStyle(fontFamily: 'Roboto'),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        items: _availableChannels
                            .map(
                              (channel) => DropdownMenuItem<String>(
                                value: channel['id'],
                                child: Text(
                                  channel['name'],
                                  style: const TextStyle(fontFamily: 'Roboto'),
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: (value) {
                          setState(() => _selectedChannelId = value);
                        },
                      ),
                    ),
                  TextField(
                    controller: _textController,
                    decoration: InputDecoration(
                      hintText: 'What\'s on your mind? Use @username or #topic',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Color(0xFF1DA1F2)),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 10,
                      ),
                      hintStyle: const TextStyle(
                        color: Color(0xFF6B7280),
                        fontFamily: 'Roboto',
                      ),
                    ),
                    maxLines: 4,
                    style: const TextStyle(fontFamily: 'Roboto'),
                  ),
                  const SizedBox(height: 12),
                  if (_taggedUserIds.isNotEmpty ||
                      _tags['hashtags']!.isNotEmpty ||
                      _tags['cashtags']!.isNotEmpty ||
                      _tags['customtags']!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [
                          // 1. User Tags (@username)
                          ..._taggedUserIds.map((userId) {
                            return FutureBuilder<Map?>(
                              future: Supabase.instance.client
                                  .from('users')
                                  .select('username')
                                  .eq('id', userId)
                                  .maybeSingle(),
                              builder: (context, snapshot) {
                                final username =
                                    snapshot.data?['username'] as String?;
                                if (username == null) {
                                  return const Chip(label: Text('@...'));
                                }
                                return Chip(
                                  label: Text(
                                    '@$username',
                                    style: const TextStyle(
                                      color: Colors.blue,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  backgroundColor: Colors.blue[50],
                                  avatar: const Icon(
                                    Icons.person,
                                    size: 16,
                                    color: Colors.blue,
                                  ),
                                );
                              },
                            );
                          }),

                          // 2. Hashtags
                          ..._tags['hashtags']!.map((hashtag) {
                            final isTrending =
                                hashtag == widget.trendingHashtag;
                            return Chip(
                              label: Text(
                                '#$hashtag',
                                style: TextStyle(
                                  color: isTrending
                                      ? Colors.green
                                      : Colors.blue,
                                  fontWeight: isTrending
                                      ? FontWeight.bold
                                      : FontWeight.bold,
                                ),
                              ),
                              backgroundColor: isTrending
                                  ? Colors.green[50]
                                  : Colors.blue[50],
                            );
                          }),
                          // 3. $BTC (cashtag = blue)
                          ..._tags['cashtags']!.map((cashtag) {
                            return Chip(
                              label: Text(
                                '\$$cashtag',
                                style: const TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              backgroundColor: Colors.blue[50],
                              avatar: const Icon(
                                Icons.attach_money,
                                size: 16,
                                color: Colors.blue,
                              ),
                            );
                          }),
                          // 4. @group (custom tag = blue)
                          ..._tags['customtags']!.map((tag) {
                            return Chip(
                              label: Text(
                                '@$tag',
                                style: const TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              backgroundColor: Colors.blue[50],
                              avatar: const Icon(
                                Icons.group,
                                size: 16,
                                color: Colors.blue,
                              ),
                            );
                          }),
                        ],
                      ),
                    ),
                  SwitchListTile(
                    title: const Text(
                      'Add Poll',
                      style: TextStyle(fontFamily: 'Roboto'),
                    ),
                    activeThumbColor: Colors.blue,
                    value: _isPollEnabled,
                    onChanged: (value) {
                      setState(() {
                        _isPollEnabled = value;
                        if (value && _pollOptionControllers.isEmpty) {
                          _updatePollOptions(2);
                        }
                      });
                    },
                  ),
                  if (_isPollEnabled) ...[
                    const SizedBox(height: 12),
                    Text(
                      _canUseFreePoll && _pollOptionsCount == 2
                          ? 'Free 2-option poll available'
                          : 'Poll Cost: ${_pollOptionsCount == 2
                                ? "Free (if first in 24hrs)"
                                : _pollOptionsCount == 3
                                ? "50 coins"
                                : _pollOptionsCount == 4
                                ? "70 coins"
                                : "100 coins"}',
                      style: const TextStyle(
                        color: Color(0xFF6B7280),
                        fontFamily: 'Roboto',
                      ),
                    ),
                    const SizedBox(height: 8),
                    DropdownButton<int>(
                      value: _pollOptionsCount,
                      items: const [
                        DropdownMenuItem(
                          value: 2,
                          child: Text(
                            '2 Options',
                            style: TextStyle(fontFamily: 'Roboto'),
                          ),
                        ),
                        DropdownMenuItem(
                          value: 3,
                          child: Text(
                            '3 Options',
                            style: TextStyle(fontFamily: 'Roboto'),
                          ),
                        ),
                        DropdownMenuItem(
                          value: 4,
                          child: Text(
                            '4 Options',
                            style: TextStyle(fontFamily: 'Roboto'),
                          ),
                        ),
                        DropdownMenuItem(
                          value: 6,
                          child: Text(
                            '6 Options',
                            style: TextStyle(fontFamily: 'Roboto'),
                          ),
                        ),
                      ],
                      onChanged: (value) =>
                          value != null ? _updatePollOptions(value) : null,
                      style: const TextStyle(
                        color: Colors.black87,
                        fontFamily: 'Roboto',
                      ),
                      dropdownColor: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    const SizedBox(height: 12),
                    ...List.generate(_pollOptionControllers.length, (index) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: TextField(
                          controller: _pollOptionControllers[index],
                          decoration: InputDecoration(
                            hintText: 'Option ${index + 1}',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(
                                color: Color(0xFFE5E7EB),
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(
                                color: Color(0xFFE5E7EB),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(
                                color: Color(0xFF1DA1F2),
                              ),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 10,
                            ),
                            hintStyle: const TextStyle(
                              color: Color(0xFF6B7280),
                              fontFamily: 'Roboto',
                            ),
                          ),
                          style: const TextStyle(fontFamily: 'Roboto'),
                        ),
                      );
                    }),
                  ],
                  const SizedBox(height: 12),
                  if (_selectedImage != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        _selectedImage!,
                        height: 150,
                        fit: BoxFit.cover,
                      ),
                    )
                  else if (_existingImageUrl != null)
                    Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            _existingImageUrl!,
                            height: 150,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                Container(
                                  height: 150,
                                  color: const Color(0xFFECEFF1),
                                  child: const Center(
                                    child: Text(
                                      'Failed to load image',
                                      style: TextStyle(
                                        color: Colors.black54,
                                        fontFamily: 'Roboto',
                                      ),
                                    ),
                                  ),
                                ),
                          ),
                        ),
                        // ← Lock icon for non-verified users
                        if (!_canEditImage)
                          const Positioned(
                            top: 8,
                            right: 8,
                            child: Icon(
                              Icons.lock,
                              color: Colors.white,
                              size: 20,
                              shadows: [
                                Shadow(
                                  blurRadius: 6,
                                  color: Colors.black54,
                                  offset: Offset(0, 1),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  // ← BONUS: Image picker button – now respects edit permission
                  FutureBuilder<bool>(
                    future: _isUserVerified(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: CircularProgressIndicator(strokeWidth: 2),
                        );
                      }
                      final canPostImage = snapshot.data ?? false;

                      // Show the button only when:
                      // 1. No image selected yet AND
                      // 2. No existing image OR user is allowed to edit it
                      final showPicker =
                          _selectedImage == null &&
                          (_existingImageUrl == null || _canEditImage);

                      return Column(
                        children: [
                          if (showPicker)
                            TextButton.icon(
                              onPressed: canPostImage ? _pickImage : null,
                              icon: Icon(
                                canPostImage ? Icons.image : Icons.lock,
                                color: canPostImage
                                    ? const Color(0xFF1DA1F2)
                                    : Colors.grey,
                              ),
                              label: Text(
                                canPostImage
                                    ? 'Add Image'
                                    : 'Image Locked (Blue/Gold Only)',
                                style: TextStyle(
                                  color: canPostImage
                                      ? const Color(0xFF1DA1F2)
                                      : Colors.grey,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                            ),
                          // ──────────────────────────────────────────────────────
                          // ← BONUS: Remove image button – shown only when user may edit
                          // ──────────────────────────────────────────────────────
                          if (_existingImageUrl != null && _canEditImage)
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: TextButton.icon(
                                onPressed: () {
                                  setState(() {
                                    _existingImageUrl = null; // Clear preview
                                    _selectedImage = null; // Clear any new pick
                                  });
                                },
                                icon: const Icon(
                                  Icons.delete_outline,
                                  color: Colors.red,
                                ),
                                label: const Text(
                                  'Remove Image',
                                  style: TextStyle(
                                    color: Colors.red,
                                    fontFamily: 'Roboto',
                                  ),
                                ),
                              ),
                            ),

                          // Inform non-verified users why they can't change the image
                          if (!canPostImage &&
                              _existingImageUrl != null &&
                              !_canEditImage)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                'Image locked – upgrade to Blue/Gold to edit',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[600],
                                ),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  _isLoading
                      ? const CircularProgressIndicator(strokeWidth: 2)
                      : ElevatedButton(
                          onPressed: _submitPost,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1DA1F2),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 12,
                            ),
                          ),
                          child: Text(
                            widget.post != null ? 'Update' : 'Post',
                            style: const TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
