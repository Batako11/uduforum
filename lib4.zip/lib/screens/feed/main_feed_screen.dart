import 'dart:async';
import 'package:flutter/material.dart';
// timeago removed — not used in this file after carousel replacement
import 'package:oktoast/oktoast.dart';
import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:share_plus/share_plus.dart' as share_plus;
import 'package:hive_flutter/hive_flutter.dart';
import '../../services/sync_service.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../../services/ad_manager.dart';
import '../../services/image_cache_service.dart';
import '../widgets/native_ad_widget.dart';
import '/auth/login_screen.dart';
import '/models/post_model.dart';
import '../profile/profile_screen.dart';
import '../comment/comment_screen.dart';
import '../profile/other_user_profile_screen.dart';
import '../admin/admin_screen.dart';
import '../dept/notice_create_screen.dart';
import '../gpt/trinity_chat_screen.dart';
import '../dept/department_selection_screen.dart';
import '../notice/notifications_screen.dart';
import '../admin/admins_screen.dart';
import 'post_card.dart';
import 'post_create_screen.dart';
import '../widgets/post_skeleton.dart';
import '../channel/my_channels_screen.dart';
import '../channel/discover_channels_screen.dart';
import '../channel/channel_feed_screen.dart';

// ──────────────────────── GLOBAL POST CACHE ────────────────────────
final Map<String, Post> _postCache = {};
final Set<String> _fetchingPosts = {};

class MainFeedScreen extends StatefulWidget {
  final int newNoticeCount;
  final VoidCallback onNoticesViewed;

  const MainFeedScreen({
    super.key,
    this.newNoticeCount = 0,
    required this.onNoticesViewed,
  });

  @override
  State<MainFeedScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainFeedScreen>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  List<Post> _boostedPosts = [];
  List<Post> _trendingPosts = [];
  bool _loadingBoosted = true;
  bool _loadingTrending = true;
  String? _userRole;
  String? _profileImageUrl;
  String? _username;
  int _newNotificationCount = 0;
  String? _currentTrendingHashtag;
  RealtimeChannel? _notificationSubscription;
  RealtimeChannel? _postsSubscription;
  late PageController _carouselController;
  Timer? _latestRefreshTimer;
  Timer? _trendingRefreshTimer;
  Timer? _boostRotateTimer;
  int _topBoostIndex = 0;
  late TabController _tabController;
  late ScrollController _nestedScrollController;
  late ScrollController _latestTabScrollController;
  final int _pageSize = 20;
  bool _isLoadingMore = false;
  bool _hasMoreLatest = true;
  final List<Post> _latestPosts = [];
  late RealtimeChannel _newPostSubscription;
  final List<Post> _pendingNewPosts = [];
  bool _showNewPostsBanner = false;
  bool _isRefreshing = false;
  Post? _lastCursor;
  bool _isFetching = false;
  bool _isOffline = false;
  // Connectivity + metrics
  late StreamSubscription<dynamic> _connectivitySub;
  int _networkFetches = 0;
  int _totalFetchTimeMs = 0;
  int _cacheLoads = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _tabController = TabController(length: 2, vsync: this);
    _nestedScrollController = ScrollController();
    _latestTabScrollController = ScrollController();
    _fetchUserData();

    // 1) Load persisted posts from Hive (fast path)
    try {
      final box = Hive.box('post_cache');
      if (box.isNotEmpty) {
        final List<Post> cached = [];
        for (final v in box.values) {
          try {
            if (v is Post) {
              cached.add(v);
            } else if (v is Map)
              cached.add(Post.fromMap(Map<String, dynamic>.from(v)));
            else if (v is String)
              cached.add(Post.fromMap(json.decode(v) as Map<String, dynamic>));
          } catch (_) {}
        }
        if (cached.isNotEmpty) {
          cached.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          for (final p in cached) {
            _postCache[p.id] = p;
          }
          setState(() {
            _latestPosts.clear();
            _latestPosts.addAll(cached);
            _cacheLoads += cached.length;
            _isOffline =
                true; // initially assume offline until network confirms
          });
        }
      }
    } catch (e) {
      debugPrint('Error loading cached posts: $e');
    }

    // 2) Then attempt a network refresh (will clear offline flag on success)
    _fetchLatestPage(reset: true).then((_) {
      // Pre-cache avatars from first page
      final urls = _latestPosts.map((p) => p.profileImageUrl).toList();
      if (urls.isNotEmpty) ImageCacheService().precacheImages(urls, context);
    });

    // 3) Subscribe to connectivity changes to auto-retry when online
    bool isNone(dynamic r) {
      if (r is ConnectivityResult) return r == ConnectivityResult.none;
      if (r is List) return r.contains(ConnectivityResult.none);
      return false;
    }

    _connectivitySub = Connectivity().onConnectivityChanged.listen((res) {
      final nowOffline = isNone(res);
      if (mounted) {
        setState(() => _isOffline = nowOffline);
      }
      if (!nowOffline) {
        // If we regained connectivity, trigger a refresh and prune/sync
        SyncService().pruneOldPosts();
        _fetchLatestPage(reset: true);
      }
    });
    _fetchBoostedPosts();
    _fetchTrendingPosts();
    _fetchTrendingHashtag();
    _fetchNotificationCount();
    _subscribeToNotifications();
    _latestTabScrollController.addListener(() {
      if (!_hasMoreLatest || _isLoadingMore) return;
      final max = _latestTabScrollController.position.maxScrollExtent;
      final current = _latestTabScrollController.offset;
      if (current >= max * 0.9) {
        _fetchLatestPage();
      }
    });
    _subscribeToPosts();
    // Remove .subscribe() — it's not needed
    _newPostSubscription = Supabase.instance.client
        .channel('new_posts')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'posts',
          callback: (payload) => _handleNewPost(payload),
        );
    _carouselController = PageController(viewportFraction: 0.85);
    _startAutoRefresh();
  }

  void _startBoostRotation() {
    // Cancel any existing timer
    _boostRotateTimer?.cancel();
    _topBoostIndex = 0;

    if (_boostedPosts.length > 1) {
      _boostRotateTimer = Timer.periodic(const Duration(seconds: 7), (_) {
        if (!mounted) return;
        setState(() {
          _topBoostIndex = (_topBoostIndex + 1) % _boostedPosts.length;
        });
      });
    }
  }

  void _startAutoRefresh() {
    _latestRefreshTimer = Timer.periodic(const Duration(minutes: 25), (_) {
      _fetchLatestPage(reset: true);
      _fetchBoostedPosts();
    });
    _trendingRefreshTimer = Timer.periodic(const Duration(minutes: 25), (_) {
      _fetchTrendingPosts();
      _fetchTrendingHashtag();
    });
  }

  Future<T?> _retry<T>(Future<T> Function() fn, {int retries = 2}) async {
    for (int attempt = 0; attempt <= retries; attempt++) {
      try {
        return await fn();
      } catch (e) {
        if (attempt == retries) {
          _showLikeError('Network error. Please try again.');
          return null;
        }
        await Future.delayed(const Duration(seconds: 1));
      }
    }
    return null;
  }

  Future<void> _fetchLatestPage({bool reset = false}) async {
    if (_isFetching) return;
    _isFetching = true;

    if (reset) {
      _lastCursor = null;
      _hasMoreLatest = true;
      // Keep existing posts visible while we fetch fresh data.
      // Do not clear `_latestPosts` here — replace the list only after
      // a successful network response below so the UI doesn't go blank
      // when transitioning from offline -> online.
    }

    setState(() => _isLoadingMore = true);

    // Track network fetch time
    final sw = Stopwatch()..start();
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;

      final query = Supabase.instance.client.from('posts').select('''
            id,
            user_id,
            content,
            image_url,
            created_at,
            poll_options,
            is_boosted,
            boost_expires_at,
            tagged_user_ids,
            tags,
            channel_id,
            channels(name, profile_image_url),
            users!inner(username, handle, level, profile_image_url, blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry),
            likes!post_id(count),
            comments!post_id(count),
            reposts!post_id(count),
            liked_by_me:likes!post_id(user_id),
            reposted_by_me:reposts!post_id(user_id),
            poll_votes!post_id(option_index, user_id),
            trending_posts!left(is_trending)
          ''');

      if (_lastCursor == null) {
        query
            .order('created_at', ascending: false)
            .order('id', ascending: false)
            .limit(_pageSize);
      } else {
        final cursorTime = _lastCursor!.createdAt.toIso8601String();
        final cursorId = _lastCursor!.id;
        query
            .or(
              'created_at.lt.$cursorTime,and(created_at.eq.$cursorTime,id.lt.$cursorId)',
            )
            .order('created_at', ascending: false)
            .order('id', ascending: false)
            .limit(_pageSize);
      }

      final response = await _retry(() => query);

      // record timing
      sw.stop();
      _networkFetches += 1;
      _totalFetchTimeMs += sw.elapsedMilliseconds;

      if (response == null) return;

      final List<Post> newPosts = [];
      for (final map in response as List) {
        final postId = map['id'] as String;
        try {
          final postObj = Post.fromMap(
            Map<String, dynamic>.from(map),
            currentUserId: userId,
          );
          try {
            Hive.box('post_cache').put(postId, postObj);
          } catch (e) {
            debugPrint('Failed to persist post $postId: $e');
          }
        } catch (e) {
          debugPrint('Invalid post map for $map: $e');
        }

        if (_postCache.containsKey(postId)) {
          newPosts.add(_postCache[postId]!);
        } else {
          final post = Post.fromMap(map, currentUserId: userId);
          _postCache[postId] = post;
          newPosts.add(post);
        }
      }

      final channelUrls = newPosts
          .where(
            (p) => p.channelImageUrl != null && p.channelImageUrl!.isNotEmpty,
          )
          .map((p) => p.channelImageUrl!)
          .toList();

      if (channelUrls.isNotEmpty) {
        ImageCacheService().precacheImages(channelUrls, context);
      }

      // Batch update interactions
      await _batchUpdateInteractions(newPosts);
      // ---- BOOSTED SORTING ----
      final now = DateTime.now();
      newPosts.sort((a, b) {
        final aBoost =
            a.isBoosted &&
            a.boostExpiresAt != null &&
            a.boostExpiresAt!.isAfter(now);
        final bBoost =
            b.isBoosted &&
            b.boostExpiresAt != null &&
            b.boostExpiresAt!.isAfter(now);
        if (aBoost && !bBoost) return -1;
        if (!aBoost && bBoost) return 1;
        if (aBoost && bBoost) {
          return b.boostExpiresAt!.compareTo(a.boostExpiresAt!);
        }
        return b.createdAt.compareTo(a.createdAt);
      });

      if (mounted) {
        setState(() {
          if (reset) {
            _latestPosts.clear();
          }

          _latestPosts.addAll(newPosts);

          final imageUrls = newPosts
              .where((p) => p.imageUrl != null && p.imageUrl!.isNotEmpty)
              .map((p) => p.imageUrl!)
              .toList();

          if (imageUrls.isNotEmpty) {
            ImageCacheService().precacheImages(imageUrls, context);
          }
          if (newPosts.isNotEmpty) {
            _lastCursor = newPosts.last;
          }
          // Successful network fetch → we are online
          _isOffline = false;
          _hasMoreLatest = newPosts.length == _pageSize;
          _isLoadingMore = false;
          _isRefreshing = false;
        });

        if (reset && !_isRefreshing) {
          _latestTabScrollController.animateTo(
            0,
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeOut,
          );
        }
      }
    } catch (e) {
      debugPrint('Error fetching posts: $e');
      if (mounted) {
        // If we have any cached posts, show them so the feed opens offline.
        if (_postCache.isNotEmpty && _latestPosts.isEmpty) {
          final cached = _postCache.values.toList()
            ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
          setState(() {
            _latestPosts.clear();
            _latestPosts.addAll(cached);
            _isLoadingMore = false;
            _hasMoreLatest = false;
            _isOffline = true;
            _cacheLoads += cached.length;
          });
          // Inform user we're offline and showing cache
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Offline: showing cached posts')),
          );
        } else {
          setState(() {
            _isLoadingMore = false;
            _hasMoreLatest = false;
            _isOffline = true;
          });
        }
      }
    } finally {
      _isFetching = false;
    }
  }

  Future<void> _batchUpdateInteractions(List<Post> posts) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null || posts.isEmpty) return;

    final postIds = posts.map((p) => p.id).toList();

    try {
      final likes = await Supabase.instance.client
          .from('likes')
          .select('post_id')
          .inFilter('post_id', postIds)
          .eq('user_id', userId);

      final reposts = await Supabase.instance.client
          .from('reposts')
          .select('post_id')
          .inFilter('post_id', postIds)
          .eq('user_id', userId);

      final likedIds = likes.map((l) => l['post_id'] as String).toSet();
      final repostedIds = reposts.map((r) => r['post_id'] as String).toSet();

      for (final post in posts) {
        post.likedByMe = likedIds.contains(post.id);
        post.repostedByMe = repostedIds.contains(post.id);
      }
    } catch (e) {
      debugPrint('Batch interaction error: $e');
    }
  }

  Future<void> _fetchBoostedPosts() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;

      final response = await Supabase.instance.client
          .from('posts')
          .select('''
            id,
            user_id,
            content,
            image_url,
            created_at,
            poll_options,
            is_boosted,
            boost_expires_at,
            tagged_user_ids,
            tags,
            channel_id,
            channels(name, profile_image_url),
            users!inner(username, handle, level, profile_image_url, blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry),
            likes!post_id(count),
            comments!post_id(count),
            reposts!post_id(count),
            liked_by_me:likes!post_id(user_id),
            reposted_by_me:reposts!post_id(user_id),
            poll_votes!post_id(option_index, user_id)
          ''')
          .eq('is_boosted', true)
          .gt('boost_expires_at', DateTime.now().toIso8601String())
          .order('boost_expires_at', ascending: false)
          .limit(5);

      final boostedPosts = (response as List).map((map) {
        return Post.fromMap(map, currentUserId: userId);
      }).toList();
      // ────── PRECACHE CHANNEL IMAGES (already there) ──────
      final channelUrls = boostedPosts
          .where(
            (p) => p.channelImageUrl != null && p.channelImageUrl!.isNotEmpty,
          )
          .map((p) => p.channelImageUrl!)
          .toList();
      if (channelUrls.isNotEmpty) {
        ImageCacheService().precacheImages(channelUrls, context);
      }

      // ────── PRECACHE POST IMAGES (NEW) ──────
      final imageUrls = boostedPosts
          .where((p) => p.imageUrl != null && p.imageUrl!.isNotEmpty)
          .map((p) => p.imageUrl!)
          .toList();
      if (imageUrls.isNotEmpty) {
        ImageCacheService().precacheImages(imageUrls, context);
      }

      // ────── Update interactions ──────
      for (final post in boostedPosts) {
        await _updatePostInteractions(post);
      }

      if (mounted) {
        setState(() {
          _boostedPosts = boostedPosts;
          _loadingBoosted = false;
        });
        // Start/refresh rotation when boosted posts change
        _startBoostRotation();
      }
    } catch (e) {
      debugPrint('Error fetching boosted posts: $e');
      if (mounted) {
        setState(() {
          _loadingBoosted = false;
        });
      }
    }
  }

  Future<void> _updatePostInteractions(Post post) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final like = await Supabase.instance.client
          .from('likes')
          .select()
          .eq('post_id', post.id)
          .eq('user_id', userId)
          .maybeSingle();

      final repost = await Supabase.instance.client
          .from('reposts')
          .select()
          .eq('post_id', post.id)
          .eq('user_id', userId)
          .maybeSingle();

      post.likedByMe = like != null;
      post.repostedByMe = repost != null;
    } catch (e) {
      debugPrint('Interaction check failed: $e');
    }
  }

  Future<void> _fetchTrendingPosts() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      final now = DateTime.now();
      final twentyFourHoursAgo = now.subtract(const Duration(hours: 24));

      // 1. Fetch recent posts + trending data
      final response = await Supabase.instance.client
          .from('posts')
          .select('''
          id,
          user_id,
          content,
          image_url,
          created_at,
          poll_options,
          is_boosted,
          boost_expires_at,
          tagged_user_ids,
          tags,
          channel_id,
          channels(name, profile_image_url),
          users!inner(username, handle, level, profile_image_url, blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry),
          likes!post_id(count),
          comments!post_id(count),
          reposts!post_id(count),
          liked_by_me:likes!post_id(user_id),
          reposted_by_me:reposts!post_id(user_id),
          poll_votes!post_id(option_index, user_id),
          trending_posts!left(engagement_score, is_trending)
        ''')
          .gte('created_at', twentyFourHoursAgo.toIso8601String())
          .limit(8);

      // 2. Build a list of {post, score, isTrending, createdAt}
      final List<Map<String, dynamic>> items = (response as List).map((map) {
        final tp = map['trending_posts'] as Map<String, dynamic>?;
        final score = (tp?['engagement_score'] as num?)?.toDouble() ?? 0.0;
        final isTrending = (tp?['is_trending'] as bool?) == true;

        return {
          'post': Post.fromMap(map, currentUserId: userId),
          'score': score,
          'isTrending': isTrending,
          'createdAt': DateTime.parse(map['created_at'] as String),
        };
      }).toList();

      // 3. Keep **only** trending items
      final trendingItems = items
          .where((item) => item['isTrending'] as bool)
          .toList();

      // 4. Sort: highest score first → then newest
      trendingItems.sort((a, b) {
        final scoreA = a['score'] as double;
        final scoreB = b['score'] as double;

        if (scoreA == 0.0 && scoreB == 0.0) {
          return (b['createdAt'] as DateTime).compareTo(
            a['createdAt'] as DateTime,
          );
        }
        if (scoreA == 0.0) return 1; // push zero-score to the end
        if (scoreB == 0.0) return -1;
        return scoreB.compareTo(scoreA); // higher score first
      });

      // 5. Final list (max 8)
      final List<Post> finalTrendingPosts = trendingItems
          .take(20)
          .map((e) => e['post'] as Post)
          .toList();

      // ────── PRECACHE CHANNEL IMAGES (already there) ──────
      final channelUrls = finalTrendingPosts
          .where(
            (p) => p.channelImageUrl != null && p.channelImageUrl!.isNotEmpty,
          )
          .map((p) => p.channelImageUrl!)
          .toList();
      if (channelUrls.isNotEmpty) {
        ImageCacheService().precacheImages(channelUrls, context);
      }

      // ────── PRECACHE POST IMAGES (NEW) ──────
      final imageUrls = finalTrendingPosts
          .where((p) => p.imageUrl != null && p.imageUrl!.isNotEmpty)
          .map((p) => p.imageUrl!)
          .toList();
      if (imageUrls.isNotEmpty) {
        ImageCacheService().precacheImages(imageUrls, context);
      }

      // ────── Update interactions ──────
      for (final post in finalTrendingPosts) {
        await _updatePostInteractions(post);
      }

      // 7. Update UI
      if (mounted) {
        setState(() {
          _trendingPosts = finalTrendingPosts;
          _loadingTrending = false;
        });
      }
    } catch (e, stack) {
      debugPrint('Error fetching trending posts: $e\n$stack');
      if (mounted) {
        setState(() => _loadingTrending = false);
      }
    }
  }

  Future<void> _fetchTrendingHashtag() async {
    try {
      final response = await Supabase.instance.client
          .from('trending_hashtags')
          .select('hashtag')
          .lte('start_date', DateTime.now().toIso8601String())
          .gte('end_date', DateTime.now().toIso8601String())
          .maybeSingle();

      if (mounted) {
        setState(() {
          _currentTrendingHashtag = response?['hashtag'] as String?;
        });
      }
    } catch (e) {
      debugPrint('No trending hashtag: $e');
    }
  }

  Future<void> _fetchUserData() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      final userData = await Supabase.instance.client
          .from('users')
          .select('role, username, profile_image_url')
          .eq('id', user.id)
          .single();

      if (mounted) {
        setState(() {
          // Handle both string and list roles
          final roleRaw = userData['role'];
          if (roleRaw is List) {
            _userRole = roleRaw.cast<String>().join(',');
          } else if (roleRaw is String) {
            _userRole = roleRaw;
          } else {
            _userRole = null;
          }
          _username = userData['username'] as String? ?? 'U';
          _profileImageUrl = userData['profile_image_url'] as String?;
        });
      }
    } catch (e) {
      debugPrint('Error fetching user data: $e');
      if (mounted) {
        setState(() {
          _username = user.userMetadata?['username'] ?? 'U';
        });
      }
    }
  }

  Future<void> _fetchNotificationCount() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final response = await Supabase.instance.client
          .from('notifications')
          .select('id')
          .eq('user_id', userId)
          .eq('is_read', false)
          .count();

      if (mounted) {
        setState(() {
          _newNotificationCount = response.count;
        });
      }
    } catch (e) {
      debugPrint('Error fetching notification count: $e');
    }
  }

  void _subscribeToNotifications() {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    _notificationSubscription = Supabase.instance.client
        .channel('notifications')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (payload) {
            if (payload.newRecord['is_read'] == false) {
              setState(() => _newNotificationCount += 1);
            }
          },
        );
  }

  // 2. In _handleNewPost → only collect
  void _handleNewPost(PostgresChangePayload payload) async {
    if (!mounted) return;
    final postId = payload.newRecord['id'] as String;

    // === DEDUPE: Skip if already in UI ===
    if (_postCache.containsKey(postId) ||
        _latestPosts.any((p) => p.id == postId) ||
        _boostedPosts.any((p) => p.id == postId) ||
        _pendingNewPosts.any((p) => p.id == postId)) {
      return;
    }

    final post = Post.fromMap(
      payload.newRecord,
      currentUserId: Supabase.instance.client.auth.currentUser?.id,
    );
    await _updatePostInteractions(post);
    _postCache[postId] = post;

    // PRECACHE...
    if (post.channelImageUrl != null && post.channelImageUrl!.isNotEmpty) {
      ImageCacheService().precacheImages([post.channelImageUrl!], context);
    }
    if (post.imageUrl != null && post.imageUrl!.isNotEmpty) {
      ImageCacheService().precacheImages([post.imageUrl!], context);
    }

    setState(() {
      _pendingNewPosts.insert(0, post);
      _showNewPostsBanner = true;
    });
  }

  Timer? _debounceTimer;

  void _debounceRefetch() {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 800), () {
      if (!mounted) return;
      _fetchLatestPage(reset: true);
      _fetchBoostedPosts(); // Boosted posts can expire
    });
  }

  void _subscribeToPosts() {
    _postsSubscription?.unsubscribe();

    _postsSubscription = Supabase.instance.client
        .channel('feed_updates')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'posts',
          callback: (_) => _debounceRefetch(),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.delete,
          schema: 'public',
          table: 'posts',
          callback: (_) => _debounceRefetch(),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'posts',
          callback: (_) => _debounceRefetch(),
        )
        // Ignore likes, reposts, comments — they don't change feed order
        .subscribe();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _connectivitySub.cancel();
    _carouselController.dispose();
    _notificationSubscription?.unsubscribe();
    _postsSubscription?.unsubscribe();
    _debounceTimer?.cancel();
    _newPostSubscription.unsubscribe();
    _latestRefreshTimer?.cancel();
    _trendingRefreshTimer?.cancel();
    _tabController.dispose();
    _nestedScrollController.dispose();
    _latestTabScrollController.dispose();
    _boostRotateTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      // App went to background → cancel auto‑refresh timers
      _latestRefreshTimer?.cancel();
      _latestRefreshTimer = null;
      _trendingRefreshTimer?.cancel();
      _trendingRefreshTimer = null;
    } else if (state == AppLifecycleState.resumed) {
      // App came back → restart the timers (optional, but keeps behaviour identical)
      _startAutoRefresh();
    }
  }

  Future<void> _openComments(Post post) async {
    final isTrending = _trendingPosts.contains(post);
    final refreshed = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CommentScreen(
          post: post,
          currentUserId: Supabase.instance.client.auth.currentUser?.id,
          onLike: _toggleLike,
          onRepost: _repost,
          onShare: _sharePost,
          onEdit: _editPost,
          onDelete: _deletePost,
          onProfileTap: _navigateToProfile,
          onError: _showLikeError,
          onBoost: _boostPost,
          isTrending: isTrending,
        ),
      ),
    );
    if (refreshed == true && mounted) {}
  }

  Future<void> _toggleLike(Post post) async {
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      showToast('You must be logged in to like posts.');
      return;
    }

    // 1. Optimistic UI
    final wasLiked = post.likedByMe;
    setState(() {
      post.likedByMe = !wasLiked;
      post.likeCount += wasLiked ? -1 : 1;
    });

    try {
      if (!wasLiked) {
        // === LIKING ===
        // Double-check DB (in case of race)
        final existing = await supabase
            .from('likes')
            .select()
            .eq('post_id', post.id)
            .eq('user_id', userId)
            .maybeSingle();

        if (existing != null) {
          // Already liked — revert optimistic
          setState(() {
            post.likedByMe = false;
            post.likeCount--;
          });
          return;
        }

        // Insert like
        await supabase.from('likes').insert({
          'post_id': post.id,
          'user_id': userId,
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });

        // Award XP
        if (post.userId != userId) {
          try {
            final owner = await supabase
                .from('users')
                .select('xp')
                .eq('id', post.userId)
                .single();
            final xp = (owner['xp'] as int?) ?? 0;
            await supabase
                .from('users')
                .update({'xp': xp + 3})
                .eq('id', post.userId);
            await supabase.from('wallet_transactions').insert({
              'user_id': post.userId,
              'type': 'xp_credit',
              'amount': 3,
              'description': 'XP from like on post ${post.id}',
              'created_at': DateTime.now().toUtc().toIso8601String(),
            });
          } catch (e) {
            debugPrint('XP error: $e');
          }
        }
      } else {
        // Safe to delete
        await supabase.from('likes').delete().match({
          'post_id': post.id,
          'user_id': userId,
        });
      }
    } catch (e) {
      // === REVERT ON FAILURE ===
      setState(() {
        post.likedByMe = wasLiked;
        post.likeCount = wasLiked ? post.likeCount + 1 : post.likeCount - 1;
      });
      _showLikeError('Failed to update like');
    }
  }

  void _showLikeError(String message) {
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  Future<void> _sharePost(Post post) async {
    final link = 'https://udusforum.com/p/${post.id}';
    // ignore: deprecated_member_use
    await share_plus.Share.share('$link\n\n${post.content}');
  }

  Future<void> _repost(Post post) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      showToast('You must be logged in to repost.');
      return;
    }

    // 1. OPTIMISTIC UPDATE
    setState(() {
      post.repostedByMe = true;
      post.repostCount++;
    });

    try {
      final existingRepost = await Supabase.instance.client
          .from('reposts')
          .select()
          .eq('post_id', post.id)
          .eq('user_id', userId)
          .maybeSingle();

      if (existingRepost != null) {
        setState(() {
          post.repostedByMe = false;
          post.repostCount--;
        });
        showToast('You have already reposted this post.');
        return;
      }

      await Supabase.instance.client.from('reposts').insert({
        'post_id': post.id,
        'user_id': userId,
        'created_at': DateTime.now().toIso8601String(),
      });

      showToast('Reposted successfully!');
    } catch (e) {
      // REVERT
      setState(() {
        post.repostedByMe = false;
        post.repostCount--;
      });
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to repost: $e')));
    }
  }

  Future<void> _deletePost(Post post) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Post'),
        content: const Text('Are you sure you want to delete this post?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final index = _latestPosts.indexWhere((p) => p.id == post.id);
    if (index != -1) {
      setState(() {
        _latestPosts.removeWhere((p) => p.id == post.id);
        _boostedPosts.removeWhere((p) => p.id == post.id);
        _trendingPosts.removeWhere((p) => p.id == post.id);
      });
    }

    try {
      await Supabase.instance.client
          .from('posts')
          .delete()
          .eq('id', post.id)
          .eq('user_id', Supabase.instance.client.auth.currentUser?.id ?? '');

      if (post.imageUrl != null && post.imageUrl!.isNotEmpty) {
        final filePath = post.imageUrl!.split('/post-images/').last;
        await Supabase.instance.client.storage.from('post-images').remove([
          filePath,
        ]);
      }

      await Future.wait([
        Supabase.instance.client.from('likes').delete().eq('post_id', post.id),
        Supabase.instance.client
            .from('comments')
            .delete()
            .eq('post_id', post.id),
        Supabase.instance.client
            .from('reposts')
            .delete()
            .eq('post_id', post.id),
        Supabase.instance.client
            .from('poll_votes')
            .delete()
            .eq('post_id', post.id),
        Supabase.instance.client
            .from('notifications')
            .delete()
            .eq('post_id', post.id),
        Supabase.instance.client
            .from('hashtag_rewards')
            .delete()
            .eq('post_id', post.id),
        Supabase.instance.client
            .from('boost_metrics')
            .delete()
            .eq('post_id', post.id),
      ]);

      showToast('✅ Post deleted successfully!');
    } catch (e, stackTrace) {
      debugPrint('Error deleting post: $e\nStack trace: $stackTrace');

      // Re-add post to UI since delete failed
      setState(() {
        _latestPosts.add(post);
        _boostedPosts.add(post);
        _trendingPosts.add(post);

        // Keep boosted posts on top
        _latestPosts.sort((a, b) {
          final now = DateTime.now();
          final aBoost =
              a.isBoosted &&
              a.boostExpiresAt != null &&
              a.boostExpiresAt!.isAfter(now);
          final bBoost =
              b.isBoosted &&
              b.boostExpiresAt != null &&
              b.boostExpiresAt!.isAfter(now);

          if (aBoost && !bBoost) return -1;
          if (!aBoost && bBoost) return 1;
          if (aBoost && bBoost) {
            return b.boostExpiresAt!.compareTo(a.boostExpiresAt!);
          }
          return b.createdAt.compareTo(a.createdAt);
        });
      });

      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Failed to delete post: $e')));
      }
    }
  }

  Future<void> _editPost(Post post) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PostCreateScreen(
          post: post,
          trendingHashtag: _currentTrendingHashtag,
        ),
      ),
    );
    if (result == true) {
      showToast('Post updated successfully!');
      _debounceRefetch();
    }
  }

  Future<void> _boostPost(Post post, int hours, int coinCost) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null || userId != post.userId) {
      showToast('Only the post owner can boost this post.');
      return;
    }

    try {
      final userData = await Supabase.instance.client
          .from('users')
          .select('coins')
          .eq('id', userId)
          .single();
      final adminBalance = await Supabase.instance.client
          .from('admin_balance')
          .select('id, coins')
          .eq('id', '72a90a21-8d41-4242-a2c8-1baecf93c349')
          .single();

      await Supabase.instance.client.rpc(
        'boost_post',
        params: {
          'user_id': userId,
          'user_coins': userData['coins'],
          'post_id': post.id,
          'hours': hours,
          'coin_cost': coinCost,
          'admin_balance_id': adminBalance['id'],
          'admin_coins': adminBalance['coins'],
        },
      );

      await Supabase.instance.client.rpc(
        'insert_boost_metrics',
        params: {'p_post_id': post.id, 'p_user_id': userId, 'p_hours': hours},
      );

      await Supabase.instance.client.from('wallet_transactions').insert({
        'user_id': userId,
        'type': 'boost',
        'amount': coinCost,
        'description': 'Boosted post for $hours hours',
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });

      showToast('✅ Post boosted for $hours hours!');
      _debounceRefetch();
    } catch (e) {
      debugPrint('Error boosting post: $e');
      showToast('Failed to boost post: $e');
    }
  }

  void _navigateToProfile(String postUserId) {
    final currentUserId = Supabase.instance.client.auth.currentUser?.id;
    if (currentUserId == null) return;

    if (postUserId == currentUserId) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfileScreen()),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OtherUserProfileScreen(userId: postUserId),
        ),
      );
    }
  }

  void _handleMenuSelection(String value) async {
    if (value == 'logout') {
      ImageCacheService().clear(); // ← ADD THIS
      await Supabase.instance.client.auth.signOut();
      _postCache.clear();
      _fetchingPosts.clear();
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
        );
      }
    } else if (value == 'post_notice') {
      final result = await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const NoticeCreateScreen()),
      );
      if (result == true) {
        // Optionally refresh posts
      }
    } else if (value == 'admin') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const AdminScreen()),
      );
    } else if (value == 'admins') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const AdminsScreen()),
      );
    } else if (value == 'my_channels') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const MyChannelsScreen()),
      );
    } else if (value == 'discover_channels') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const DiscoverChannelsScreen()),
      );
    } else if (value.startsWith('channel_')) {
      final channelId = value.replaceFirst('channel_', '');
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChannelFeedScreen(channelId: channelId),
        ),
      );
    }
  }

  Widget _buildBadgeCountIcon(IconData icon, int count) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Icon(icon, color: Colors.black87),
        if (count > 0)
          Positioned(
            right: -6,
            top: -4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(10),
              ),
              constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
              child: Center(
                child: Text(
                  count.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildTopBoostedCard() {
    if (_loadingBoosted) {
      return const Padding(
        padding: EdgeInsets.all(8.0),
        child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }
    if (_boostedPosts.isEmpty) return const SizedBox.shrink();

    // Use AnimatedSwitcher + fixed key → smooth fade, no jump
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 400),
      transitionBuilder: (child, animation) {
        return FadeTransition(opacity: animation, child: child);
      },
      child: Padding(
        key: const ValueKey('boosted_card_container'), // ← ONE FIXED KEY
        padding: const EdgeInsets.symmetric(vertical: 6.0, horizontal: 8.0),
        child: PostCard(
          key: ValueKey('boost_post_${_boostedPosts[_topBoostIndex].id}'),
          post: _boostedPosts[_topBoostIndex],
          currentUserId: Supabase.instance.client.auth.currentUser?.id,
          onComment: _openComments,
          onLike: _toggleLike,
          onRepost: _repost,
          onShare: _sharePost,
          onEdit: _editPost,
          onDelete: _deletePost,
          onProfileTap: _navigateToProfile,
          onError: _showLikeError,
          onBoost: _boostPost,
          isTrending: _boostedPosts[_topBoostIndex].isTrending,
          onRefreshInteractions: _updatePostInteractions,
        ),
      ),
    );
  }

  // 3. Banner tap → batch insert + smooth scroll
  Widget _buildNewPostsBanner() {
    if (!_showNewPostsBanner ||
        _pendingNewPosts.isEmpty ||
        _pendingNewPosts.length == 1) {
      return const SizedBox.shrink();
    }

    return AnimatedSlide(
      duration: const Duration(milliseconds: 250),
      offset: _showNewPostsBanner ? Offset.zero : const Offset(0, -1),
      child: GestureDetector(
        onTap: () {
          setState(() {
            // 1. Insert all at once
            _latestPosts.insertAll(0, _pendingNewPosts);
            _pendingNewPosts.clear();
            _showNewPostsBanner = false;
          });

          // 2. Smooth scroll to top
          _latestTabScrollController.animateTo(
            0,
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeOut,
          );
        },
        child: Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
          decoration: BoxDecoration(
            color: const Color(0xFF1DA1F2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.refresh, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                '${_pendingNewPosts.length} new post${_pendingNewPosts.length > 1 ? 's' : ''}',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final avatarLetter = _username?.isNotEmpty == true
        ? _username![0].toUpperCase()
        : 'U';

    // Prepare a feed list that excludes currently boosted posts
    final boostedIds = _boostedPosts.map((p) => p.id).toSet();
    final List<Post> displayLatest = _latestPosts
        .where((p) => !boostedIds.contains(p.id))
        .toList();

    return Scaffold(
      backgroundColor: Colors.white,
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Trinity (AI) button ──
          FloatingActionButton(
            heroTag: "trinity",
            mini: true,
            backgroundColor: Colors.green,
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TrinityChatScreen()),
            ),
            child: const Icon(Icons.auto_awesome, color: Colors.white),
          ),
          const SizedBox(height: 12),

          // ── Main Post button ──
          FloatingActionButton(
            heroTag: "post",
            backgroundColor: const Color(0xFF1DA1F2),
            elevation: 6,
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PostCreateScreen(
                    trendingHashtag: _currentTrendingHashtag,
                  ),
                ),
              );

              // === OPTIMISTIC INSERT ===
              if (result is Post && mounted) {
                setState(() {
                  // Avoid duplicate if already in list
                  if (!_latestPosts.any((p) => p.id == result.id)) {
                    _latestPosts.insert(0, result);
                    _postCache[result.id] = result;
                  }
                });

                // Smooth scroll to top
                _latestTabScrollController.animateTo(
                  0,
                  duration: const Duration(milliseconds: 400),
                  curve: Curves.easeOut,
                );

                // Precache image if exists
                if (result.imageUrl != null && result.imageUrl!.isNotEmpty) {
                  ImageCacheService().precacheImages([
                    result.imageUrl!,
                  ], context);
                }
                if (result.channelImageUrl != null &&
                    result.channelImageUrl!.isNotEmpty) {
                  ImageCacheService().precacheImages([
                    result.channelImageUrl!,
                  ], context);
                }
              }
            },
            child: const Icon(Icons.edit, color: Colors.white, size: 28),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      body: NestedScrollView(
        controller: _nestedScrollController,
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverAppBar(
            backgroundColor: Colors.white,
            elevation: innerBoxIsScrolled ? 0.8 : 0.5,
            floating: true,
            snap: true,
            pinned: true,
            centerTitle: true, // ← CENTER TITLE
            expandedHeight: 90,
            leading: Padding(
              padding: const EdgeInsets.only(left: 8),
              child: GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ProfileScreen()),
                ),
                child: AnimatedBuilder(
                  animation: _nestedScrollController,
                  builder: (context, _) {
                    final shrink =
                        (_nestedScrollController.hasClients
                                ? _nestedScrollController.offset /
                                      (120 - kToolbarHeight)
                                : 0.0)
                            .clamp(0.0, 1.0);
                    final avatarRadius = 22 - 4 * shrink;
                    return CircleAvatar(
                      radius: avatarRadius,
                      backgroundColor: Colors.grey[200],
                      backgroundImage: _profileImageUrl != null
                          ? NetworkImage(_profileImageUrl!)
                          : null,
                      child: _profileImageUrl == null
                          ? Text(
                              avatarLetter,
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: avatarRadius * 0.8,
                              ),
                            )
                          : null,
                    );
                  },
                ),
              ),
            ),
            title: AnimatedBuilder(
              animation: _nestedScrollController,
              builder: (context, _) {
                final shrink =
                    (_nestedScrollController.hasClients
                            ? _nestedScrollController.offset /
                                  (120 - kToolbarHeight)
                            : 0.0)
                        .clamp(0.0, 1.0);
                final titleSize = 20 - 2 * shrink;

                return Row(
                  children: [
                    Expanded(
                      child: Text(
                        'UDUS Forum',
                        style: TextStyle(
                          color: Colors.black87,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Roboto',
                          fontSize: titleSize,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ),
                  ],
                );
              },
            ),
            actions: [
              // Department (Compact)
              IconButton(
                icon: _buildBadgeCountIcon(Icons.school, widget.newNoticeCount),
                iconSize: 20,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                onPressed: () {
                  widget.onNoticesViewed();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const DepartmentSelectionScreen(),
                    ),
                  );
                },
              ),
              // Notifications (Compact)
              IconButton(
                icon: _buildBadgeCountIcon(
                  Icons.notifications,
                  _newNotificationCount,
                ),
                iconSize: 22,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => NotificationsScreen(
                        newNotificationCount: _newNotificationCount,
                        onNotificationsViewed: () =>
                            setState(() => _newNotificationCount = 0),
                      ),
                    ),
                  );
                },
              ),
              PopupMenuButton<String>(
                onSelected: _handleMenuSelection,
                itemBuilder: (context) {
                  final List<PopupMenuEntry<String>> items = [
                    const PopupMenuItem<String>(
                      value: 'discover_channels',
                      child: Text('Discover Channels'),
                    ),
                    const PopupMenuItem<String>(
                      value: 'my_channels',
                      child: Text('My Channels'),
                    ),
                    const PopupMenuDivider(),
                    const PopupMenuItem<String>(
                      value: 'logout',
                      child: Text('Logout'),
                    ),
                  ];

                  if (_userRole == 'lecturer') {
                    items.add(
                      const PopupMenuItem<String>(
                        value: 'post_notice',
                        child: Text('Post Notice'),
                      ),
                    );
                  }
                  if (_userRole?.contains('superadmin') ?? false) {
                    items.add(
                      const PopupMenuItem<String>(
                        value: 'admin',
                        child: Text('Superadmin'),
                      ),
                    );
                  }
                  if ((_userRole?.contains('admin') ?? false) ||
                      (_userRole?.contains('moderator') ?? false)) {
                    items.add(
                      const PopupMenuItem<String>(
                        value: 'admins',
                        child: Text('Admin/Moderator'),
                      ),
                    );
                  }

                  return items;
                },
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              collapseMode: CollapseMode.pin,
              background: SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    AnimatedBuilder(
                      animation: _nestedScrollController,
                      builder: (context, _) {
                        final shrink =
                            (_nestedScrollController.hasClients
                                    ? _nestedScrollController.offset /
                                          (120 - kToolbarHeight)
                                    : 0.0)
                                .clamp(0.0, 1.0);
                        final tabHeight =
                            44 - 6 * shrink; // Reduced from 48 → 44

                        return Container(
                          height: tabHeight,
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          alignment: Alignment.center,
                          child: TabBar(
                            controller: _tabController,
                            labelColor: const Color(0xFF1DA1F2),
                            unselectedLabelColor: Colors.grey[600],
                            indicatorColor: const Color(0xFF1DA1F2),
                            indicatorSize: TabBarIndicatorSize.tab,
                            indicatorWeight: 2.5,
                            labelStyle: const TextStyle(
                              fontSize: 13, // ← Smaller
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Roboto',
                            ),
                            unselectedLabelStyle: const TextStyle(
                              fontSize: 13, // ← Consistent
                              fontFamily: 'Roboto',
                            ),
                            labelPadding: const EdgeInsets.symmetric(
                              horizontal: 12,
                            ), // ← Tighter
                            tabs: const [
                              Tab(text: 'Latest'),
                              Tab(
                                text: 'Trending',
                              ), // ← "Trend" → "Trending" (optional)
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabController,
          children: [
            // ==================== LATEST TAB ====================
            (displayLatest.isNotEmpty ||
                    _isLoadingMore ||
                    _boostedPosts.isNotEmpty)
                ? RefreshIndicator(
                    onRefresh: () async {
                      setState(() => _isRefreshing = true);
                      setState(() {
                        _showNewPostsBanner = false;
                        _pendingNewPosts.clear();
                      });
                      await Future.wait([
                        _fetchLatestPage(reset: true),
                        _fetchBoostedPosts(),
                      ]);
                    },
                    color: const Color(0xFF1DA1F2),
                    strokeWidth: 2.5,
                    child: Stack(
                      children: [
                        ListView.builder(
                          physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics(),
                          ),
                          controller: _latestTabScrollController,
                          cacheExtent: 500,
                          padding: EdgeInsets.zero,
                          itemCount:
                              displayLatest.length +
                              (_boostedPosts.isNotEmpty ? 1 : 0) +
                              (_isLoadingMore ? 3 : 0),
                          itemBuilder: (context, index) {
                            // Top boosted slot (single PostCard). When boosts exist,
                            // reserve index 0 for a fixed PostCard that rotates every 5s.
                            if (_boostedPosts.isNotEmpty && index == 0) {
                              return _buildTopBoostedCard();
                            }

                            final adjustedIndex =
                                index - (_boostedPosts.isNotEmpty ? 1 : 0);

                            // Loading skeletons
                            if (_isLoadingMore &&
                                adjustedIndex >= displayLatest.length) {
                              return const PostSkeleton();
                            }

                            // === INSERT NATIVE AD ===
                            final contentIndex = adjustedIndex;
                            if (AdManager().shouldShowNativeAd(contentIndex)) {
                              return NativeAdWidget(
                                key: ValueKey('native_ad_$contentIndex'),
                              );
                            }

                            // Adjust post index after ads
                            final postListIndex =
                                contentIndex -
                                (contentIndex ~/ AdManager().nativeAdFrequency);
                            if (postListIndex >= displayLatest.length) {
                              return const SizedBox.shrink();
                            }

                            final post = displayLatest[postListIndex];

                            return PostCard(
                              key: ValueKey('post_${post.id}'),
                              post: post,
                              currentUserId:
                                  Supabase.instance.client.auth.currentUser?.id,
                              onComment: _openComments,
                              onLike: _toggleLike,
                              onRepost: _repost,
                              onShare: _sharePost,
                              onEdit: _editPost,
                              onDelete: _deletePost,
                              onProfileTap: _navigateToProfile,
                              onError: _showLikeError,
                              onBoost: _boostPost,
                              isTrending: post.isTrending,
                              onRefreshInteractions: _updatePostInteractions,
                            );
                          },
                        ),
                        if (_isOffline)
                          Positioned(
                            top: 0,
                            left: 0,
                            right: 0,
                            child: Material(
                              color: Colors.amber[800],
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.wifi_off,
                                      color: Colors.white,
                                      size: 18,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Builder(
                                        builder: (c) {
                                          final avgFetch = _networkFetches > 0
                                              ? (_totalFetchTimeMs ~/
                                                    _networkFetches)
                                              : 0;
                                          final totalLoads =
                                              _networkFetches + _cacheLoads;
                                          final cacheHit = totalLoads > 0
                                              ? (_cacheLoads *
                                                    100 ~/
                                                    totalLoads)
                                              : 0;
                                          return Text(
                                            'Offline — showing cached posts • avg ${avgFetch}ms • cache $cacheHit%',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    TextButton(
                                      onPressed: () =>
                                          _fetchLatestPage(reset: true),
                                      child: const Text(
                                        'Retry',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        if (_showNewPostsBanner)
                          Positioned(top: 0, child: _buildNewPostsBanner()),
                        if (_isRefreshing)
                          const Positioned(
                            top: 0,
                            left: 0,
                            right: 0,
                            child: LinearProgressIndicator(
                              backgroundColor: Colors.transparent,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Color(0xFF1DA1F2),
                              ),
                              minHeight: 2.5,
                            ),
                          ),
                      ],
                    ),
                  )
                : const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(color: Color(0xFF1DA1F2)),
                        SizedBox(height: 16),
                        Text(
                          'Loading posts...',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),

            // ==================== TRENDING TAB ====================
            _loadingTrending
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                : _trendingPosts.isEmpty
                ? const Center(child: Text('No trending posts yet'))
                : RefreshIndicator(
                    onRefresh: _onRefreshTrending,
                    color: const Color(0xFF1DA1F2),
                    strokeWidth: 2.5,
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics(),
                      ),
                      cacheExtent: 800,
                      padding: EdgeInsets.zero,
                      itemCount:
                          _trendingPosts.length +
                          (_currentTrendingHashtag != null ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (_currentTrendingHashtag != null && index == 0) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.green.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: Colors.green,
                                  width: 1,
                                ),
                              ),
                              padding: const EdgeInsets.all(12),
                              child: Text(
                                'Trending Hashtag: #$_currentTrendingHashtag (+20 XP)',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                            ),
                          );
                        }
                        final postIndex = _currentTrendingHashtag != null
                            ? index - 1
                            : index;
                        // 3. SAFETY: Prevent out-of-bounds
                        if (postIndex >= _trendingPosts.length) {
                          return const PostSkeleton();
                        }

                        // 4. Real post
                        final post = _trendingPosts[postIndex];
                        return PostCard(
                          key: ValueKey('trending_${post.id}'),
                          post: post,
                          currentUserId:
                              Supabase.instance.client.auth.currentUser?.id,
                          onComment: _openComments,
                          onLike: _toggleLike,
                          onRepost: _repost,
                          onShare: _sharePost,
                          onEdit: _editPost,
                          onDelete: _deletePost,
                          onProfileTap: _navigateToProfile,
                          onError: _showLikeError,
                          onBoost: _boostPost,
                          trendingHashtag: _currentTrendingHashtag,
                          isTrending: true,
                          onRefreshInteractions: _updatePostInteractions,
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }

  Future<void> _onRefreshTrending() async {
    await Future.wait([_fetchTrendingPosts(), _fetchTrendingHashtag()]);
  }
}
