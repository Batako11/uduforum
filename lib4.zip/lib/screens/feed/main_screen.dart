import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/services.dart';
import 'package:oktoast/oktoast.dart';
import '../banned/banned_screen.dart';
import '../profile/profile_screen.dart';
import '../messages/messages_screen.dart';
import '../search/search_screen.dart';
import 'main_feed_screen.dart';
import '../dept/department_notice_screen.dart';

// Extension to check if ValueNotifier is disposed
extension ValueNotifierExtension<T> on ValueNotifier<T> {
  bool get isDisposed {
    try {
      value;
      return false;
    } catch (e) {
      return true;
    }
  }
}

// Global notifier for active conversation
final activeConversationId = ValueNotifier<String?>(null);

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with WidgetsBindingObserver {
  int _selectedIndex = 0;
  bool hasNewPosts = false;
  int unreadMessages = 0;
  int newNoticeCount = 0;
  DateTime? _lastBackPressed;
  bool _checkingBan = true;
  bool _isBanned = false;
  String? _banReason;
  DateTime? _banExpiresAt;
  RealtimeChannel? _banSubscription;

  final supabase = Supabase.instance.client;

  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      MainFeedScreen(
        newNoticeCount: newNoticeCount,
        onNoticesViewed: _clearNoticeCount,
      ),
      const MessagesScreen(),
      DepartmentNoticeScreen(
        newNoticeCount: newNoticeCount,
        onNoticesViewed: _clearNoticeCount,
      ),
      const SearchScreen(),
      const ProfileScreen(),
    ];
    // Add listener to track activeConversationId changes
    activeConversationId.addListener(() {
      debugPrint(
        'DEBUG: activeConversationId changed to ${activeConversationId.value}',
      );
    });
    _subscribeToNewPosts();
    _subscribeToNewMessages();
    _subscribeToNewNotices();
    _fetchUnreadMessages();
    _fetchNewNotices();
    _checkBanStatusAndSubscribe();
  }

  @override
  void dispose() {
    _banSubscription?.unsubscribe();
    super.dispose();
  }

  void _subscribeToNewPosts() {
    supabase.from('posts').stream(primaryKey: ['id']).listen((posts) {
      if (_selectedIndex != 0) {
        setState(() {
          hasNewPosts = true;
        });
      }
    });
  }

  void _subscribeToNewMessages() {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    supabase.from('messages').stream(primaryKey: ['id']).listen((
      messages,
    ) async {
      if (activeConversationId.isDisposed) {
        debugPrint(
          'DEBUG: activeConversationId is disposed, skipping message subscription',
        );
        return;
      }

      final preFiltered = messages.where(
        (msg) =>
            msg['is_read'] == false &&
            msg['sender_id'] != userId &&
            (activeConversationId.value == null ||
                activeConversationId.value!.isEmpty ||
                !RegExp(
                  r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                  caseSensitive: false,
                ).hasMatch(activeConversationId.value!) ||
                msg['conversation_id'] != activeConversationId.value),
      );

      final validMessages = await Future.wait(
        preFiltered.map((msg) async {
          final conv = await supabase
              .from('conversations')
              .select()
              .eq('id', msg['conversation_id'])
              .or('user1_id.eq.$userId,user2_id.eq.$userId')
              .maybeSingle();
          return conv != null ? msg : null;
        }).toList(),
      );

      if (mounted) {
        setState(() {
          unreadMessages = validMessages.where((msg) => msg != null).length;
        });
      }
      debugPrint('DEBUG UNREAD MESSAGES: $unreadMessages');
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkBanStatusAndSubscribe();
    }
  }

  Future<void> _checkBanStatusAndSubscribe() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      setState(() => _checkingBan = false);
      return;
    }

    try {
      final data = await supabase
          .from('users')
          .select('banned, ban_reason, ban_expires_at')
          .eq('id', userId)
          .maybeSingle();

      if (data != null && data['banned'] == true) {
        final expiresAt = data['ban_expires_at'] != null
            ? DateTime.tryParse(data['ban_expires_at'])
            : null;

        if (expiresAt != null && expiresAt.isBefore(DateTime.now())) {
          await supabase
              .from('users')
              .update({
                'banned': false,
                'ban_reason': null,
                'ban_expires_at': null,
              })
              .eq('id', userId);
        } else {
          if (mounted) {
            setState(() {
              _isBanned = true;
              _banReason =
                  data['ban_reason'] ?? 'Your account has been suspended.';
              _banExpiresAt = expiresAt;
              _checkingBan = false;
            });
          }
          _subscribeToBan(userId);
          return;
        }
      }
    } catch (e) {
      debugPrint('Ban check error: $e');
    }

    if (mounted) setState(() => _checkingBan = false);
    _subscribeToBan(userId);
  }

  void _subscribeToBan(String userId) {
    _banSubscription?.unsubscribe();
    _banSubscription = supabase
        .channel('ban_$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'users',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: userId,
          ),
          callback: (payload) {
            final banned = payload.newRecord['banned'] as bool? ?? false;
            if (banned && mounted) {
              final reason = payload.newRecord['ban_reason'] as String?;
              final expires = payload.newRecord['ban_expires_at'] as String?;
              final expiresAt = expires != null
                  ? DateTime.tryParse(expires)
                  : null;
              setState(() {
                _isBanned = true;
                _banReason = reason ?? 'Your account has been suspended.';
                _banExpiresAt = expiresAt;
              });
            }
          },
        )
        .subscribe();
  }

  void _subscribeToNewNotices() {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    supabase.from('notices').stream(primaryKey: ['id']).listen((notices) async {
      final userData = await supabase
          .from('users')
          .select('department_id')
          .eq('id', userId)
          .single();

      final departmentId = userData['department_id'] as String?;
      if (departmentId == null) return;

      final newNotices = notices.where(
        (notice) =>
            notice['department_id'] == departmentId &&
            notice['created_at'] != null &&
            DateTime.parse(
              notice['created_at'],
            ).isAfter(DateTime.now().subtract(const Duration(minutes: 1))),
      );

      if (mounted && _selectedIndex != 2) {
        setState(() {
          newNoticeCount = newNotices.length;
        });
      }
      debugPrint('DEBUG NEW NOTICE COUNT: $newNoticeCount');
    });
  }

  Future<void> _fetchUnreadMessages() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    try {
      var query = supabase
          .from('messages')
          .select()
          .eq('is_read', false)
          .neq('sender_id', userId);

      if (activeConversationId.value != null &&
          activeConversationId.value!.isNotEmpty &&
          RegExp(
            r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
            caseSensitive: false,
          ).hasMatch(activeConversationId.value!)) {
        query = query.not('conversation_id', 'eq', activeConversationId.value!);
      }

      final response = await query;

      final validMessages = await Future.wait(
        response.map((msg) async {
          final conv = await supabase
              .from('conversations')
              .select()
              .eq('id', msg['conversation_id'])
              .or('user1_id.eq.$userId,user2_id.eq.$userId')
              .maybeSingle();
          return conv != null ? msg : null;
        }),
      );

      if (mounted) {
        setState(() {
          unreadMessages = validMessages.where((msg) => msg != null).length;
        });
      }
      debugPrint('DEBUG INITIAL UNREAD MESSAGES: $unreadMessages');
    } catch (e) {
      debugPrint('Error fetching unread messages: $e');
      if (mounted) showToast('Failed to fetch unread messages');
    }
  }

  Future<void> _fetchNewNotices() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final userData = await supabase
          .from('users')
          .select('department_id')
          .eq('id', userId)
          .single();

      final departmentId = userData['department_id'] as String?;
      if (departmentId == null) return;

      final response = await supabase
          .from('notices')
          .select()
          .eq('department_id', departmentId)
          .gt(
            'created_at',
            DateTime.now().subtract(const Duration(days: 1)).toIso8601String(),
          );

      if (mounted) {
        setState(() {
          newNoticeCount = response.length;
        });
      }
      debugPrint('DEBUG INITIAL NEW NOTICE COUNT: $newNoticeCount');
    } catch (e) {
      debugPrint('Error fetching new notices: $e');
      if (mounted) showToast('Failed to fetch new notices');
    }
  }

  void _clearNoticeCount() {
    setState(() {
      newNoticeCount = 0;
    });
  }

  Widget _buildBadgeIcon(IconData icon, {bool showBadge = false}) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Icon(icon),
        if (showBadge)
          Positioned(
            right: -2,
            top: -2,
            child: Container(
              width: 10,
              height: 10,
              decoration: const BoxDecoration(
                color: Colors.red,
                shape: BoxShape.circle,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildBadgeCountIcon(IconData icon, int count) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Icon(icon),
        if (count > 0)
          Positioned(
            right: -6,
            top: -4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(10),
              ),
              constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
              child: Center(
                child: Text(
                  count.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // SHOW BANNED SCREEN FIRST
    if (_checkingBan) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_isBanned) {
      return BannedScreen(reason: _banReason, expiresAt: _banExpiresAt);
    }

    // NORMAL UI
    // WillPopScope is deprecated in newer Flutter versions; keep behavior
    // and silence the deprecation here until full PopScope migration is done.
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () async {
        final now = DateTime.now();
        // If not on Home tab, navigate to Home instead of exiting the app.
        if (_selectedIndex != 0) {
          setState(() => _selectedIndex = 0);
          return false; // prevent pop
        }

        // Double-back-to-exit on Home: show tiny toast on first back
        if (_lastBackPressed == null ||
            now.difference(_lastBackPressed!) > const Duration(seconds: 2)) {
          _lastBackPressed = now;
          showToast(
            'press back again to exit',
            duration: const Duration(seconds: 2),
            position: ToastPosition.bottom,
            textStyle: const TextStyle(fontSize: 12),
          );
          return false; // consume first back
        }

        // Second back within 2s → allow default (exit)
        return true;
      },
      child: Scaffold(
        body: IndexedStack(index: _selectedIndex, children: _screens),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: _selectedIndex,
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
              if (index == 0) hasNewPosts = false;
              if (index == 1) {
                unreadMessages = 0;
                if (!activeConversationId.isDisposed) {
                  activeConversationId.value = null;
                }
                _fetchUnreadMessages();
              }
              if (index == 2) {
                newNoticeCount = 0;
                _clearNoticeCount();
              }
              if (index == 4) {
                HapticFeedback.mediumImpact();
              }
            });
          },
          selectedItemColor: const Color(0xFF1E88E5),
          unselectedItemColor: Colors.grey[600],
          backgroundColor: Colors.white,
          items: [
            BottomNavigationBarItem(
              icon: _buildBadgeIcon(
                Icons.home_outlined,
                showBadge: hasNewPosts,
              ),
              activeIcon: _buildBadgeIcon(Icons.home, showBadge: hasNewPosts),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: _buildBadgeCountIcon(
                LucideIcons.messageCircle,
                unreadMessages,
              ),
              activeIcon: _buildBadgeCountIcon(
                LucideIcons.messageCircle,
                unreadMessages,
              ),
              label: 'Messages',
            ),
            BottomNavigationBarItem(
              icon: _buildBadgeCountIcon(
                LucideIcons.graduationCap,
                newNoticeCount,
              ),
              activeIcon: _buildBadgeCountIcon(Icons.school, newNoticeCount),
              label: 'Dept Notices',
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.search_outlined),
              activeIcon: const Icon(Icons.search),
              label: 'Search',
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.person_outline),
              activeIcon: const Icon(Icons.person),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }
}
