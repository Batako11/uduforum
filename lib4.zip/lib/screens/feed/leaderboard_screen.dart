// leaderboard_screen.dart
import 'package:flutter/material.dart';
import 'package:confetti/confetti.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';
import '../profile/other_user_profile_screen.dart';
import '/utils/level_utils.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;
  late final ConfettiController _confettiController;

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(
      duration: const Duration(seconds: 4),
    );
    _confettiController.play();
    _loadLeaderboard();
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  Future<void> _loadLeaderboard() async {
    try {
      final response = await supabase
          .from('users')
          .select('id, username, full_name, profile_image_url, xp')
          .order('xp', ascending: false)
          .limit(100);

      if (mounted) {
        setState(() {
          _users = List<Map<String, dynamic>>.from(response);
          _loading = false;
        });
      }
    } catch (e) {
      debugPrint('Leaderboard error: $e');
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.emoji_events, color: Colors.amber[700], size: 28),
            const SizedBox(width: 8),
            const Text(
              'Stars Leaderboard',
              style: TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ],
        ),
      ),

      body: Stack(
        children: [
          _loading
              ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
              : _users.isEmpty
              ? const Center(
                  child: Text(
                    'No stars yet',
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                )
              : Column(
                  children: [
                    if (_users.length >= 3) _buildPodium(),
                    const SizedBox(height: 16),
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: _users.length > 3 ? _users.length - 3 : 0,
                        itemBuilder: (context, i) {
                          final index = i + 3;
                          final user = _users[index];
                          final levelInfo = getLevelInfo(
                            user['xp'] ?? 0,
                          ); // Used here

                          return Card(
                            elevation: 2,
                            margin: const EdgeInsets.symmetric(vertical: 6),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: ListTile(
                              leading: Stack(
                                children: [
                                  CircleAvatar(
                                    radius: 26,
                                    backgroundImage:
                                        user['profile_image_url'] != null
                                        ? NetworkImage(
                                            user['profile_image_url'],
                                          )
                                        : null,
                                    child: user['profile_image_url'] == null
                                        ? Text(
                                            (user['full_name']?.isNotEmpty ==
                                                        true
                                                    ? user['full_name'][0]
                                                    : user['username']?[0] ??
                                                          'U')
                                                .toUpperCase(),
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                            ),
                                          )
                                        : null,
                                  ),
                                  Positioned(
                                    bottom: 0,
                                    right: 0,
                                    child: Container(
                                      padding: const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: levelInfo['color'],
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: Colors.white,
                                          width: 2,
                                        ),
                                      ),
                                      child: Icon(
                                        levelInfo['icon'],
                                        size: 16,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              title: Text(
                                user['full_name']?.isNotEmpty == true
                                    ? user['full_name']
                                    : user['username'] ?? 'User',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              subtitle: Row(
                                children: [
                                  const Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                    size: 16,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    '${user['xp']} Stars • Level ${levelInfo['level']} ${levelInfo['title']}',
                                    style: TextStyle(color: Colors.grey[600]),
                                  ),
                                ],
                              ),
                              trailing: Text(
                                '#${index + 1}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: index < 9
                                      ? const Color(0xFF1E88E5)
                                      : Colors.grey[600],
                                ),
                              ),
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => OtherUserProfileScreen(
                                    userId: user['id'],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),

          // Confetti
          Align(
            alignment: Alignment.topCenter,
            child: ConfettiWidget(
              confettiController: _confettiController,
              blastDirectionality: BlastDirectionality.explosive,
              emissionFrequency: 0.05,
              numberOfParticles: 50,
              gravity: 0.2,
              colors: const [
                Colors.amber,
                Colors.orange,
                Colors.red,
                Colors.purple,
                Colors.blue,
              ],
            ),
          ),
        ],
      ),

      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(height: 0.5, color: Colors.grey[300]),
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }

  Widget _buildPodium() {
    final top3 = _users.take(3).toList();

    return SizedBox(
      height: 320,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          _podiumUser(top3[1], rank: 2, height: 210),
          const SizedBox(width: 24),
          _podiumUser(top3[0], rank: 1, height: 270, isChampion: true),
          const SizedBox(width: 24),
          _podiumUser(top3[2], rank: 3, height: 180),
        ],
      ),
    );
  }

  Widget _podiumUser(
    Map<String, dynamic> user, {
    required int rank,
    required double height,
    bool isChampion = false,
  }) {
    final levelInfo = getLevelInfo(user['xp'] ?? 0); // Now properly used!
    final medalColor = rank == 1
        ? Colors.amber
        : rank == 2
        ? Colors.grey[400]!
        : Colors.brown[600]!;

    return Column(
      children: [
        Text(
          '#$rank',
          style: TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.bold,
            color: medalColor,
            shadows: const [Shadow(blurRadius: 10, color: Colors.black26)],
          ),
        ),
        const SizedBox(height: 8),
        Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              width: 100,
              height: height,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    medalColor.withValues(alpha: 0.95),
                    medalColor.withValues(alpha: 0.7),
                  ],
                ),
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(20),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 12,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  const SizedBox(height: 50), // Space for avatar + badge
                  if (isChampion)
                    Icon(
                      Icons.emoji_events,
                      color: Colors.amber[800],
                      size: 44,
                    ),
                  Text(
                    user['full_name']?.isNotEmpty == true
                        ? user['full_name']
                        : user['username'],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontSize: 13,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    '${user['xp']} Stars',
                    style: const TextStyle(color: Colors.white70, fontSize: 11),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
            // Avatar + Level Badge on Top
            Positioned(
              top: -10,
              left: 0,
              right: 0,
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.white,
                    child: CircleAvatar(
                      radius: 37,
                      backgroundImage: user['profile_image_url'] != null
                          ? NetworkImage(user['profile_image_url'])
                          : null,
                      child: user['profile_image_url'] == null
                          ? Text(
                              (user['full_name']?.isNotEmpty == true
                                      ? user['full_name'][0]
                                      : user['username']?[0] ?? 'U')
                                  .toUpperCase(),
                              style: const TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          : null,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: levelInfo['color'],
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(levelInfo['icon'], size: 16, color: Colors.white),
                        const SizedBox(width: 4),
                        Text(
                          'Lvl ${levelInfo['level']}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}
