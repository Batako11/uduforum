import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'full_screen_image.dart';
import '/models/post_model.dart';
import '../profile/other_user_profile_screen.dart';
import '../channel/channel_feed_screen.dart';

class PostCard extends StatefulWidget {
  final Post post;
  final String? trendingHashtag;
  final String? currentUserId;
  final Future<void> Function(Post) onComment;
  final Future<void> Function(Post) onLike;
  final Future<void> Function(Post) onRepost;
  final Future<void> Function(Post) onShare;
  final Function(Post, int)? onPollVote;
  final Future<void> Function(Post) onEdit;
  final Future<void> Function(Post) onDelete;
  final void Function(String) onProfileTap;
  final void Function(String) onError;
  final Future<void> Function(Post, int, int) onBoost;
  final bool isTrending;
  static final _tagCache = <String, List<InlineSpan>>{};
  final Future<void> Function(Post)? onRefreshInteractions;
  final List<Post>? allPosts;

  const PostCard({
    super.key,
    required this.post,
    required this.currentUserId,
    required this.onComment,
    required this.onLike,
    required this.onRepost,
    required this.onShare,
    this.onPollVote,
    required this.onEdit,
    required this.onDelete,
    required this.onProfileTap,
    required this.onError,
    required this.onBoost,
    required this.isTrending,
    this.trendingHashtag,
    this.onRefreshInteractions,
    this.allPosts,
  });

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  bool _expanded = false;
  Map<String, String> _taggedUsernames = {};
  static final Set<String> _preloadedUrls = {};
  int? _localUserVoteIndex;

  @override
  void initState() {
    super.initState();
    _loadTaggedUsernames();
    _localUserVoteIndex = widget.post.userVoteIndex;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.onRefreshInteractions?.call(widget.post);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId != null && widget.post.isBoosted) {
        await Supabase.instance.client.from('post_views').insert({
          'post_id': widget.post.id,
          'user_id': userId,
          'viewed_at': DateTime.now().toIso8601String(),
        });
      }
    });
  }

  @override
  void didUpdateWidget(covariant PostCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.post.id != widget.post.id ||
        oldWidget.post.userVoteIndex != widget.post.userVoteIndex) {
      _localUserVoteIndex = widget.post.userVoteIndex;
    }
  }

  List<InlineSpan> _getCachedSpans(String content) {
    return PostCard._tagCache[content] ??= _parseTags(content);
  }

  void _showTickInfo(
    BuildContext context, {
    required bool isGold,
    required DateTime expiry,
  }) {
    final daysLeft = expiry.difference(DateTime.now()).inDays;
    final formatted = DateFormat('MMM d, yyyy').format(expiry);

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: isGold ? Colors.amber[50] : Colors.blue[50],
        title: Row(
          children: [
            Icon(Icons.verified, color: isGold ? Colors.amber : Colors.blue),
            const SizedBox(width: 8),
            Text(isGold ? 'Gold Verified' : 'Blue Verified'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isGold
                  ? 'This is a premium verified account.'
                  : 'This account is verified.',
            ),
            const SizedBox(height: 8),
            Text('Expires: $formatted'),
            Text('Days left: $daysLeft'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _loadTaggedUsernames() async {
    if (widget.post.taggedUserIds == null || widget.post.taggedUserIds!.isEmpty) {
      return;
    }

    try {
      final response = await Supabase.instance.client
          .from('users')
          .select('id, username')
          .inFilter('id', widget.post.taggedUserIds!);

      final map = <String, String>{};
      for (var user in response) {
        map[user['id']] = user['username'];
      }

      if (mounted) {
        setState(() {
          _taggedUsernames = map;
        });
      }
    } catch (e) {
      debugPrint('Failed to load tagged users: $e');
    }
  }

  Future<void> _voteOnPoll(String postId, int optionIndex) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      _showError('You must be logged in to vote.');
      return;
    }

    // ---- 1. Prevent double-vote ----
    if (_localUserVoteIndex != null || widget.post.userVoteIndex != null) {
      return;
    }

    // ---- 2. Optimistic UI (only this card) ----
    setState(() {
      // Increment count
      widget.post.pollVoteCounts[optionIndex] =
          (widget.post.pollVoteCounts[optionIndex] ?? 0) + 1;
      // Track locally
      _localUserVoteIndex = optionIndex;
    });

    // ---- 3. Server insert ----
    try {
      await Supabase.instance.client.from('poll_votes').insert({
        'post_id': postId,
        'user_id': userId,
        'option_index': optionIndex,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });

      // ---- 4. Re-fetch only this post's counts ----
      final fresh = await Supabase.instance.client
          .from('poll_votes')
          .select('option_index')
          .eq('post_id', postId);

      final Map<int, int> serverCounts = {};
      for (final row in fresh) {
        final idx = row['option_index'] as int;
        serverCounts[idx] = (serverCounts[idx] ?? 0) + 1;
      }

      // Apply server truth
      setState(() {
        widget.post.pollVoteCounts
          ..clear()
          ..addAll(serverCounts);
        // Keep local vote (server has it now)
        _localUserVoteIndex = optionIndex;
      });
    } catch (e) {
      // ---- 5. Revert on error ----
      setState(() {
        final current = widget.post.pollVoteCounts[optionIndex] ?? 0;
        if (current > 0) {
          widget.post.pollVoteCounts[optionIndex] = current - 1;
          if (widget.post.pollVoteCounts[optionIndex] == 0) {
            widget.post.pollVoteCounts.remove(optionIndex);
          }
        }
        _localUserVoteIndex = null;
      });
      _showError('Failed to vote');
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: Colors.redAccent,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _reportPost() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      const Text('You must be logged in to vote.');
      return;
    }
    if (userId == widget.post.userId) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          content: const Text('You cannot report your own post.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }
    try {
      final existingReport = await Supabase.instance.client
          .from('user_reports')
          .select()
          .eq('post_id', widget.post.id)
          .eq('reporter_id', userId)
          .maybeSingle();
      if (existingReport != null) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            content: const Text('You have already reported this post.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
        );
        return;
      }
      String? selectedReason;
      final reasons = [
        'Inappropriate content',
        'Spam',
        'Harassment',
        'Misinformation',
        'Other',
      ];
      await showDialog(
        context: context,
        builder: (context) => StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            title: const Text('Report Post'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Please select a reason for reporting this post:'),
                const SizedBox(height: 8),
                DropdownButton<String>(
                  isExpanded: true,
                  hint: const Text('Select a reason'),
                  value: selectedReason,
                  items: reasons.map((reason) {
                    return DropdownMenuItem<String>(
                      value: reason,
                      child: Text(reason),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setDialogState(() {
                      selectedReason = value;
                    });
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: selectedReason == null
                    ? null
                    : () async {
                        try {
                          await Supabase.instance.client
                              .from('user_reports')
                              .insert({
                                'post_id': widget.post.id,
                                'reporter_id': userId,
                                'user_id': widget.post.userId,
                                'reason': selectedReason,
                                'status': 'pending',
                                'created_at': DateTime.now().toIso8601String(),
                              });
                          await Supabase.instance.client
                              .from('posts')
                              .update({'is_flagged': true})
                              .eq('id', widget.post.id);
                          await Supabase.instance.client
                              .from('notifications')
                              .insert({
                                'user_id': widget.post.userId,
                                'actor_id': userId,
                                'type': 'report',
                                'post_id': widget.post.id,
                                'created_at': DateTime.now().toIso8601String(),
                                'is_read': false,
                              });
                          try {
                            final admins = await Supabase.instance.client.rpc(
                              'get_admins',
                              params: {
                                'roles': ['admin', 'superadmin', 'moderator'],
                              },
                            );
                            for (final admin in admins) {
                              await Supabase.instance.client
                                  .from('notifications')
                                  .insert({
                                    'user_id': admin['id'],
                                    'actor_id': userId,
                                    'type': 'report_admin',
                                    'post_id': widget.post.id,
                                    'created_at': DateTime.now()
                                        .toIso8601String(),
                                    'is_read': false,
                                  });
                            }
                          } catch (adminError) {
                            debugPrint('Error notifying admins: $adminError');
                          }
                          showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                              content: const Text(
                                'Post reported successfully!',
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context),
                                  child: const Text('OK'),
                                ),
                              ],
                            ),
                          );
                          Navigator.pop(context);
                        } catch (e) {
                          debugPrint('Error reporting post: $e');
                          showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                              content: Text(
                                'Failed to report post: ${e.toString()}',
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context),
                                  child: const Text('OK'),
                                ),
                              ],
                            ),
                          );
                          widget.onError('Failed to report post: $e');
                        }
                      },
                child: const Text(
                  'Report',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      debugPrint('Error checking existing report: $e');
      showToast('Failed to check existing report: $e');
      widget.onError('Failed to check existing report: $e');
    }
  }

  List<InlineSpan> _parseTags(String content) {
    final List<InlineSpan> spans = [];

    // Matches: @user, #hashtag, $cashtag, @customtag, http(s)://…
    final RegExp tagExp = RegExp(
      r'(@|#|\$)([a-zA-Z0-9_]+)|(https?://[\S]+)',
      caseSensitive: false,
    );

    int lastIndex = 0;

    for (final RegExpMatch match in tagExp.allMatches(content)) {
      // ---- plain text before the match ----
      if (match.start > lastIndex) {
        spans.add(TextSpan(text: content.substring(lastIndex, match.start)));
      }

      final String fullMatch = match.group(0)!;
      final String? prefix = match.group(1);
      final String? tag = match.group(2);
      final bool isUrl = match.group(3) != null;

      if (isUrl) {
        // ---- URLs ----
        final String url = match.group(3)!;
        spans.add(
          TextSpan(
            text: url,
            style: const TextStyle(
              color: Colors.blue,
              decoration: TextDecoration.underline,
              fontFamily: 'Roboto',
            ),
            recognizer: TapGestureRecognizer()
              ..onTap = () async {
                final Uri uri = Uri.parse(url);
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  showToast('Cannot open link');
                }
              },
          ),
        );
      } else {
        // ---- @ # $ tags ----
        // prefix and tag are guaranteed to be non‑null because the regex
        // captured group 1 and 2 for non‑URL matches.
        final String safePrefix = prefix!;
        final String safeTag = tag!;

        final bool isMention = safePrefix == '@';
        final bool isHashtag = safePrefix == '#';

        // Trending‑hashtag check (only hashtags can be trending)
        final bool isTrendingHashtag =
            isHashtag && safeTag == widget.trendingHashtag;

        final Color tagColor = isTrendingHashtag ? Colors.green : Colors.blue;

        spans.add(
          WidgetSpan(
            child: GestureDetector(
              onTap: () {
                if (isMention) {
                  // ---- @mention → open profile if user exists ----
                  Supabase.instance.client
                      .from('users')
                      .select('id')
                      .eq('username', safeTag) // ← safeTag is String
                      .maybeSingle()
                      .then((user) {
                        if (user != null &&
                            user['id'] != widget.currentUserId) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => OtherUserProfileScreen(
                                userId: user['id'] as String,
                              ),
                            ),
                          );
                        }
                      })
                      .catchError((_) {
                        // ignore – user simply doesn’t exist
                      });
                } else {
                  // ---- #hashtag, $cashtag, @custom → generic search ----
                  showToast('Search for $fullMatch');
                }
              },
              child: Text(
                fullMatch,
                style: TextStyle(
                  color: tagColor,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Roboto',
                ),
              ),
            ),
          ),
        );
      }

      lastIndex = match.end;
    }

    // ---- remaining plain text ----
    if (lastIndex < content.length) {
      spans.add(TextSpan(text: content.substring(lastIndex)));
    }

    return spans;
  }

  Widget _iconText(
    IconData icon,
    String text, {
    required Color color,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, size: 18, color: color), // Smaller icons for X.com style
          if (text.isNotEmpty) ...[
            const SizedBox(width: 4),
            Text(
              text,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontFamily: 'Roboto',
              ),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isUsingTrendingHashtag =
        widget.trendingHashtag != null &&
        widget.post.tags?['hashtags']?.contains(widget.trendingHashtag) == true;
    // === PRELOAD NEXT 3 IMAGES ===
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final list = widget.allPosts;
      if (list == null) return;

      final currentIndex = list.indexOf(widget.post);
      if (currentIndex == -1) return;

      for (int i = 1; i <= 3 && currentIndex + i < list.length; i++) {
        final url = list[currentIndex + i].imageUrl;
        if (url != null && url.isNotEmpty && !_preloadedUrls.contains(url)) {
          precacheImage(CachedNetworkImageProvider(url), context).then((_) {
            _preloadedUrls.add(url);
            if (_preloadedUrls.length > 50) {
              final oldest = _preloadedUrls.first;
              _preloadedUrls.remove(oldest);
              PaintingBinding.instance.imageCache.evict(Uri.parse(oldest));
            }
          });
        }
      }
    });
    return RepaintBoundary(
      child: InkWell(
        onTap: () => widget.onComment(widget.post),
        splashColor: Colors.grey.withValues(alpha: 0.1),
        highlightColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(
              bottom: BorderSide(
                color: Colors.grey.withValues(alpha: 0.4),
                width: 0.5,
              ),
            ),
          ),
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 🔹 CHANNEL ROW (kept exactly as your logic)
              if (widget.post.channelName != null &&
                  widget.post.channelName!.isNotEmpty)
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChannelFeedScreen(
                          channelId: widget.post.channelId!,
                        ),
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: Colors.grey[200],
                          backgroundImage:
                              widget.post.channelImageUrl != null &&
                                  widget.post.channelImageUrl!.isNotEmpty
                              ? NetworkImage(widget.post.channelImageUrl!)
                              : null,
                          child:
                              (widget.post.channelImageUrl == null ||
                                  widget.post.channelImageUrl!.isEmpty)
                              ? const Icon(
                                  Icons.campaign,
                                  size: 18,
                                  color: Color(0xFF1DA1F2),
                                )
                              : null,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          widget.post.channelName!,
                          style: const TextStyle(
                            color: Color(0xFF1DA1F2),
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              // 🔹 POST BODY (X layout)
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Avatar
                  GestureDetector(
                    onTap: () => widget.onProfileTap(widget.post.userId),
                    child: CircleAvatar(
                      radius: 20,
                      backgroundColor: Colors.grey[200],
                      backgroundImage: widget.post.profileImageUrl != null
                          ? NetworkImage(widget.post.profileImageUrl!)
                          : null,
                      child: widget.post.profileImageUrl == null
                          ? Text(
                              widget.post.username.isNotEmpty
                                  ? widget.post.username[0].toUpperCase()
                                  : 'U',
                              style: const TextStyle(
                                color: Colors.black87,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Roboto',
                              ),
                            )
                          : null,
                    ),
                  ),
                  const SizedBox(width: 10),

                  // Post content
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Flexible(
                                            child: Text(
                                              widget.post.username,
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15,
                                                color: Colors.black,
                                                fontFamily: 'Roboto',
                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),

                                          // ✅ Blue tick badge
                                          // GOLD TICK (Priority)
                                          if (widget.post.goldTick &&
                                              (widget.post.goldTickExpiry
                                                      ?.isAfter(
                                                        DateTime.now(),
                                                      ) ??
                                                  false))
                                            GestureDetector(
                                              onTap: () => _showTickInfo(
                                                context,
                                                isGold: true,
                                                expiry:
                                                    widget.post.goldTickExpiry!,
                                              ),
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                  left: 3,
                                                ),
                                                child: Icon(
                                                  Icons.verified,
                                                  color: Colors.amber.shade700,
                                                  size: 15,
                                                ),
                                              ),
                                            )
                                          // BLUE TICK (Fallback if no Gold)
                                          else if (widget.post.blueTick &&
                                              (widget.post.blueTickExpiry
                                                      ?.isAfter(
                                                        DateTime.now(),
                                                      ) ??
                                                  false))
                                            GestureDetector(
                                              onTap: () => _showTickInfo(
                                                context,
                                                isGold: false,
                                                expiry:
                                                    widget.post.blueTickExpiry!,
                                              ),
                                              child: const Padding(
                                                padding: EdgeInsets.only(
                                                  left: 3,
                                                ),
                                                child: Icon(
                                                  Icons.verified,
                                                  color: Colors.blue,
                                                  size: 15,
                                                ),
                                              ),
                                            ),

                                          // 🚀 Animated Boosted Badge
                                          if (widget.post.isBoosted &&
                                              widget.post.boostExpiresAt !=
                                                  null &&
                                              widget.post.boostExpiresAt!
                                                  .isAfter(DateTime.now()))
                                            const Padding(
                                              padding: EdgeInsets.only(
                                                left: 10,
                                              ),
                                              child: Icon(
                                                Icons.rocket_launch,
                                                color: Color(0xFF1DA1F2),
                                                size: 19,
                                              ),
                                            ),
                                        ],
                                      ),
                                      // Time
                                      Text(
                                        '${widget.post.handle} • ${timeago.format(widget.post.createdAt)}',
                                        style: const TextStyle(
                                          color: Color(0xFF6B7280),
                                          fontSize: 13,
                                          fontFamily: 'Roboto',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (widget.post.userId == widget.currentUserId)
                                  PopupMenuButton<String>(
                                    icon: const Icon(
                                      Icons.more_vert,
                                      size: 18,
                                      color: Color(0xFF6B7280),
                                    ),
                                    onSelected: (value) {
                                      if (value == 'edit') {
                                        widget.onEdit(widget.post);
                                      } else if (value == 'delete') {
                                        widget.onDelete(widget.post);
                                      } else if (value.startsWith('boost_')) {
                                        final hours = int.parse(
                                          value.split('_')[1],
                                        );
                                        final coinCost = hours == 7
                                            ? 20
                                            : hours == 15
                                            ? 50
                                            : hours == 24
                                            ? 70
                                            : 200;
                                        widget.onBoost(
                                          widget.post,
                                          hours,
                                          coinCost,
                                        );
                                      }
                                    },
                                    itemBuilder: (context) {
                                      final items = [
                                        const PopupMenuItem(
                                          value: 'edit',
                                          child: Text('Edit'),
                                        ),
                                        const PopupMenuItem(
                                          value: 'delete',
                                          child: Text(
                                            'Delete',
                                            style: TextStyle(color: Colors.red),
                                          ),
                                        ),
                                      ];
                                      if (!widget.post.isBoosted ||
                                          (widget.post.boostExpiresAt?.isBefore(
                                                DateTime.now(),
                                              ) ??
                                              true)) {
                                        items.addAll([
                                          const PopupMenuItem(
                                            value: 'boost_7',
                                            child: Text(
                                              'Boost 7h (20 coins)',
                                            ),
                                          ),
                                          const PopupMenuItem(
                                            value: 'boost_15',
                                            child: Text(
                                              'Boost 15h (50 coins)',
                                            ),
                                          ),
                                          const PopupMenuItem(
                                            value: 'boost_24',
                                            child: Text(
                                              'Boost 24h (70 coins)',
                                            ),
                                          ),
                                          const PopupMenuItem(
                                            value: 'boost_48',
                                            child: Text(
                                              'Boost 48h (200 coins)',
                                            ),
                                          ),
                                        ]);
                                      }
                                      return items;
                                    },
                                  ),
                              ],
                            ),
                          ],
                        ),

                        if (widget.isTrending || isUsingTrendingHashtag)
                          Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: Text(
                              widget.isTrending
                                  ? '🔥 Trending Post'
                                  : '🔥 Uses Trending Hashtag',
                              style: const TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.w500,
                                fontSize: 12,
                                fontFamily: 'Roboto',
                              ),
                            ),
                          ),

                        // Content text
                        // === POST BODY TEXT (X.com style) ===
                        // === MEMOIZED POST TEXT (NO REBUILD ON INTERACTION) ===
                        Padding(
                          padding: const EdgeInsets.only(top: 5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Use ValueNotifier to trigger rebuild ONLY when content or expanded state changes
                              ValueListenableBuilder<String>(
                                valueListenable: ValueNotifier<String>(
                                  '${widget.post.id}_expanded_$_expanded',
                                ),
                                builder: (context, _, _) {
                                  final contentKey =
                                      '${widget.post.id}_expanded_$_expanded';
                                  return SelectableText.rich(
                                    key: ValueKey(
                                      contentKey,
                                    ), // ← KEY GOES HERE ON THE WIDGET
                                    TextSpan(
                                      style: const TextStyle(
                                        fontSize: 16,
                                        height: 1.5,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'TwitterChirp',
                                      ),
                                      children: _getCachedSpans(
                                        _expanded
                                            ? widget.post.content
                                            : (widget.post.content.length > 150
                                                  ? '${widget.post.content.substring(0, 150)}...'
                                                  : widget.post.content),
                                      ),
                                    ),
                                    contextMenuBuilder:
                                        (context, editableTextState) {
                                          return AdaptiveTextSelectionToolbar.buttonItems(
                                            anchors: editableTextState
                                                .contextMenuAnchors,
                                            buttonItems: [
                                              ...editableTextState
                                                  .contextMenuButtonItems,
                                              ContextMenuButtonItem(
                                                onPressed: () {
                                                  final selectedText =
                                                      editableTextState
                                                          .textEditingValue
                                                          .selection
                                                          .textInside(
                                                            editableTextState
                                                                .textEditingValue
                                                                .text,
                                                          );
                                                  Clipboard.setData(
                                                    ClipboardData(
                                                      text: selectedText,
                                                    ),
                                                  );
                                                  showDialog(
                                                    context: context,
                                                    builder: (_) => AlertDialog(
                                                      content: const Text(
                                                        'Copied to clipboard!',
                                                      ),
                                                      actions: [
                                                        TextButton(
                                                          onPressed: () =>
                                                              Navigator.pop(
                                                                context,
                                                              ),
                                                          child: const Text(
                                                            'OK',
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                                label: 'Copy',
                                              ),
                                            ],
                                          );
                                        },
                                  );
                                },
                              ),
                              if (widget.post.content.length > 150)
                                GestureDetector(
                                  onTap: () =>
                                      setState(() => _expanded = !_expanded),
                                  child: Text(
                                    _expanded ? 'Show less' : 'Read more',
                                    style: const TextStyle(
                                      color: Colors.blue,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        // === Tagged Users (Pre-fetched usernames) ===
                        if (widget.post.taggedUserIds != null &&
                            widget.post.taggedUserIds!.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Wrap(
                              spacing: 6,
                              runSpacing: 4,
                              children: widget.post.taggedUserIds!.map((
                                userId,
                              ) {
                                final username =
                                    _taggedUsernames[userId] ?? 'Loading...';
                                return Chip(
                                  label: Text(
                                    '@$username',
                                    style: const TextStyle(
                                      color: Colors.blue,
                                      fontSize: 13,
                                    ),
                                  ),
                                  backgroundColor: Colors.blue[50],
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 4,
                                  ),
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                );
                              }).toList(),
                            ),
                          ),
                        // Image (kept logic)
                        // === X.COM-STYLE IMAGE ===
                        if (widget.post.imageUrl != null &&
                            widget.post.imageUrl!.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => FullScreenImage(
                                      imageUrl: widget.post.imageUrl!,
                                    ),
                                  ),
                                );
                              },
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: AspectRatio(
                                  aspectRatio: 16 / 9,
                                  child: RepaintBoundary(
                                    child: CachedNetworkImage(
                                      imageUrl: widget.post.imageUrl!,
                                      fit: BoxFit.cover,
                                      memCacheWidth: 600,
                                      memCacheHeight: 338,
                                      placeholder: (_, _) => Shimmer.fromColors(
                                        baseColor: Colors.grey[300]!,
                                        highlightColor: Colors.grey[100]!,
                                        child: Container(
                                          color: Colors.grey[300],
                                        ),
                                      ),
                                      errorWidget: (_, _, _) => Container(
                                        color: Colors.grey[200],
                                        child: const Icon(
                                          Icons.broken_image,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        // Poll (unchanged)
                        // Poll
                        if (widget.post.pollOptions != null &&
                            widget.post.pollOptions!.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Poll',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF6B7280),
                                    fontFamily: 'Roboto',
                                  ),
                                ),
                                const SizedBox(height: 8),
                                ...widget.post.pollOptions!.asMap().entries.map((
                                  e,
                                ) {
                                  final index = e.key;
                                  final option = e.value;

                                  // Use pre-aggregated count from pollVoteCounts
                                  final voteCount =
                                      widget.post.pollVoteCounts[index] ?? 0;

                                  // Total votes
                                  final totalVotes = widget
                                      .post
                                      .pollVoteCounts
                                      .values
                                      .fold<int>(0, (a, b) => a + b);

                                  // Percentage
                                  final percentage = totalVotes > 0
                                      ? (voteCount / totalVotes * 100)
                                            .toStringAsFixed(1)
                                      : '0.0';

                                  // Did current user vote on this option?
                                  final hasUserVoted =
                                      _localUserVoteIndex != null ||
                                      widget.post.userVoteIndex != null;
                                  final userVotedThisOption =
                                      _localUserVoteIndex == index ||
                                      (widget.post.userVoteIndex == index &&
                                          _localUserVoteIndex == null);

                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 4,
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.stretch,
                                      children: [
                                        ElevatedButton(
                                          onPressed: hasUserVoted
                                              ? null
                                              : () => _voteOnPoll(
                                                  widget.post.id,
                                                  index,
                                                ),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: userVotedThisOption
                                                ? const Color(
                                                    0xFF1DA1F2,
                                                  ).withValues(alpha: 0.7)
                                                : const Color(0xFF1DA1F2),
                                            foregroundColor: Colors.white,
                                            elevation: 0,
                                            padding: const EdgeInsets.symmetric(
                                              vertical: 10,
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Flexible(
                                                child: Text(
                                                  option,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                              Text('$voteCount ($percentage%)'),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        // “You voted” label
                                        if (userVotedThisOption)
                                          Padding(
                                            padding: const EdgeInsets.only(
                                              top: 3,
                                            ),
                                            child: Text(
                                              'You voted',
                                              style: TextStyle(
                                                color: const Color(0xFF1DA1F2),
                                                fontSize: 11,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        LinearProgressIndicator(
                                          value: totalVotes > 0
                                              ? voteCount / totalVotes
                                              : 0.0,
                                          backgroundColor: Colors.grey[200],
                                          valueColor:
                                              const AlwaysStoppedAnimation<
                                                Color
                                              >(Color(0xFF1DA1F2)),
                                          minHeight: 6,
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ),

                        // Action Row
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _iconText(
                                LucideIcons.messageCircle,
                                widget.post.commentCount.toString(),
                                color: const Color(0xFF6B7280),
                                onTap: () => widget.onComment(widget.post),
                              ),
                              _iconText(
                                LucideIcons.repeat,
                                widget.post.repostCount.toString(),
                                color: const Color(0xFF6B7280),
                                onTap: () => widget.onRepost(widget.post),
                              ),
                              _iconText(
                                widget.post.likedByMe
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                widget.post.likeCount.toString(),
                                color: widget.post.likedByMe
                                    ? const Color(0xFFF91880)
                                    : const Color(0xFF6B7280),
                                onTap: () => widget.onLike(widget.post),
                              ),
                              _iconText(
                                LucideIcons.share2,
                                '',
                                color: const Color(0xFF6B7280),
                                onTap: () => widget.onShare(widget.post),
                              ),
                              _iconText(
                                Icons.flag_outlined,
                                '',
                                color: const Color(0xFF6B7280),
                                onTap: _reportPost,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
