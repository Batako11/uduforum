import 'dart:async';
import 'package:flutter/material.dart';
import '/auth/auth_gate.dart'; // where login / main feed redirect happens

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  int activeDot = 0;
  late Timer _timer;

  @override
  void initState() {
    super.initState();

    // Animate dots like in HTML
    _timer = Timer.periodic(const Duration(milliseconds: 1000), (timer) {
      if (activeDot < 3) {
        setState(() => activeDot++);
      } else {
        _timer.cancel();
        // Navigate to AuthGate (which decides LoginScreen or MainFeedScreen)
        Future.delayed(const Duration(milliseconds: 1000), () {
          if (!mounted) return; // <-- ensures context is safe
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const AuthGate()),
          );
        });
      }
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Neon UDUS FORUM text
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: "UDUS FORUM".split("").map((char) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: Text(
                    char,
                    style: TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                      color: Colors.black87,
                      shadows: [
                        Shadow(
                          blurRadius: 15,
                          color: Colors.black26,
                          offset: const Offset(0, 0),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 30),

            // Loading dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(4, (i) {
                return AnimatedOpacity(
                  duration: const Duration(milliseconds: 500),
                  opacity: i <= activeDot ? 1.0 : 0.2,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: 10,
                    height: 10,
                    decoration: const BoxDecoration(
                      color: Colors.black87,
                      shape: BoxShape.circle,
                    ),
                  ),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}
