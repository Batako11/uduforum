import 'dart:async';
import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'trinity_oracle.dart';

/// === Message Model ===
class Message {
  final String sender; // "user" or "trinity"
  final String text;

  Message({required this.sender, required this.text});
}

/// === Trinity Chat Screen (White & Clean) ===
class TrinityChatScreen extends StatefulWidget {
  final bool isVerified;

  const TrinityChatScreen({super.key, this.isVerified = false});

  @override
  State<TrinityChatScreen> createState() => _TrinityChatScreenState();
}

class _TrinityChatScreenState extends State<TrinityChatScreen> {
  final List<Message> _messages = [];
  final TextEditingController _controller = TextEditingController();
  bool _isTyping = false;
  int _queriesLeft = 5;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // === Handle message send ===
  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      showToast('Login to chat with Trinity');
      return;
    }

    // === DAILY LIMIT (NON-VERIFIED) ===
    if (!widget.isVerified && _queriesLeft <= 0) {
      setState(() {
        _messages.add(
          Message(
            sender: "trinity",
            text: "Daily limit reached. Verify for unlimited access.",
          ),
        );
      });
      return;
    }
    if (!widget.isVerified) setState(() => _queriesLeft--);

    // === ADD USER MESSAGE ===
    setState(() {
      _messages.add(Message(sender: "user", text: text.trim()));
      _controller.clear();
      _isTyping = true;
    });

    // === GLITCH EFFECT ===
    await Future.delayed(const Duration(milliseconds: 600));
    setState(() {
      _messages.add(Message(sender: "trinity", text: "SCANNED"));
    });
    await Future.delayed(const Duration(seconds: 1));

    // === GET USER VERIFICATION FROM DB ===
    final userData = await supabase
        .from('users')
        .select('blue_tick, gold_tick')
        .eq('id', userId)
        .single();

    final isVerified =
        (userData['blue_tick'] == true) || (userData['gold_tick'] == true);

    final oracle = TrinityOracle();
    final reply = isVerified
        ? oracle.getResponse(text.trim())
        : "Access denied. Only **verified** users can speak to Trinity.";

    // === FINAL REPLY ===
    setState(() {
      _isTyping = false;
      _messages.removeLast();
      _messages.add(Message(sender: "trinity", text: reply));
    });
  }

  /// === Chat Bubble ===
  Widget _buildMessageBubble(Message msg) {
    final isUser = msg.sender == "user";
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        padding: const EdgeInsets.all(14),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.75,
        ),
        decoration: BoxDecoration(
          color: isUser ? const Color(0xFF1E88E5) : Colors.grey[100],
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Text(
          msg.text,
          style: TextStyle(
            color: isUser ? Colors.white : Colors.black87,
            fontSize: 15,
            height: 1.3,
          ),
        ),
      ),
    );
  }

  /// === Typing Indicator ===
  Widget _buildTypingIndicator() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            return Padding(
              padding: const EdgeInsets.only(right: 4),
              child: AnimatedContainer(
                duration: Duration(milliseconds: 300 + i * 100),
                curve: Curves.easeInOut,
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: Colors.grey[400],
                  shape: BoxShape.circle,
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // WHITE BG
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          "Trinity",
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black54),
      ),
      body: Column(
        children: [
          // Query limit banner
          if (!widget.isVerified)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              color: _queriesLeft > 0 ? Colors.blue[50] : Colors.red[50],
              child: Text(
                _queriesLeft > 0
                    ? "Queries left today: $_queriesLeft / 5"
                    : "Daily limit reached. Verify to unlock unlimited access.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _queriesLeft > 0 ? Colors.blue[700] : Colors.red[700],
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),

          // Chat messages
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.only(top: 8),
              itemCount: _messages.length + (_isTyping ? 1 : 0),
              itemBuilder: (context, index) {
                if (_isTyping && index == _messages.length) {
                  return _buildTypingIndicator();
                }
                return _buildMessageBubble(_messages[index]);
              },
            ),
          ),

          // Input bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.08),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(fontSize: 15),
                    decoration: InputDecoration(
                      hintText: "Ask Trinity anything...",
                      hintStyle: TextStyle(color: Colors.grey[500]),
                      filled: true,
                      fillColor: Colors.grey[50],
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onSubmitted: _sendMessage,
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(
                  radius: 22,
                  backgroundColor: const Color(0xFF1E88E5),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 20),
                    onPressed: () => _sendMessage(_controller.text),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
