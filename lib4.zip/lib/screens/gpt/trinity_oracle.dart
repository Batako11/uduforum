// lib/services/trinity_oracle.dart
class TrinityOracle {
  // Trinity's REAL Supabase user ID
  static const String trinityUserId = '6f31f4dc-7944-4224-a049-98a9cc971d67';

  // Singleton
  static final TrinityOracle _instance = TrinityOracle._internal();
  factory TrinityOracle() => _instance;
  TrinityOracle._internal();

  String getResponse(String query) {
    final q = query.toLowerCase().trim();

    if (q.isEmpty || q == "summon") {
      return "Trinity summoned. I am the Oracle of UDUS. "
          "Ask about: registration, exams, hostel, SUG, rumors. "
          "What truth do you seek?";
    }

    if (q.contains('registration') || q.contains('course')) {
      return "Course registration closes **Friday, Nov 22 @ 11:59 PM**. "
          "Portal: **portal.udusok.edu.ng** | Late fee: ₦5,000. "
          "[Registrar Notice #2025/47]";
    }

    if (q.contains('exam') || q.contains('timetable')) {
      return "Second Semester exams: **Dec 9 – Dec 20**. "
          "Timetable in all departments. "
          "Check HOD office or SUG group. [Updated 2 hrs ago]";
    }

    if (q.contains('hostel') || q.contains('accommodation')) {
      return "Hostel ballot result: **OUT**. "
          "Check **hostel.udusok.edu.ng** | Pay by **Nov 25**. "
          "Off-campus? Try **Danfodiyo Hostel**.";
    }

    if (q.contains('sug') || q.contains('election')) {
      return "SUG Election: **Dec 5**. "
          "Candidates: Aisha (President), Musa (VP). "
          "Voting via **UDUS e-Vote app**. "
          "Manifesto debate tomorrow @ Auditorium.";
    }

    if (q.contains('vc') && q.contains('ban')) {
      return "FALSE: VC did **not** ban phones. "
          "Silent mode only. "
          "Rumor from fake post → [Post #8921]. "
          "Official: [Admin Notice #119].";
    }

    if (q.contains('grant') || q.contains('100k')) {
      return "SCAM ALERT: No ₦100k grant. "
          "Admin never announced. "
          "Report to **security@udusok.edu.ng**.";
    }

    if (q.contains('library') || q.contains('book')) {
      return "Main Library open **7 AM – 10 PM**. "
          "E-library: **Floor 3**. "
          "Borrow 3 books max. Fines: ₦50/day.";
    }

    if (q.contains('cafeteria') || q.contains('food')) {
      return "Mama Put (behind Faculty of Science): "
          "Jollof + Chicken = ₦400. "
          "Open till 8 PM. Avoid 'Indomie joint' — overpriced.";
    }

    return "I scanned the forum, notices, and admin posts. "
        "No match for: \"$query\". "
        "Try: registration, exams, hostel, or rumors. "
        "Or post in **#general**.";
  }
}
