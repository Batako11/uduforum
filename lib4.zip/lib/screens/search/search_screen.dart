import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';
import '/models/post_model.dart';
import '../widgets/native_ad_widget.dart';
import '../feed/post_card.dart';
import '../comment/comment_screen.dart';
import '../profile/other_user_profile_screen.dart';
import '../channel/channel_feed_screen.dart';
import '../dept/department_selection_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  final supabase = Supabase.instance.client;

  String _query = '';
  bool _isSearching = false;
  bool _loading = true;

  // Results
  List<Map<String, dynamic>> _users = [];
  List<Post> _posts = [];
  List<Map<String, dynamic>> _departments = [];
  List<Map<String, dynamic>> _channels = [];

  // Explore
  List<String> _trendingHashtags = [];
  List<Map<String, dynamic>> _suggestedUsers = [];
  List<Map<String, dynamic>> _activeChannels = [];

  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _loadInitialData();
    _controller.addListener(() {
      setState(() => _query = _controller.text.trim());
      if (_query.isEmpty) {
        _clearResults();
      } else {
        _debounce?.cancel();
        _debounce = Timer(const Duration(milliseconds: 400), _search);
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  // MARK: - Data Loading
  Future<void> _loadInitialData() async {
    setState(() => _loading = true);
    await Future.wait([
      _fetchTrendingHashtags(),
      _fetchSuggestedUsers(),
      _fetchActiveChannels(),
    ]);
    setState(() => _loading = false);
  }

  Future<void> _search() async {
    if (_query.isEmpty) return;
    setState(() => _isSearching = true);
    try {
      await Future.wait([
        _searchUsers(),
        _searchPosts(),
        _searchDepartments(),
        _searchChannels(),
      ]);
    } catch (e) {
      showToast('Search failed: $e');
    } finally {
      if (mounted) setState(() => _isSearching = false);
    }
  }

  void _clearResults() {
    setState(() {
      _users.clear();
      _posts.clear();
      _departments.clear();
      _channels.clear();
    });
  }

  // MARK: - Search Queries
  Future<void> _searchUsers() async {
    final res = await supabase
        .from('users')
        .select('id, username, handle, profile_image_url, level')
        .or('username.ilike.%$_query%,handle.ilike.%$_query%')
        .limit(3);
    _users = List<Map<String, dynamic>>.from(res);
  }

  Future<void> _searchPosts() async {
    final userId = supabase.auth.currentUser?.id;
    final res = await supabase
        .from('posts')
        .select('''
          id, user_id, content, image_url, created_at, channel_id,
          users!inner(username, profile_image_url),
          likes!post_id(count), comments!post_id(count), reposts!post_id(count),
          liked_by_me:likes!post_id(user_id)
        ''')
        .textSearch('content', _query)
        .order('created_at', ascending: false)
        .limit(10);

    _posts = (res as List).map((map) {
      // FIX: Supabase sometimes returns bool instead of List for empty left joins
      final likedRaw = map['liked_by_me'];
      final bool likedByMe = likedRaw is List
          ? likedRaw.isNotEmpty
          : (likedRaw == true); // handles rare bool true, otherwise false

      // Create a safe map that Post.fromMap can handle without crashing
      final safeMap = Map<String, dynamic>.from(map);
      safeMap['liked_by_me'] = likedByMe ? [{}] : <dynamic>[];
      safeMap['reposted_by_me'] = <dynamic>[]; // always false in search
      safeMap['is_trending'] = false;

      return Post.fromMap(safeMap, currentUserId: userId);
    }).toList();
  }

  Future<void> _searchDepartments() async {
    final res = await supabase
        .from('departments')
        .select('id, name')
        .ilike('name', '%$_query%')
        .limit(2);
    _departments = List<Map<String, dynamic>>.from(res);
  }

  Future<void> _searchChannels() async {
    final res = await supabase
        .from('channels')
        .select('id, name, profile_image_url, followers')
        .ilike('name', '%$_query%')
        .order('followers', ascending: false)
        .limit(3);
    _channels = List<Map<String, dynamic>>.from(res);
  }

  // MARK: - Explore Data
  Future<void> _fetchTrendingHashtags() async {
    final now = DateTime.now().toIso8601String();
    final res = await supabase
        .from('trending_hashtags')
        .select('hashtag')
        .lte('start_date', now)
        .gte('end_date', now)
        .limit(3);
    _trendingHashtags = (res as List).map((e) => '#${e['hashtag']}').toList();
  }

  Future<void> _fetchSuggestedUsers() async {
    final res = await supabase
        .from('users')
        .select('id, username, handle, profile_image_url, level')
        .neq('id', supabase.auth.currentUser?.id ?? '')
        .order('level', ascending: false)
        .limit(3);
    _suggestedUsers = List<Map<String, dynamic>>.from(res);
  }

  Future<void> _fetchActiveChannels() async {
    final res = await supabase
        .from('channels')
        .select('id, name, profile_image_url, followers')
        .order('followers', ascending: false)
        .limit(3);
    _activeChannels = List<Map<String, dynamic>>.from(res);
  }

  // MARK: - Navigation & Actions
  Future<void> _openCommentScreen(Post post) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CommentScreen(
          post: post,
          currentUserId: supabase.auth.currentUser?.id,
          onLike: (_) async => showToast('Like not available in search'),
          onRepost: (_) async => showToast('Repost not available in search'),
          onShare: (_) async => showToast('Share not available in search'),
          onEdit: (_) async => showToast('Edit not available'),
          onDelete: (_) async => showToast('Delete not available'),
          onProfileTap: _navigateToProfile,
          onError: (_) => showToast('Error'),
          onBoost: (_, _, _) async => showToast('Boost not available'),
          isTrending: false,
        ),
      ),
    );
    if (mounted) await _searchPosts();
  }

  void _navigateToProfile(String userId) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => OtherUserProfileScreen(userId: userId)),
    );
  }

  // MARK: - UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true, // Important for keyboard + banner

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1E88E5)),
          onPressed: () => Navigator.pop(context),
        ),
        title: TextField(
          controller: _controller,
          focusNode: _focusNode,
          autofocus: true,
          decoration: InputDecoration(
            hintText: 'Search users, posts, departments...',
            border: InputBorder.none,
            hintStyle: TextStyle(color: Colors.grey[600], fontSize: 16),
          ),
          style: const TextStyle(fontSize: 16, fontFamily: 'Roboto'),
        ),
        actions: [
          if (_query.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear, color: Colors.black87),
              onPressed: () {
                _controller.clear();
                _clearResults();
              },
            ),
        ],
      ),

      // MAIN CONTENT
      body: _loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : _query.isEmpty
          ? _buildExploreView()
          : _isSearching
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : _buildSearchResults(),

      // FIXED BANNER AD AT BOTTOM – NEVER MOVES
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(
                    height: 0.5,
                    color: Colors.grey[300],
                  ), // subtle separator
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }

  Widget _buildExploreView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_trendingHashtags.isNotEmpty) ...[
            const Text(
              'Trending Now',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: _trendingHashtags
                  .map(
                    (tag) => Chip(
                      label: Text(tag, style: const TextStyle(fontSize: 13)),
                      backgroundColor: Colors.blue.withValues(alpha: 0.1),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 24),
          ],
          if (_suggestedUsers.isNotEmpty) ...[
            const Text(
              'Suggested Users',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            ..._suggestedUsers.map(_userTile),
            const SizedBox(height: 24),
          ],
          if (_activeChannels.isNotEmpty) ...[
            const Text(
              'Active Channels',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            ..._activeChannels.map(_channelTile),
          ],
        ],
      ),
    );
  }

  Widget _buildSearchResults() {
    final adManager = AdManager();

    // Build mixed list: real posts + native ads (only in Posts section)
    final List<Widget> postItems = [];
    for (int i = 0; i < _posts.length; i++) {
      // Insert your beautiful native ad using your existing logic
      if (adManager.shouldShowNativeAd(i)) {
        postItems.add(
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: NativeAdWidget(),
          ),
        );
      }

      // Add the real post
      final post = _posts[i];
      postItems.add(
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: PostCard(
            post: post,
            currentUserId: supabase.auth.currentUser?.id,
            onComment: (_) async => _openCommentScreen(post),
            onLike: (_) async => showToast('Like not available in search'),
            onRepost: (_) async => showToast('Repost not available in search'),
            onShare: (_) async => showToast('Share not available in search'),
            onEdit: (_) async => showToast('Edit not available'),
            onDelete: (_) async => showToast('Delete not available'),
            onProfileTap: (_) => _navigateToProfile(post.userId),
            onError: (_) => showToast('Error'),
            onBoost: (_, _, _) async => showToast('Boost not available'),
            isTrending: false,
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.only(bottom: 90),
      children: [
        // Users
        if (_users.isNotEmpty) ...[
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Text('Users', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          ..._users.map(_userTile),
        ],

        // Posts + Native Ads mixed perfectly
        if (postItems.isNotEmpty) ...[
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Text('Posts', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          ...postItems,
        ],

        // Departments
        if (_departments.isNotEmpty) ...[
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Text(
              'Departments',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          ..._departments.map(
            (dept) => ListTile(
              leading: const Icon(Icons.school, color: Colors.blue),
              title: Text(dept['name']),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DepartmentSelectionScreen(),
                ),
              ),
            ),
          ),
        ],

        // Channels
        if (_channels.isNotEmpty) ...[
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Text(
              'Channels',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          ..._channels.map(_channelTile),
        ],

        // No results
        if (_users.isEmpty &&
            _posts.isEmpty &&
            _departments.isEmpty &&
            _channels.isEmpty)
          const Padding(
            padding: EdgeInsets.all(32),
            child: Center(
              child: Text(
                'No results found',
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ),
      ],
    );
  }

  Widget _userTile(Map<String, dynamic> user) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: user['profile_image_url'] != null
            ? NetworkImage(user['profile_image_url'])
            : null,
        child: user['profile_image_url'] == null
            ? Text(user['username']?[0].toUpperCase() ?? 'U')
            : null,
      ),
      title: Text(
        user['username'],
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
      subtitle: Text(
        '@${user['handle']}',
        style: TextStyle(color: Colors.grey[600]),
      ),
      trailing: user['level'] != null
          ? Text(
              'Lvl ${user['level']}',
              style: const TextStyle(color: Colors.blue),
            )
          : null,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OtherUserProfileScreen(userId: user['id']),
        ),
      ),
    );
  }

  Widget _channelTile(Map<String, dynamic> channel) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: channel['profile_image_url'] != null
            ? NetworkImage(channel['profile_image_url'])
            : null,
        child: channel['profile_image_url'] == null
            ? const Icon(Icons.campaign, color: Color(0xFF1DA1F2))
            : null,
      ),
      title: Text(
        channel['name'],
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
      subtitle: Text('${channel['followers']?.length ?? 0} followers'),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChannelFeedScreen(channelId: channel['id']),
        ),
      ),
    );
  }
}
