// lib/screens/leaderboard_screen.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Top Contributors',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        elevation: 0.5,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: Supabase.instance.client
            .from('materials')
            .stream(primaryKey: ['id'])
            .map((data) {
              // Group by uploader and count uploads
              final Map<String, Map<String, dynamic>> users = {};

              for (var item in data) {
                final uploaderId = item['uploader_id'] as String?;
                final name = (item['uploader_name'] ?? 'Anonymous') as String;
                final avatar = item['uploader_avatar'] as String?;

                if (uploaderId != null) {
                  if (!users.containsKey(uploaderId)) {
                    users[uploaderId] = {
                      'uploader_id': uploaderId,
                      'uploader_name': name,
                      'uploader_avatar': avatar,
                      'upload_count': 0,
                    };
                  }
                  users[uploaderId]!['upload_count'] += 1;
                }
              }

              return users.values.toList()..sort(
                (a, b) => b['upload_count'].compareTo(a['upload_count']),
              );
            }),
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.emoji_events_outlined,
                    size: 80,
                    color: Colors.amber,
                  ),
                  SizedBox(height: 16),
                  Text('No uploads yet', style: TextStyle(fontSize: 18)),
                  Text('Be the first to upload and claim #1!'),
                ],
              ),
            );
          }

          final leaders = snapshot.data!;

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: leaders.length,
            itemBuilder: (context, index) {
              final user = leaders[index];
              final rank = index + 1;
              final isTop3 = rank <= 3;

              return Card(
                elevation: isTop3 ? 8 : 2,
                color: isTop3
                    ? (rank == 1
                          ? Colors.amber.shade50
                          : rank == 2
                          ? Colors.grey.shade200
                          : Colors.brown.shade100)
                    : null,
                child: ListTile(
                  leading: Stack(
                    children: [
                      CircleAvatar(
                        radius: 26,
                        backgroundImage: user['uploader_avatar'] != null
                            ? NetworkImage(user['uploader_avatar'])
                            : null,
                        child: user['uploader_avatar'] == null
                            ? Text(
                                user['uploader_name'][0].toUpperCase(),
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            : null,
                      ),
                      if (isTop3)
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: CircleAvatar(
                            radius: 14,
                            backgroundColor: rank == 1
                                ? Colors.amber
                                : rank == 2
                                ? Colors.grey
                                : Colors.brown,
                            child: Text(
                              '$rank',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  title: Text(
                    user['uploader_name'],
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('${user['upload_count']} uploads'),
                  trailing: isTop3
                      ? Icon(
                          rank == 1 ? Icons.emoji_events : Icons.star,
                          color: rank == 1 ? Colors.amber : Colors.orange,
                          size: 32,
                        )
                      : null,
                ),
              );
            },
          );
        },
      ),
    );
  }
}
