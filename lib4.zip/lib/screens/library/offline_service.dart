// lib/services/offline_service.dart
// Forwarder to the shared offline service implementation.
export '../../services/offline_service.dart';
