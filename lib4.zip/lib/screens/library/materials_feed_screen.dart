// lib/screens/materials/materials_feed_screen.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/material_service.dart';
import '../Profile/profile_screen.dart';
import 'leaderboard_screen.dart';
import '../widgets/material_card.dart';
import '../../models/material_model.dart';
import 'my_bookmarks_screen.dart';
import 'upload_material_screen.dart';
import 'material_detail_screen.dart';

class MaterialsFeedScreen extends StatefulWidget {
  const MaterialsFeedScreen({super.key});

  @override
  State<MaterialsFeedScreen> createState() => _MaterialsFeedScreenState();
}

class _MaterialsFeedScreenState extends State<MaterialsFeedScreen> {
  final MaterialService _service = MaterialService();
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  Set<String> _bookmarkedIds = {};
  int _currentTabIndex = 0;

  // All 4 screens
  late final List<Widget> _tabScreens;

  @override
  void initState() {
    super.initState();
    _loadBookmarks();
    _searchController.addListener(() {
      setState(() => _searchQuery = _searchController.text.toLowerCase());
    });

    // Define all tabs once
    _tabScreens = [
      _buildMaterialsTab(), // Tab 0
      const LeaderboardScreen(), // Tab 1
      const MyBookmarksScreen(), // Tab 2
      const ProfileScreen(), // Tab 3
    ];
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadBookmarks() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final response = await Supabase.instance.client
          .from('bookmarks')
          .select('material_id')
          .eq('user_id', userId);

      setState(() {
        _bookmarkedIds = response
            .map((e) => e['material_id'] as String)
            .toSet();
      });
    } catch (e) {
      debugPrint('No bookmarks yet: $e');
    }
  }

  Future<void> _toggleBookmark(String materialId) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    final wasBookmarked = _bookmarkedIds.contains(materialId);

    setState(() {
      if (wasBookmarked) {
        _bookmarkedIds.remove(materialId);
      } else {
        _bookmarkedIds.add(materialId);
      }
    });

    try {
      if (wasBookmarked) {
        await Supabase.instance.client.from('bookmarks').delete().match({
          'user_id': userId,
          'material_id': materialId,
        });
      } else {
        await Supabase.instance.client.from('bookmarks').insert({
          'user_id': userId,
          'material_id': materialId,
        });
      }
    } catch (e) {
      setState(() => _bookmarkedIds = wasBookmarked ? {materialId} : {});
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Bookmark failed: $e')));
    }
  }

  // This is your original Materials tab content
  Widget _buildMaterialsTab() {
    return Column(
      children: [
        // MOST DOWNLOADED THIS WEEK BANNER
        StreamBuilder<List<MaterialModel>>(
          stream: _service.streamTopDownloadsThisWeek(),
          builder: (context, snapshot) {
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const SizedBox.shrink();
            }
            final topMaterials = snapshot.data!.take(6).toList();

            return Container(
              height: 160,
              margin: const EdgeInsets.all(12),
              child: Card(
                color: Colors.orange.shade50,
                elevation: 6,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                      child: Row(
                        children: const [
                          Icon(Icons.whatshot, color: Colors.red, size: 28),
                          SizedBox(width: 8),
                          Text(
                            'Most Downloaded This Week',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: Colors.red,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        itemCount: topMaterials.length,
                        itemBuilder: (context, index) {
                          final m = topMaterials[index];
                          return SizedBox(
                            width: 240,
                            height: 104,
                            child: Card(
                              margin: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 6,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: InkWell(
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        MaterialDetailScreen(material: m),
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      // Thumbnail / icon
                                      Container(
                                        width: 56,
                                        height: 56,
                                        decoration: BoxDecoration(
                                          color: Colors.orange.shade100,
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                        ),
                                        child: Center(
                                          child: Icon(
                                            Icons.menu_book,
                                            color: Colors.deepOrange,
                                            size: 30,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 12),

                                      // Title & course
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              m.title,
                                              style: const TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w600,
                                              ),
                                              maxLines: 3,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            const SizedBox(height: 6),
                                            Text(
                                              m.courseCode,
                                              style: const TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      const SizedBox(width: 8),

                                      // Downloads badge + CTA
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                              vertical: 6,
                                            ),
                                            decoration: BoxDecoration(
                                              color: Colors.red.shade50,
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                            child: Text(
                                              m.downloadsCount > 9999
                                                  ? '${(m.downloadsCount / 1000).toStringAsFixed(1)}k'
                                                  : '${m.downloadsCount}',
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: Colors.red,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: 8),
                                          SizedBox(
                                            width: 72,
                                            child: OutlinedButton(
                                              onPressed: () => Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (_) =>
                                                      MaterialDetailScreen(
                                                        material: m,
                                                      ),
                                                ),
                                              ),
                                              style: OutlinedButton.styleFrom(
                                                side: BorderSide(
                                                  color: Colors.red.shade200,
                                                ),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                ),
                                              ),
                                              child: const Text(
                                                'View',
                                                style: TextStyle(fontSize: 12),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),

        // MAIN MATERIALS FEED
        Expanded(
          child: StreamBuilder<List<MaterialModel>>(
            stream: _service.streamMaterials(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }

              var materials = snapshot.data!;

              if (_searchQuery.isNotEmpty) {
                materials = materials
                    .where(
                      (m) =>
                          m.courseCode.toLowerCase().contains(_searchQuery) ||
                          m.title.toLowerCase().contains(_searchQuery),
                    )
                    .toList();
              }

              if (materials.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.menu_book_outlined,
                        size: 80,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _searchQuery.isNotEmpty
                            ? 'No materials found'
                            : 'No materials yet',
                        style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                      ),
                      if (_searchQuery.isEmpty)
                        const Text('Be the first to upload!'),
                    ],
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.only(top: 8, bottom: 90),
                itemCount: materials.length,
                itemBuilder: (context, index) {
                  final material = materials[index];
                  final isBookmarked = _bookmarkedIds.contains(material.id);

                  return Stack(
                    children: [
                      MaterialCard(material: material),
                      Positioned(
                        top: 12,
                        right: 20,
                        child: IconButton(
                          icon: Icon(
                            isBookmarked
                                ? Icons.bookmark
                                : Icons.bookmark_outline,
                            color: isBookmarked
                                ? Colors.blue
                                : Colors.grey[600],
                            size: 28,
                          ),
                          onPressed: () => _toggleBookmark(material.id),
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _currentTabIndex == 0
          ? AppBar(
              backgroundColor: Colors.white,
              elevation: 0.5,
              title: const Text(
                'Library',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              centerTitle: true,
              bottom: PreferredSize(
                preferredSize: const Size.fromHeight(70),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: 'Search course code, title...',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _searchQuery.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                _searchController.clear();
                                setState(() => _searchQuery = '');
                              },
                            )
                          : null,
                      filled: true,
                      fillColor: Colors.grey[100],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
              ),
            )
          : null, // Hide AppBar on other tabs

      body: IndexedStack(index: _currentTabIndex, children: _tabScreens),

      floatingActionButton: _currentTabIndex == 0
          ? FloatingActionButton(
              backgroundColor: Colors.black,
              foregroundColor: Colors.white,
              elevation: 8,
              onPressed: () async {
                final uploaded = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const UploadMaterialScreen(),
                  ),
                );
                if (uploaded == true) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      backgroundColor: Colors.green,
                      content: Text('Uploaded successfully!'),
                    ),
                  );
                }
              },
              child: const Icon(Icons.add, size: 32),
            )
          : null,

      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTabIndex,
        onTap: (index) => setState(() => _currentTabIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.menu_book_outlined),
            activeIcon: Icon(Icons.menu_book),
            label: 'Library',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.leaderboard_outlined),
            activeIcon: Icon(Icons.leaderboard),
            label: 'Leaderboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bookmark_outline),
            activeIcon: Icon(Icons.bookmark),
            label: 'Bookmarks',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
