// lib/screens/materials/material_detail_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'package:open_file/open_file.dart';
import '../../models/material_model.dart';
import '../../services/material_service.dart';
import '../../services/offline_service.dart'; // ← ADD THIS
// hive listenable used via OfflineService; no direct hive import needed here

class MaterialDetailScreen extends StatefulWidget {
  final MaterialModel material;
  const MaterialDetailScreen({super.key, required this.material});

  @override
  State<MaterialDetailScreen> createState() => _MaterialDetailScreenState();
}

class _MaterialDetailScreenState extends State<MaterialDetailScreen> {
  bool _isDownloading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.material.courseCode),
        actions: [
          ValueListenableBuilder(
            valueListenable: OfflineService.listenable,
            builder: (context, box, _) {
              final localPath = OfflineService.getLocalPath(widget.material.id);
              final downloaded = localPath != null;

              return IconButton(
                icon: _isDownloading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : Icon(
                        downloaded ? Icons.offline_pin : Icons.download,
                        color: downloaded ? Colors.green : Colors.white,
                      ),
                onPressed: downloaded
                    ? () async {
                        final path = OfflineService.getLocalPath(
                          widget.material.id,
                        );
                        if (path != null) {
                          await OpenFile.open(path);
                        }
                      }
                    : () async {
                        setState(() => _isDownloading = true);
                        try {
                          await OfflineService.downloadMaterial(
                            widget.material.id,
                            widget.material.fileUrl,
                            widget.material.title,
                          );
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Download started')),
                            );
                          }
                        } catch (e) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Download failed: $e')),
                            );
                          }
                        } finally {
                          if (mounted) setState(() => _isDownloading = false);
                        }
                      },
              );
            },
          ),
        ],
      ),
      body: ValueListenableBuilder(
        valueListenable: OfflineService.listenable,
        builder: (context, box, _) {
          final path = OfflineService.getLocalPath(widget.material.id);
          if (path != null) {
            return Column(
              children: [
                Expanded(
                  child: SfPdfViewer.file(
                    File(path),
                    canShowScrollHead: false,
                    canShowPaginationDialog: true,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ElevatedButton.icon(
                        icon: const Icon(Icons.open_in_new),
                        label: const Text('Open with system app'),
                        onPressed: () async {
                          final p = OfflineService.getLocalPath(
                            widget.material.id,
                          );
                          if (p != null) await OpenFile.open(p);
                        },
                      ),
                    ],
                  ),
                ),
              ],
            );
          }

          return SfPdfViewer.network(
            widget.material.fileUrl,
            canShowScrollHead: false,
            canShowPaginationDialog: true,
            onDocumentLoaded: (_) {
              MaterialService().incrementDownload(widget.material.id);
            },
          );
        },
      ),
    );
  }
}
