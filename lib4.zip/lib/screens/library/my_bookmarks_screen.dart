// lib/screens/materials/my_bookmarks_screen.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../models/material_model.dart';
import '../widgets/material_card.dart';

class MyBookmarksScreen extends StatelessWidget {
  const MyBookmarksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final userId = Supabase.instance.client.auth.currentUser?.id;

    if (userId == null) {
      return const Scaffold(
        body: Center(child: Text('Please log in to see your bookmarks')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'My Bookmarks',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        elevation: 0.5,
      ),
      body: StreamBuilder(
        stream: Supabase.instance.client
            .from('bookmarks')
            .stream(primaryKey: ['user_id', 'material_id'])
            .eq('user_id', userId)
            .order('created_at', ascending: false),
        builder: (context, AsyncSnapshot<List<Map<String, dynamic>>> snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.bookmark_border,
                    size: 80,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'No bookmarks yet',
                    style: TextStyle(fontSize: 18),
                  ),
                  const Text(
                    'Tap the bookmark icon on any material to save it here',
                  ),
                ],
              ),
            );
          }

          final bookmarkEntries = snapshot.data!;
          final materialIds = bookmarkEntries
              .map((e) => e['material_id'] as String)
              .toList();

          // Now fetch the actual materials
          return StreamBuilder<List<MaterialModel>>(
            stream: Supabase.instance.client
                .from('materials')
                .stream(primaryKey: ['id'])
                .inFilter('id', materialIds)
                .order('created_at', ascending: false)
                .map(
                  (data) =>
                      data.map((json) => MaterialModel.fromMap(json)).toList(),
                ),
            builder: (context, materialSnapshot) {
              if (materialSnapshot.hasError) {
                return Center(child: Text('Error loading materials'));
              }
              if (!materialSnapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }

              final materials = materialSnapshot.data!;

              if (materials.isEmpty) {
                return const Center(
                  child: Text('Bookmarked materials not found'),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.only(top: 8, bottom: 80),
                itemCount: materials.length,
                itemBuilder: (context, index) {
                  final material = materials[index];
                  return Stack(
                    children: [
                      MaterialCard(material: material),
                      Positioned(
                        top: 12,
                        right: 20,
                        child: IconButton(
                          icon: const Icon(
                            Icons.bookmark,
                            color: Colors.blue,
                            size: 28,
                          ),
                          onPressed: () async {
                            await Supabase.instance.client
                                .from('bookmarks')
                                .delete()
                                .match({
                                  'user_id': userId,
                                  'material_id': material.id,
                                });
                          },
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
