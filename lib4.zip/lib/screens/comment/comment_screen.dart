import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:oktoast/oktoast.dart';
import '../../services/ad_manager.dart';
import '../../services/image_cache_service.dart';
import '../gpt/trinity_oracle.dart';
import '../widgets/native_ad_widget.dart';
import '/models/post_model.dart';
import '../feed/post_card.dart';
import '../profile/other_user_profile_screen.dart';

class CommentScreen extends StatefulWidget {
  final Post post;
  final String? currentUserId;
  final Future<void> Function(Post) onLike;
  final Future<void> Function(Post) onRepost;
  final Future<void> Function(Post) onShare;
  final Future<void> Function(Post) onEdit;
  final Future<void> Function(Post) onDelete;
  final void Function(String) onProfileTap;
  final void Function(String) onError;
  final Future<void> Function(Post, int, int) onBoost;
  final bool isTrending;

  const CommentScreen({
    super.key,
    required this.post,
    required this.currentUserId,
    required this.onLike,
    required this.onRepost,
    required this.onShare,
    required this.onEdit,
    required this.onDelete,
    required this.onProfileTap,
    required this.onError,
    required this.onBoost,
    required this.isTrending,
  });

  @override
  State<CommentScreen> createState() => _CommentScreenState();
}

class _CommentScreenState extends State<CommentScreen>
    with TickerProviderStateMixin {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();
  bool _isSending = false;
  bool _hasError = false;
  List<Map<String, dynamic>> _comments = [];
  String? _replyToCommentId;
  String? _replyToUsername;
  late AnimationController _animationController;
  late Animation<double> _animation;
  RealtimeChannel? _commentSubscription;

  @override
  void initState() {
    super.initState();
    _fetchComments();
    _setupRealtimeSubscription();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  Future<void> _fetchComments() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      // Fetch comments without joining users
      final commentsData = await Supabase.instance.client
          .from('comments')
          .select('id, post_id, user_id, content, created_at, parent_id')
          .eq('post_id', widget.post.id)
          .order('created_at', ascending: false);

      // Fetch user data from public.users
      final userIds = commentsData
          .map((c) => c['user_id'] as String?)
          .toSet()
          .whereType<String>()
          .toList();
      Map<String, dynamic> users = {};
      if (userIds.isNotEmpty) {
        final userResponse = await Supabase.instance.client
            .from('users')
            .select(
              'id, username, handle, profile_image_url, blue_tick, gold_tick',
            )
            .inFilter('id', userIds);
        users = Map.fromEntries(userResponse.map((u) => MapEntry(u['id'], u)));
      }

      // Fetch comment likes without selecting id column
      final commentIds = commentsData.map((c) => c['id'] as String).toList();
      List<Map<String, dynamic>> likesData = [];
      if (commentIds.isNotEmpty) {
        likesData = await Supabase.instance.client
            .from('comment_likes')
            .select('user_id, comment_id')
            .inFilter('comment_id', commentIds);
      }

      final commentsWithUsers = commentsData.map((c) {
        final cCopy = Map<String, dynamic>.from(c);
        final commentLikes = likesData
            .where((like) => like['comment_id'] == c['id'])
            .toList();
        cCopy['like_count'] = commentLikes.length;
        cCopy['is_liked'] =
            userId != null &&
            commentLikes.any((like) => like['user_id'] == userId);
        cCopy['users'] = c['user_id'] != null
            ? users[c['user_id']] ??
                  {'username': 'Unknown', 'handle': 'unknown'}
            : {'username': 'Unknown', 'handle': 'unknown'};
        return cCopy;
      }).toList();

      if (mounted) {
        setState(() {
          _comments = commentsWithUsers;
          _hasError = false;
        });

        // Pre-cache avatars AFTER comments are ready
        final avatarUrls = _comments
            .map((c) => c['users']?['profile_image_url'] as String?)
            .where((url) => url != null && url.isNotEmpty)
            .cast<String>()
            .toList();

        if (avatarUrls.isNotEmpty) {
          ImageCacheService().precacheImages(avatarUrls, context);
        }
      }
    } catch (e) {
      debugPrint('Error fetching comments: $e');
      if (mounted) {
        setState(() {
          _hasError = true;
        });
        widget.onError('Failed to load comments: $e');
      }
    }
  }

  void _setupRealtimeSubscription() {
    _commentSubscription = Supabase.instance.client
        .channel('comments:${widget.post.id}')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'comments',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'post_id',
            value: widget.post.id,
          ),
          callback: (_) async {
            await _fetchComments();
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'comment_likes',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.inFilter,
            column: 'comment_id',
            value: _comments.map((c) => c['id']).toList(),
          ),
          callback: (_) async {
            await _fetchComments();
          },
        )
        .subscribe((status, [error]) {
          final String statusStr = status is String
              ? status as String
              : status.toString().toUpperCase();
          if (statusStr.contains('SUBSCRIPTION_ERROR') && error != null) {
            debugPrint('Realtime subscription error: $error');
            if (mounted) setState(() => _hasError = true);
          }
        });
  }

  Future<void> _addComment() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      _showErrorSnackBar('You must be logged in to comment');
      return;
    }

    setState(() {
      _isSending = true;
      _comments.insert(0, {
        'id': 'temp_${DateTime.now().millisecondsSinceEpoch}',
        'post_id': widget.post.id,
        'user_id': userId,
        'content': text,
        'created_at': DateTime.now().toUtc().toIso8601String(),
        'parent_id': _replyToCommentId,
        'users': {'username': 'You', 'handle': '@you'},
        'like_count': 0,
        'is_liked': false,
      });
      widget.post.commentCount += 1;
      _controller.clear();
      _replyToCommentId = null;
      _replyToUsername = null;
      FocusScope.of(context).unfocus();
      _animationController.forward(from: 0);
    });

    try {
      final inserted = await supabase
          .from('comments')
          .insert({
            'post_id': widget.post.id,
            'user_id': userId,
            'content': text,
            'created_at': DateTime.now().toUtc().toIso8601String(),
            if (_replyToCommentId != null) 'parent_id': _replyToCommentId,
          })
          .select()
          .single();

      final userData = await supabase
          .from('users')
          .select('username, handle, profile_image_url')
          .eq('id', userId)
          .single();

      setState(() {
        _comments.removeWhere((c) => c['id'].toString().startsWith('temp_'));
        _comments.insert(0, {
          ...inserted,
          'users': {
            'username': userData['username'] ?? 'Unknown',
            'handle': userData['handle'] ?? 'unknown',
            'profile_image_url': userData['profile_image_url'],
          },
          'like_count': 0,
          'is_liked': false,
        });
      });

      // === TRINITY SUMMON – ONLY VERIFIED + SERVICE_ROLE ===
      // === TRINITY SUMMON – ONLY VERIFIED + SERVICE_ROLE ===
      if (text.toLowerCase().contains('@trinity')) {
        final authorData = await supabase
            .from('users')
            .select('blue_tick, gold_tick')
            .eq('id', userId)
            .single();

        final isVerified =
            (authorData['blue_tick'] == true) ||
            (authorData['gold_tick'] == true);

        final oracle = TrinityOracle();
        final question = text
            .split(RegExp(r'@trinity', caseSensitive: false))
            .last
            .trim();

        final reply = isVerified
            ? oracle.getResponse(question.isEmpty ? "summon" : question)
            : "Trinity access denied. Only **verified** users can summon me.";

        final serviceClient = SupabaseClient(
          'https://jzvvzyrtafqmxpnxyvgn.supabase.co', // HARDCODED – NO ERROR
          dotenv.env['SUPABASE_SERVICE_ROLE']!,
        );

        await serviceClient.from('comments').insert({
          'post_id': widget.post.id,
          'user_id': TrinityOracle.trinityUserId,
          'content': reply,
          'parent_id': inserted['id'],
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });
      }

      if (widget.post.userId != userId) {
        try {
          final ownerData = await supabase
              .from('users')
              .select('xp')
              .eq('id', widget.post.userId)
              .single();
          final currentXp = (ownerData['xp'] as int?) ?? 0;
          await supabase
              .from('users')
              .update({'xp': currentXp + 5})
              .eq('id', widget.post.userId);
          await supabase.from('wallet_transactions').insert({
            'user_id': widget.post.userId,
            'type': 'xp_credit',
            'amount': 5,
            'description': 'XP earned from comment on post ${widget.post.id}',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          });
          if (supabase.auth.currentUser?.id == widget.post.userId) {
            showToast("💬 You earned +5 XP from a comment!");
          }
        } catch (e) {
          debugPrint('Error awarding XP for comment: $e');
        }
      }

      final tagExp = RegExp(r'(@|#)([a-zA-Z0-9_]+)');
      for (var match in tagExp.allMatches(text)) {
        if (match.group(1) == '@') {
          final taggedUsername = match.group(2)!;
          final taggedUser = await supabase
              .from('users')
              .select('id')
              .eq('username', taggedUsername)
              .maybeSingle();
          if (taggedUser != null && taggedUser['id'] != userId) {
            await supabase.from('notifications').insert({
              'user_id': taggedUser['id'],
              'actor_id': userId,
              'type': 'tag',
              'post_id': widget.post.id,
              'created_at': DateTime.now().toIso8601String(),
            });
          }
        }
      }

      showToast('✅ Comment posted!');
    } catch (e) {
      debugPrint('Error adding comment: $e');
      setState(() {
        _comments.removeWhere((c) => c['id'].toString().startsWith('temp_'));
        widget.post.commentCount -= 1;
      });
      _showErrorSnackBar('Failed to add comment: $e');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _toggleLike(String commentId, bool isLiked) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      _showErrorSnackBar('You must be logged in to like comments');
      return;
    }

    try {
      if (isLiked) {
        await Supabase.instance.client
            .from('comment_likes')
            .delete()
            .eq('user_id', userId)
            .eq('comment_id', commentId);
        setState(() {
          final comment = _comments.firstWhere((c) => c['id'] == commentId);
          comment['like_count'] = (comment['like_count'] as int) - 1;
          comment['is_liked'] = false;
        });
      } else {
        await Supabase.instance.client.from('comment_likes').insert({
          'user_id': userId,
          'comment_id': commentId,
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });
        setState(() {
          final comment = _comments.firstWhere((c) => c['id'] == commentId);
          comment['like_count'] = (comment['like_count'] as int) + 1;
          comment['is_liked'] = true;
        });

        final comment = _comments.firstWhere((c) => c['id'] == commentId);
        if (comment['user_id'] != null && comment['user_id'] != userId) {
          await Supabase.instance.client.from('notifications').insert({
            'user_id': comment['user_id'],
            'actor_id': userId,
            'type': 'comment_like',
            'comment_id': commentId,
            'created_at': DateTime.now().toIso8601String(),
          });
        }
      }
      showToast(isLiked ? '👎 Comment unliked' : '❤️ Comment liked');
    } catch (e) {
      debugPrint('Error toggling like: $e');
      _showErrorSnackBar('Failed to like/unlike comment: $e');
    }
  }

  void _showErrorSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  List<Map<String, dynamic>> _getReplies(String commentId) {
    return _comments.where((c) => c['parent_id'] == commentId).toList();
  }

  List<InlineSpan> _parseTags(String content) {
    List<InlineSpan> spans = [];
    RegExp tagExp = RegExp(r'(@|#)([a-zA-Z0-9_]+)');
    int lastIndex = 0;

    for (var match in tagExp.allMatches(content)) {
      if (match.start > lastIndex) {
        spans.add(TextSpan(text: content.substring(lastIndex, match.start)));
      }
      final prefix = match.group(1)!;
      final tag = match.group(2)!;
      final fullTag = '$prefix$tag';

      if (prefix == '@') {
        spans.add(
          WidgetSpan(
            child: GestureDetector(
              onTap: () async {
                final user = await Supabase.instance.client
                    .from('users')
                    .select('id')
                    .eq('username', tag)
                    .maybeSingle();
                if (user != null &&
                    user['id'] !=
                        Supabase.instance.client.auth.currentUser?.id) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          OtherUserProfileScreen(userId: user['id']),
                    ),
                  );
                }
              },
              child: Text(
                fullTag,
                style: const TextStyle(
                  color: Color(0xFF1DA1F2),
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Roboto',
                ),
              ),
            ),
          ),
        );
      } else if (prefix == '#') {
        spans.add(
          WidgetSpan(
            child: GestureDetector(
              onTap: () => showToast('Search for #$tag (not implemented yet)'),
              child: Text(
                fullTag,
                style: const TextStyle(
                  color: Color(0xFF1DA1F2),
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Roboto',
                ),
              ),
            ),
          ),
        );
      }
      lastIndex = match.end;
    }
    if (lastIndex < content.length) {
      spans.add(TextSpan(text: content.substring(lastIndex)));
    }
    return spans;
  }

  Future<void> _reportComment(String commentId, String? commentUserId) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      showToast('You must be logged in to report comments.');
      return;
    }
    if (userId == commentUserId) {
      showToast('You cannot report your own comment.');
      return;
    }
    try {
      final existingReport = await Supabase.instance.client
          .from('user_reports')
          .select()
          .eq('comment_id', commentId)
          .eq('reporter_id', userId)
          .maybeSingle();
      if (existingReport != null) {
        showToast('You have already reported this comment.');
        return;
      }
      String? selectedReason;
      final reasons = [
        'Inappropriate content',
        'Spam',
        'Harassment',
        'Misinformation',
        'Other',
      ];
      await showDialog(
        context: context,
        builder: (context) => StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            title: const Text('Report Comment'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Please select a reason for reporting this comment:',
                ),
                const SizedBox(height: 8),
                DropdownButton<String>(
                  isExpanded: true,
                  hint: const Text('Select a reason'),
                  value: selectedReason,
                  items: reasons.map((reason) {
                    return DropdownMenuItem<String>(
                      value: reason,
                      child: Text(reason),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setDialogState(() {
                      selectedReason = value;
                    });
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: selectedReason == null
                    ? null
                    : () async {
                        try {
                          await Supabase.instance.client
                              .from('user_reports')
                              .insert({
                                'comment_id': commentId,
                                'reporter_id': userId,
                                'user_id': commentUserId,
                                'reason': selectedReason,
                                'status': 'pending',
                                'created_at': DateTime.now().toIso8601String(),
                              });
                          if (commentUserId != null) {
                            await Supabase.instance.client
                                .from('notifications')
                                .insert({
                                  'user_id': commentUserId,
                                  'actor_id': userId,
                                  'type': 'report',
                                  'comment_id': commentId,
                                  'created_at': DateTime.now()
                                      .toIso8601String(),
                                  'is_read': false,
                                });
                          }
                          try {
                            final admins = await Supabase.instance.client.rpc(
                              'get_admins',
                              params: {
                                'roles': ['admin', 'superadmin', 'moderator'],
                              },
                            );
                            for (final admin in admins) {
                              await Supabase.instance.client
                                  .from('notifications')
                                  .insert({
                                    'user_id': admin['id'],
                                    'actor_id': userId,
                                    'type': 'report_admin',
                                    'comment_id': commentId,
                                    'created_at': DateTime.now()
                                        .toIso8601String(),
                                    'is_read': false,
                                  });
                            }
                          } catch (adminError) {
                            debugPrint('Error notifying admins: $adminError');
                          }
                          showToast('✅ Comment reported successfully!');
                          Navigator.pop(context);
                        } catch (e) {
                          debugPrint('Error reporting comment: $e');
                          showToast('Failed to report comment: $e');
                          _showErrorSnackBar('Failed to report comment: $e');
                        }
                      },
                child: const Text(
                  'Report',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      debugPrint('Error checking existing report: $e');
      showToast('Failed to check existing report: $e');
      _showErrorSnackBar('Failed to check existing report: $e');
    }
  }

  Widget _buildCommentTile(
    Map<String, dynamic> comment, {
    bool isReply = false,
  }) {
    final user = comment['users'] ?? {};
    final username = user['username'] ?? 'Unknown';
    final handle = user['handle'] ?? '@unknown';
    final createdAt = DateTime.tryParse(comment['created_at'] ?? '')?.toLocal();
    final likeCount = comment['like_count'] as int? ?? 0;
    final isLiked = comment['is_liked'] as bool? ?? false;

    return Container(
      margin: EdgeInsets.only(
        left: isReply ? 50 : 0,
        right: 8,
        top: 4,
        bottom: 4,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Avatar
          // Avatar + Trinity Special Case
          // Avatar
          GestureDetector(
            onTap: () {
              if (comment['user_id'] != null &&
                  comment['user_id'] != TrinityOracle.trinityUserId) {
                // ← Fixed
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        OtherUserProfileScreen(userId: comment['user_id']),
                  ),
                );
              }
            },
            child: CircleAvatar(
              radius: 18,
              backgroundColor: comment['user_id'] == TrinityOracle.trinityUserId
                  ? const Color(0xFF1DA1F2)
                  : Colors.grey[300],
              backgroundImage: comment['user_id'] == TrinityOracle.trinityUserId
                  ? null
                  : (user['profile_image_url'] != null
                        ? NetworkImage(user['profile_image_url'])
                        : null),
              child: comment['user_id'] == TrinityOracle.trinityUserId
                  ? const Icon(Icons.smart_toy, color: Colors.white, size: 20)
                  : (user['profile_image_url'] == null
                        ? Text(
                            username[0].toUpperCase(),
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          )
                        : null),
            ),
          ),

          const SizedBox(width: 10),

          // Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Username + Time row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Row(
                        children: [
                          Row(
                            children: [
                              Text(
                                username,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                ),
                              ),
                              // Badge
                              if (comment['user_id'] ==
                                  TrinityOracle.trinityUserId) ...[
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF1DA1F2),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: const Text(
                                    'TRINITY',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ] else if (user['blue_tick'] == true ||
                                  user['gold_tick'] == true) ...[
                                const SizedBox(width: 4),
                                Icon(
                                  Icons.verified,
                                  color: user['gold_tick'] == true
                                      ? Colors.amber.shade700
                                      : const Color(0xFF1DA1F2),
                                  size: 16,
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(width: 6),
                          Text(
                            createdAt != null
                                ? "· ${timeago.format(createdAt)}"
                                : '',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Color(0xFF9CA3AF),
                            ),
                          ),
                        ],
                      ),
                    ),
                    PopupMenuButton<String>(
                      icon: const Icon(
                        Icons.more_vert,
                        size: 16,
                        color: Color(0xFF6B7280),
                      ),
                      onSelected: (value) {
                        if (value == 'report') {
                          _reportComment(comment['id'], comment['user_id']);
                        }
                      },
                      itemBuilder: (context) => const [
                        PopupMenuItem(value: 'report', child: Text('Report')),
                      ],
                    ),
                  ],
                ),

                // Handle directly below username (tight spacing)
                Padding(
                  padding: const EdgeInsets.only(top: 1),
                  child: Text(
                    handle,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF6B7280),
                      height: 1.0, // reduces vertical space
                    ),
                  ),
                ),
                // Comment Text
                RichText(
                  text: TextSpan(
                    style: const TextStyle(fontSize: 14, color: Colors.black),
                    children: _parseTags(comment['content'] ?? ''),
                  ),
                ),

                const SizedBox(height: 8),

                // Reply + Like Row
                Row(
                  children: [
                    // Reply button
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _replyToCommentId = comment['id'];
                          _replyToUsername = username;
                          _controller.text = '@$username ';
                          FocusScope.of(context).requestFocus(_focusNode);
                        });
                      },
                      child: Row(
                        children: const [
                          Icon(
                            LucideIcons.messageCircle,
                            size: 16,
                            color: Color(0xFF6B7280),
                          ),
                          SizedBox(width: 4),
                          Text(
                            'Reply',
                            style: TextStyle(
                              fontSize: 12,
                              color: Color(0xFF6B7280),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(width: 20),

                    // Like button
                    GestureDetector(
                      onTap: () => _toggleLike(
                        comment['id'],
                        comment['is_liked'] ?? false,
                      ),
                      child: Row(
                        children: [
                          Icon(
                            isLiked ? Icons.favorite : Icons.favorite_border,
                            size: 16,
                            color: isLiked
                                ? const Color(0xFFF91880)
                                : Colors.grey,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '$likeCount',
                            style: TextStyle(
                              fontSize: 12,
                              color: isLiked
                                  ? const Color(0xFFF91880)
                                  : Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 4),
                const Divider(height: 10, thickness: 0.5),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    _animationController.dispose();
    _commentSubscription?.unsubscribe();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topLevelComments = _comments
        .where((c) => c['parent_id'] == null)
        .toList();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Post',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontFamily: 'Roboto',
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1DA1F2)),
          onPressed: () => Navigator.pop(context, true),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _hasError
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Failed to load comments',
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            color: Colors.black87,
                          ),
                        ),
                        TextButton(
                          onPressed: _fetchComments,
                          child: const Text(
                            'Retry',
                            style: TextStyle(
                              color: Color(0xFF1DA1F2),
                              fontFamily: 'Roboto',
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    // ← REPLACE ListView with ListView.builder
                    itemCount:
                        2 +
                        topLevelComments.length +
                        (topLevelComments.length ~/
                            AdManager().nativeAdFrequency),
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return PostCard(
                          post: widget.post,
                          currentUserId: widget.currentUserId,
                          onComment: (_) async {},
                          onLike: widget.onLike,
                          onRepost: widget.onRepost,
                          onShare: widget.onShare,
                          onEdit: widget.onEdit,
                          onDelete: widget.onDelete,
                          onProfileTap: widget.onProfileTap,
                          onError: widget.onError,
                          onBoost: widget.onBoost,
                          isTrending: widget.isTrending,
                        );
                      } else if (index == 1) {
                        return const Divider(
                          height: 1,
                          color: Color(0xFFE5E7EB),
                        );
                      } else {
                        final contentIndex = index - 2;
                        if (topLevelComments.isEmpty) {
                          return const Padding(
                            padding: EdgeInsets.all(16),
                            child: Text(
                              'No comments yet',
                              style: TextStyle(
                                color: Colors.black87,
                                fontFamily: 'Roboto',
                              ),
                            ),
                          );
                        }
                        // === INSERT NATIVE AD ===
                        if (AdManager().shouldShowNativeAd(contentIndex)) {
                          return NativeAdWidget(
                            key: ValueKey(
                              'native_ad_$contentIndex',
                            ), // ← dynamic key
                          );
                        }

                        // Adjust comment index after ads
                        final commentIndex =
                            contentIndex -
                            (contentIndex ~/ AdManager().nativeAdFrequency);
                        if (commentIndex >= topLevelComments.length) {
                          return const SizedBox.shrink();
                        }

                        final comment = topLevelComments[commentIndex];
                        return FadeTransition(
                          opacity: _animation,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _buildCommentTile(comment, isReply: false),

                              Padding(
                                padding: const EdgeInsets.only(left: 16),
                                child: Column(
                                  children: _getReplies(comment['id'])
                                      .map(
                                        (reply) => _buildCommentTile(
                                          reply,
                                          isReply: true,
                                        ),
                                      )
                                      .toList(),
                                ),
                              ),
                            ],
                          ),
                        );
                      }
                    },
                  ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      focusNode: _focusNode,
                      decoration: InputDecoration(
                        hintText: _replyToCommentId != null
                            ? 'Replying to @$_replyToUsername...'
                            : 'Add a comment...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: const BorderSide(
                            color: Color(0xFFE5E7EB),
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: const BorderSide(
                            color: Color(0xFFE5E7EB),
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: const BorderSide(
                            color: Color(0xFF1DA1F2),
                          ),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                        hintStyle: const TextStyle(color: Color(0xFF6B7280)),
                      ),
                      maxLines: null,
                      keyboardType: TextInputType.multiline,
                      style: const TextStyle(
                        fontFamily: 'Roboto',
                        fontSize: 13,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: _isSending ? null : _addComment,
                    icon: _isSending
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(
                                Color(0xFF1DA1F2),
                              ),
                            ),
                          )
                        : const Icon(
                            Icons.send,
                            color: Color(0xFF1DA1F2),
                            size: 20,
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
