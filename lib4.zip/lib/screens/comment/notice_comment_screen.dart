import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/models/notice_model.dart';

class NoticeCommentScreen extends StatefulWidget {
  final Notice notice;

  const NoticeCommentScreen({super.key, required this.notice});

  @override
  State<NoticeCommentScreen> createState() => _NoticeCommentScreenState();
}

class _NoticeCommentScreenState extends State<NoticeCommentScreen> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _comments = [];
  bool _loading = true;
  String? _error;
  final _commentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchComments();
  }

  Future<void> _fetchComments() async {
    try {
      final response = await supabase
          .from('notice_comments')
          .select('''
        id,
        notice_id,
        user_id,
        content,
        created_at,
        users(username, profile_image_url)
      ''')
          .eq('notice_id', widget.notice.id)
          .order('created_at', ascending: false);

      if (mounted) {
        setState(() {
          _comments = response; // Removed unnecessary cast
          _loading = false;
          _error = null;
        });
      }
    } catch (e) {
      debugPrint('Error fetching comments: $e');
      if (mounted) {
        setState(() {
          _error = 'Failed to load comments: $e';
          _loading = false;
        });
      }
    }
  }

  Future<void> _addComment() async {
    if (_commentController.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Comment cannot be empty')));
      return;
    }

    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      await supabase.from('notice_comments').insert({
        'notice_id': widget.notice.id,
        'user_id': user.id,
        'content': _commentController.text.trim(),
      });

      _commentController.clear();
      await _fetchComments();
      if (mounted) {
        Navigator.pop(context, _comments.length);
      }
    } catch (e) {
      debugPrint('Error adding comment: $e');
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Failed to add comment: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Comments',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                : _error != null
                ? Center(child: Text(_error!))
                : _comments.isEmpty
                ? const Center(child: Text('No comments yet'))
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _comments.length,
                    separatorBuilder: (_, _) =>
                        Divider(height: 1, color: Colors.grey[300]),
                    itemBuilder: (context, index) {
                      final comment = _comments[index];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey[300],
                          backgroundImage:
                              comment['users']['profile_image_url'] != null
                              ? NetworkImage(
                                  comment['users']['profile_image_url'],
                                )
                              : null,
                          child: comment['users']['profile_image_url'] == null
                              ? Text(
                                  comment['users']['username'].isNotEmpty
                                      ? comment['users']['username'][0]
                                            .toUpperCase()
                                      : 'U',
                                  style: const TextStyle(color: Colors.black),
                                )
                              : null,
                        ),
                        title: Text(
                          comment['users']['username'] ?? 'Unknown',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              comment['content'],
                              style: const TextStyle(fontSize: 15),
                            ),
                            Text(
                              timeago.format(
                                DateTime.parse(comment['created_at']),
                              ),
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _commentController,
                    decoration: InputDecoration(
                      hintText: 'Add a comment...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _addComment,
                  icon: const Icon(Icons.send, color: Colors.blue),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }
}
