import 'package:flutter/material.dart';

class FullImageScreen extends StatelessWidget {
  final String? imageUrl;
  final String placeholderText;

  const FullImageScreen({
    super.key,
    required this.imageUrl,
    required this.placeholderText,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: imageUrl != null
            ? InteractiveViewer(
                panEnabled: true,
                minScale: 0.5,
                maxScale: 4.0,
                child: Image.network(
                  imageUrl!,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) => Center(
                    child: Text(
                      'Failed to load image',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                ),
              )
            : Text(
                placeholderText,
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
      ),
    );
  }
}
