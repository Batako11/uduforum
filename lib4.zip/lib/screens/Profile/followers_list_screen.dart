import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import '../../services/user_service.dart';
import '../../models/user_model.dart';
import 'other_user_profile_screen.dart';
import 'profile_screen.dart';

class FollowersListScreen extends StatefulWidget {
  final String userId;

  const FollowersListScreen({super.key, required this.userId});

  @override
  State<FollowersListScreen> createState() => _FollowersListScreenState();
}

class _FollowersListScreenState extends State<FollowersListScreen> {
  bool _loading = true;
  String? _error;
  List<UserModel> _followers = [];

  @override
  void initState() {
    super.initState();
    _fetchFollowers();
  }

  Future<void> _fetchFollowers() async {
    try {
      final followers = await UserService.getFollowers(widget.userId);
      if (mounted) {
        setState(() {
          _followers = followers;
          _loading = false;
          _error = null;
        });
      }
    } catch (e) {
      debugPrint('Error fetching followers: $e');
      if (mounted) {
        setState(() {
          _error = 'Failed to load followers: $e';
          _loading = false;
        });
      }
    }
  }

  void _navigateToProfile(String followerId) {
    final currentUserId = Supabase.instance.client.auth.currentUser?.id;
    if (currentUserId == null) {
      showToast('You must be logged in');
      return;
    }

    if (followerId == currentUserId) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfileScreen()),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OtherUserProfileScreen(userId: followerId),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Followers',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : _error != null
          ? Center(child: Text(_error!))
          : _followers.isEmpty
          ? const Center(child: Text('No followers yet'))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _followers.length,
              separatorBuilder: (_, _) =>
                  Divider(height: 1, color: Colors.grey[300]),
              itemBuilder: (context, index) {
                final user = _followers[index];
                return Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                    side: BorderSide(color: Colors.grey[200]!),
                  ),
                  elevation: 0,
                  color: Colors.white,
                  child: ListTile(
                    onTap: () => _navigateToProfile(user.id),
                    leading: CircleAvatar(
                      backgroundColor: Colors.grey[300],
                      backgroundImage: user.profileImageUrl != null
                          ? NetworkImage(user.profileImageUrl!)
                          : null,
                      child: user.profileImageUrl == null
                          ? Text(
                              user.fullName.isNotEmpty
                                  ? user.fullName[0].toUpperCase()
                                  : user.username[0].toUpperCase(),
                              style: const TextStyle(color: Colors.black),
                            )
                          : null,
                    ),
                    title: Text(
                      user.fullName.isNotEmpty ? user.fullName : user.username,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                    subtitle: Text(
                      '@${user.username}',
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
