import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import 'package:share_plus/share_plus.dart' as share_plus;
import '../../services/ad_manager.dart';
import '../feed/post_card.dart';
import '../comment/comment_screen.dart';
import '../widgets/native_ad_widget.dart';
import '/models/post_model.dart';
import '/utils/level_utils.dart';
import '/services/user_service.dart';
import '/models/user_model.dart';
import 'followers_list_screen.dart';
import 'following_list_screen.dart';
import '../messages/chat_screen.dart';
import 'full_image_screen.dart';
import 'profile_screen.dart';

class OtherUserProfileScreen extends StatefulWidget {
  final String userId;

  const OtherUserProfileScreen({super.key, required this.userId});

  @override
  State<OtherUserProfileScreen> createState() => _OtherUserProfileScreenState();
}

class _OtherUserProfileScreenState extends State<OtherUserProfileScreen> {
  final supabase = Supabase.instance.client;
  UserModel? _user;
  List<Post> _userPosts = [];
  bool _loading = true;
  bool _isFollowing = false;
  bool _isFollowLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadProfileData();
    final userId = supabase.auth.currentUser?.id;
    if (userId != null && userId != widget.userId) {
      _createProfileVisitNotification(userId);
    }
  }

  Future<void> _createProfileVisitNotification(String currentUserId) async {
    try {
      final existing = await supabase
          .from('notifications')
          .select()
          .eq('user_id', widget.userId)
          .eq('actor_id', currentUserId)
          .eq('type', 'profile_visit')
          .gt(
            'created_at',
            DateTime.now()
                .subtract(const Duration(minutes: 5))
                .toIso8601String(),
          )
          .maybeSingle();

      if (existing == null) {
        await supabase.from('notifications').insert({
          'user_id': widget.userId,
          'actor_id': currentUserId,
          'type': 'profile_visit',
          'created_at': DateTime.now().toIso8601String(),
        });
      }
    } catch (e) {
      debugPrint('Error creating profile visit notification: $e');
    }
  }

  Future<void> _loadProfileData() async {
    try {
      // GET currentUserId FIRST
      final currentUserId = supabase.auth.currentUser?.id;

      final userData = await UserService.getUserById(widget.userId);

      final postsData = await supabase
          .from('posts')
          .select('''
            id,
            user_id,
            content,
            image_url,
            created_at,
            poll_options,
            is_boosted,
            boost_expires_at,
            tagged_user_ids,
            tags,
            channel_id,
            channels(name, profile_image_url),
            users!inner(
            username, handle, level, profile_image_url, blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry),
            likes!post_id(count),
            comments!post_id(count),
            reposts!post_id(count),
            liked_by_me:likes!post_id(user_id),
            reposted_by_me:reposts!post_id(user_id),
            poll_votes!post_id(option_index, user_id),
            trending_posts!left(engagement_score, is_trending)
          ''')
          .eq('user_id', widget.userId)
          .order('created_at', ascending: false);

      final isFollowing = currentUserId != null
          ? await UserService.isFollowing(currentUserId, widget.userId)
          : false;

      final posts = (postsData as List).map((map) {
        return Post.fromMap(map, currentUserId: currentUserId);
      }).toList();

      if (mounted) {
        setState(() {
          _user = userData;
          _userPosts = posts;
          _isFollowing = isFollowing;
          _loading = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading profile: $e');
      if (mounted) {
        setState(() {
          _loading = false;
          _errorMessage = 'Failed to load profile';
        });
      }
    }
  }

  Future<void> _toggleFollow() async {
    final currentUserId = supabase.auth.currentUser?.id;
    if (currentUserId == null) {
      if (mounted) {
        showToast('You must be logged in to follow');
      }
      return;
    }

    setState(() {
      _isFollowLoading = true;
      if (_isFollowing) {
        _isFollowing = false;
        _user = _user!.copyWith(followers: _user!.followers - 1);
      } else {
        _isFollowing = true;
        _user = _user!.copyWith(followers: _user!.followers + 1);
      }
    });

    try {
      if (!_isFollowing) {
        await supabase.from('follows').delete().match({
          'follower_id': currentUserId,
          'followed_id': widget.userId,
        });
        await supabase
            .from('users')
            .update({'followers': _user!.followers})
            .eq('id', widget.userId);
        await supabase
            .from('users')
            .update({'following': (_user!.following - 1)})
            .eq('id', currentUserId);
      } else {
        await supabase.from('follows').insert({
          'follower_id': currentUserId,
          'followed_id': widget.userId,
        });
        await supabase
            .from('users')
            .update({'followers': _user!.followers})
            .eq('id', widget.userId);
        await supabase
            .from('users')
            .update({'following': (_user!.following + 1)})
            .eq('id', currentUserId);
        await supabase.from('notifications').insert({
          'user_id': widget.userId,
          'actor_id': currentUserId,
          'type': 'follow',
          'created_at': DateTime.now().toIso8601String(),
        });
      }
    } catch (e) {
      debugPrint('Error toggling follow: $e');
      if (mounted) {
        setState(() {
          _isFollowing = !_isFollowing;
          _user = _user!.copyWith(
            followers: _isFollowing ? _user!.followers : _user!.followers - 1,
          );
        });
        showToast('Failed to update follow status: $e');
      }
    } finally {
      if (mounted) {
        setState(() => _isFollowLoading = false);
      }
    }
  }

  Future<void> _startConversation() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      if (mounted) showToast('You must be logged in.');
      return;
    }

    try {
      final response = await supabase
          .from('conversations')
          .select()
          .or(
            'and(user1_id.eq.${user.id},user2_id.eq.${widget.userId}),and(user1_id.eq.${widget.userId},user2_id.eq.${user.id})',
          )
          .maybeSingle();

      String conversationId;
      if (response == null) {
        final newConv = await supabase
            .from('conversations')
            .insert({
              'user1_id': user.id,
              'user2_id': widget.userId,
              'created_at': DateTime.now().toIso8601String(),
              'updated_at': DateTime.now().toIso8601String(),
            })
            .select()
            .single();
        conversationId = newConv['id'];
      } else {
        conversationId = response['id'];
      }

      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChatScreen(
              conversationId: conversationId,
              otherUserId: widget.userId,
              otherUserName: _user!.fullName.isNotEmpty
                  ? _user!.fullName
                  : _user!.username,
              otherUserImageUrl: _user!.profileImageUrl,
            ),
          ),
        );
      }
    } catch (e) {
      debugPrint('Error starting conversation: $e');
      if (mounted) showToast('Failed to start conversation: $e');
    }
  }

  Future<void> _toggleLike(Post post, int index) async {
    final currentUserId = supabase.auth.currentUser?.id;
    if (currentUserId == null) {
      showToast('You must be logged in to like');
      return;
    }

    try {
      if (post.likedByMe) {
        await supabase.from('likes').delete().match({
          'user_id': currentUserId,
          'post_id': post.id,
        });
        setState(() {
          _userPosts[index] = post.copyWith(
            likedByMe: false,
            likeCount: post.likeCount - 1,
          );
        });
      } else {
        final existingLike = await supabase
            .from('likes')
            .select()
            .eq('post_id', post.id)
            .eq('user_id', currentUserId)
            .maybeSingle();

        if (existingLike != null) {
          showToast('You have already liked this post.');
          return;
        }

        await supabase.from('likes').insert({
          'user_id': currentUserId,
          'post_id': post.id,
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });
        setState(() {
          _userPosts[index] = post.copyWith(
            likedByMe: true,
            likeCount: post.likeCount + 1,
          );
        });

        if (post.userId != currentUserId) {
          await supabase.from('notifications').insert({
            'user_id': post.userId,
            'actor_id': currentUserId,
            'type': 'like',
            'post_id': post.id,
            'created_at': DateTime.now().toIso8601String(),
          });

          try {
            final ownerData = await supabase
                .from('users')
                .select('xp')
                .eq('id', post.userId)
                .single();
            final currentXp = (ownerData['xp'] as int?) ?? 0;
            await supabase
                .from('users')
                .update({'xp': currentXp + 3})
                .eq('id', post.userId);
            await supabase.from('wallet_transactions').insert({
              'user_id': post.userId,
              'type': 'xp_credit',
              'amount': 3,
              'description': 'XP earned from like on post ${post.id}',
              'created_at': DateTime.now().toUtc().toIso8601String(),
            });
            if (supabase.auth.currentUser?.id == post.userId) {
              showToast("❤️ You earned +3 XP from a like!");
            }
          } catch (e) {
            debugPrint('Error awarding XP for like: $e');
          }
        }
      }
      showToast(post.likedByMe ? '👎 Post unliked' : '❤️ Post liked');
    } catch (e) {
      debugPrint('Error toggling like: $e');
      showToast('Failed to update like: $e');
    }
  }

  Future<void> _toggleRepost(Post post, int index) async {
    final currentUserId = supabase.auth.currentUser?.id;
    if (currentUserId == null) {
      showToast('You must be logged in to repost');
      return;
    }

    try {
      if (post.repostedByMe) {
        await supabase.from('reposts').delete().match({
          'user_id': currentUserId,
          'post_id': post.id,
        });
        setState(() {
          _userPosts[index] = post.copyWith(
            repostedByMe: false,
            repostCount: post.repostCount - 1,
          );
        });
      } else {
        final existingRepost = await supabase
            .from('reposts')
            .select()
            .eq('post_id', post.id)
            .eq('user_id', currentUserId)
            .maybeSingle();

        if (existingRepost != null) {
          showToast('You have already reposted this post.');
          return;
        }

        await supabase.from('reposts').insert({
          'user_id': currentUserId,
          'post_id': post.id,
          'created_at': DateTime.now().toIso8601String(),
        });
        setState(() {
          _userPosts[index] = post.copyWith(
            repostedByMe: true,
            repostCount: post.repostCount + 1,
          );
        });

        if (post.userId != currentUserId) {
          await supabase.from('notifications').insert({
            'user_id': post.userId,
            'actor_id': currentUserId,
            'type': 'repost',
            'post_id': post.id,
            'created_at': DateTime.now().toIso8601String(),
          });
        }
      }
      showToast(post.repostedByMe ? '🔁 Post unreposted' : '🔁 Post reposted');
    } catch (e) {
      debugPrint('Error toggling repost: $e');
      showToast('Failed to update repost: $e');
    }
  }

  Future<void> _votePoll(Post post, int optionIndex, int index) async {
    final currentUserId = supabase.auth.currentUser?.id;
    if (currentUserId == null) {
      showToast('You must be logged in to vote');
      return;
    }
    if (post.pollOptions == null || optionIndex >= post.pollOptions!.length) {
      showToast('Invalid poll option');
      return;
    }

    try {
      final existingVote = await supabase
          .from('poll_votes')
          .select()
          .eq('user_id', currentUserId)
          .eq('post_id', post.id)
          .maybeSingle();

      if (existingVote != null) {
        showToast('You have already voted on this poll');
        return;
      }

      await supabase.from('poll_votes').insert({
        'user_id': currentUserId,
        'post_id': post.id,
        'option_index': optionIndex,
        'created_at': DateTime.now().toIso8601String(),
      });

      if (post.userId != currentUserId) {
        await supabase.from('notifications').insert({
          'user_id': post.userId,
          'actor_id': currentUserId,
          'type': 'poll_vote',
          'post_id': post.id,
          'created_at': DateTime.now().toIso8601String(),
        });
      }

      showToast('🗳️ Voted successfully!');
      await _openComments(post); // Refresh via onComment
    } catch (e) {
      debugPrint('Error voting on poll: $e');
      showToast('Failed to vote: $e');
    }
  }

  Future<void> _openComments(Post post) async {
    final isTrending = await _isTrendingPost(post.id);
    final refreshed = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CommentScreen(
          post: post,
          currentUserId: supabase.auth.currentUser?.id,
          onLike: (p) async {
            final index = _userPosts.indexWhere(
              (element) => element.id == p.id,
            );
            if (index != -1) {
              await _toggleLike(p, index);
            }
          },
          onRepost: (p) async {
            final index = _userPosts.indexWhere(
              (element) => element.id == p.id,
            );
            if (index != -1) {
              await _toggleRepost(p, index);
            }
          },
          onShare: _sharePost,
          onEdit: (p) async {
            showToast('Cannot edit another user\'s post');
          },
          onDelete: (p) async {
            showToast('Cannot delete another user\'s post');
          },
          onProfileTap: _navigateToProfile,
          onError: (message) {
            showToast(message);
          },
          onBoost: (p, duration, amount) async {
            showToast('Cannot boost another user\'s post');
          },
          isTrending: isTrending,
        ),
      ),
    );
    if (refreshed == true && mounted) {
      await _loadProfileData();
    }
  }

  Future<void> _sharePost(Post post) async {
    // ignore: deprecated_member_use
    await share_plus.Share.share('https://udusforum.com/p/${post.id}');
  }

  Future<void> _reportUser() async {
    final reporterId = supabase.auth.currentUser?.id;
    if (reporterId == null) {
      showToast('You must be logged in to report a user.');
      return;
    }

    if (reporterId == widget.userId) {
      showToast('You cannot report yourself.');
      return;
    }

    try {
      // Check if already reported
      final existing = await supabase
          .from('user_reports')
          .select()
          .eq('user_id', widget.userId)
          .eq('reporter_id', reporterId)
          .maybeSingle();

      if (existing != null) {
        showToast('You already reported this user.');
        return;
      }

      String? selectedReason;
      final reasons = [
        'Harassment or bullying',
        'Fake account',
        'Impersonation',
        'Hate speech or discrimination',
        'Spam or scam activity',
        'Other',
      ];

      await showDialog(
        context: context,
        builder: (context) => StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            title: const Text('Report User'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Select a reason for reporting this user:'),
                const SizedBox(height: 8),
                DropdownButton<String>(
                  isExpanded: true,
                  hint: const Text('Select reason'),
                  value: selectedReason,
                  items: reasons.map((reason) {
                    return DropdownMenuItem<String>(
                      value: reason,
                      child: Text(reason),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setDialogState(() => selectedReason = value);
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: selectedReason == null
                    ? null
                    : () async {
                        try {
                          await supabase.from('user_reports').insert({
                            'reporter_id': reporterId,
                            'user_id': widget.userId,
                            'reason': selectedReason,
                            'status': 'pending',
                            'created_at': DateTime.now().toIso8601String(),
                          });

                          // Notify admins (simplified, no RPC)
                          try {
                            final admins = await supabase
                                .from('users')
                                .select('id')
                                .inFilter('role', [
                                  'admin',
                                  'superadmin',
                                  'moderator',
                                ]);

                            for (final admin in admins) {
                              await supabase.from('notifications').insert({
                                'user_id': admin['id'],
                                'actor_id': reporterId,
                                'type': 'user_report_admin',
                                'created_at': DateTime.now().toIso8601String(),
                                'is_read': false,
                              });
                            }
                          } catch (e) {
                            debugPrint('Error notifying admins: $e');
                          }

                          showToast('✅ Report submitted successfully!');
                          Navigator.pop(context);
                        } catch (e) {
                          debugPrint('Error reporting user: $e');
                          showToast('Failed to report user.');
                        }
                      },
                child: const Text(
                  'Report',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      debugPrint('Error checking existing report: $e');
      showToast('Failed to check report.');
    }
  }

  void _navigateToProfile(String postUserId) {
    final currentUserId = supabase.auth.currentUser?.id;
    if (currentUserId == null) return;

    if (postUserId == currentUserId) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfileScreen()),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OtherUserProfileScreen(userId: postUserId),
        ),
      );
    }
  }

  Future<bool> _isTrendingPost(String postId) async {
    try {
      final response = await supabase
          .from('trending_posts')
          .select('is_trending')
          .eq('post_id', postId)
          .maybeSingle();
      return response != null && (response['is_trending'] as bool?) == true;
    } catch (e) {
      debugPrint('Error checking trending status: $e');
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }

    if (_errorMessage != null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_errorMessage!, style: const TextStyle(color: Colors.red)),
              TextButton(
                onPressed: _loadProfileData,
                child: const Text(
                  'Retry',
                  style: TextStyle(color: Color(0xFF1E88E5)),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final levelInfo = getLevelInfo(_user!.xp);
    final color = levelInfo['color'];
    final font = levelInfo['font'];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Text(
          _user!.username,
          style: const TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1E88E5)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: DefaultTabController(
        length: 2,
        child: Column(
          children: [
            TabBar(
              indicatorColor: const Color(0xFF1E88E5),
              labelColor: const Color(0xFF1E88E5),
              unselectedLabelColor: Colors.grey[600],
              tabs: const [
                Tab(icon: Icon(Icons.bar_chart), text: 'Stats'),
                Tab(icon: Icon(Icons.post_add), text: 'Posts'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  _buildStatsTab(levelInfo, color, font),
                  _buildPostsTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: color,
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
      ],
    );
  }

  Widget _buildStatsTab(
    Map<String, dynamic> levelInfo,
    Color levelColor,
    TextStyle font,
  ) {
    double progress =
        (_user!.xp - levelInfo['currentXp']) /
        (levelInfo['nextXp'] - levelInfo['currentXp']);

    Color getProgressColor() {
      if (progress < 0.15) return Colors.grey[400]!;
      if (progress < 0.3) return const Color(0xFFFFA973);
      if (progress < 0.5) return const Color(0xFFF5EA84);
      if (progress < 0.7) return const Color(0xFF589797);
      return const Color(0xFF1E88E5);
    }

    return Padding(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => FullImageScreen(
                          imageUrl: _user!.profileImageUrl,
                          placeholderText:
                              (_user!.fullName.isNotEmpty
                                      ? _user!.fullName[0]
                                      : _user!.username[0])
                                  .toUpperCase(),
                        ),
                      ),
                    );
                  },
                  child: CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.grey[200],
                    backgroundImage: _user!.profileImageUrl != null
                        ? NetworkImage(_user!.profileImageUrl!)
                        : null,
                    child: _user!.profileImageUrl == null
                        ? Text(
                            (_user!.fullName.isNotEmpty
                                    ? _user!.fullName[0]
                                    : _user!.username[0])
                                .toUpperCase(),
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          )
                        : null,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            _user!.fullName.isNotEmpty
                                ? _user!.fullName
                                : _user!.username,
                            style: font.copyWith(
                              fontSize: 22,
                              color: Colors.black87,
                            ),
                          ),
                          if (_user!.goldTick &&
                              (_user!.goldTickExpiry?.isAfter(DateTime.now()) ??
                                  false))
                            Padding(
                              padding: EdgeInsets.only(left: 8),
                              child: Icon(
                                Icons.verified,
                                color: Colors.amber.shade700,
                                size: 20,
                              ),
                            )
                          else if (_user!.blueTick &&
                              (_user!.blueTickExpiry?.isAfter(DateTime.now()) ??
                                  false))
                            const Padding(
                              padding: EdgeInsets.only(left: 8),
                              child: Icon(
                                Icons.verified,
                                color: Colors.blue,
                                size: 20,
                              ),
                            ),
                        ],
                      ),
                      if (_user!.username.isNotEmpty &&
                          _user!.fullName != _user!.username)
                        Text(
                          '@${_user!.username}',
                          style: font.copyWith(
                            fontSize: 16,
                            color: Colors.grey[600],
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            if (_user!.level?.isNotEmpty == true) ...[
              const SizedBox(height: 8),
              Text(
                _user!.level!,
                style: font.copyWith(color: Colors.black87, fontSize: 16),
              ),
            ],
            if (_user!.department?.isNotEmpty == true) ...[
              const SizedBox(height: 8),
              Text(
                _user!.department!,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
            ],
            if (_user!.bio?.isNotEmpty == true) ...[
              const SizedBox(height: 8),
              Text(
                _user!.bio!,
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            FollowersListScreen(userId: widget.userId),
                      ),
                    );
                  },
                  child: Text(
                    '${_user!.followers} Followers',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black87,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            FollowingListScreen(userId: widget.userId),
                      ),
                    );
                  },
                  child: Text(
                    '${_user!.following} Following',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black87,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: _isFollowLoading ? null : _toggleFollow,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isFollowing
                        ? Colors.grey[300]
                        : const Color(0xFF1E88E5),
                    foregroundColor: _isFollowing
                        ? Colors.black87
                        : Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                  icon: _isFollowLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation(Colors.white),
                          ),
                        )
                      : Icon(
                          _isFollowing ? Icons.person_remove : Icons.person_add,
                          size: 20,
                        ),
                  label: Text(_isFollowing ? 'Unfollow' : 'Follow'),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: _startConversation,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1E88E5),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                  icon: const Icon(Icons.message, size: 20),
                  label: const Text('Message'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: _reportUser,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade100,
                foregroundColor: Colors.red.shade800,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
              icon: const Icon(Icons.flag, size: 20),
              label: const Text('Report User'),
            ),
            const SizedBox(height: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Progress to Next Rank (${_user!.xp}/${levelInfo['nextXp']} XP)',
                  style: TextStyle(color: Colors.black87, fontSize: 14),
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey[200],
                  valueColor: AlwaysStoppedAnimation(getProgressColor()),
                  minHeight: 8,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(levelInfo['icon'], color: levelColor, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'Level ${levelInfo['level']}',
                      style: font.copyWith(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: levelColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: Colors.grey[200]!),
              ),
              elevation: 2,
              color: levelColor.withValues(alpha: 0.1),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildStat('XP', '${_user!.xp}', levelColor),
                    _buildStat('Streak', '${_user!.streak}', levelColor),
                    _buildStat('Coins', '${_user!.coins}', levelColor),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPostsTab() {
    final adManager = AdManager();

    if (_userPosts.isEmpty) {
      return const Center(
        child: Text(
          'This user has not posted anything yet.',
          style: TextStyle(color: Colors.grey, fontSize: 16),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount:
          _userPosts.length +
          (_userPosts.length ~/ adManager.nativeAdFrequency).toInt(),
      itemBuilder: (context, index) {
        // Insert a native ad every `nativeAdFrequency` posts
        // Example: frequency = 5 → ads at index 5, 11, 17, …
        if ((index + 1) % (adManager.nativeAdFrequency + 1) == 0) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: NativeAdWidget(),
          );
        }

        // Calculate the real post index (skipping the ad slots we already inserted)
        final int postIndex =
            index - (index ~/ (adManager.nativeAdFrequency + 1));

        final post = _userPosts[postIndex];

        return FutureBuilder<bool>(
          future: _isTrendingPost(post.id),
          builder: (context, snapshot) {
            final isTrending = snapshot.data ?? false;
            return PostCard(
              key: ValueKey('post_${post.id}_$postIndex'),
              post: post,
              currentUserId: supabase.auth.currentUser?.id,
              onComment: _openComments,
              onLike: (p) async {
                final i = _userPosts.indexWhere((e) => e.id == p.id);
                if (i != -1) await _toggleLike(p, i);
              },
              onRepost: (p) async {
                final i = _userPosts.indexWhere((e) => e.id == p.id);
                if (i != -1) await _toggleRepost(p, i);
              },
              onShare: _sharePost,
              onPollVote: (p, optionIndex) async {
                final i = _userPosts.indexWhere((e) => e.id == p.id);
                if (i != -1) await _votePoll(p, optionIndex, i);
              },
              onEdit: (_) async =>
                  showToast('Cannot edit another user\'s post'),
              onDelete: (_) async =>
                  showToast('Cannot delete another user\'s post'),
              onProfileTap: _navigateToProfile,
              onError: (msg) => showToast(msg),
              onBoost: (_, _, _) async =>
                  showToast('Cannot boost another user\'s post'),
              isTrending: isTrending,
            );
          },
        );
      },
    );
  }
}
