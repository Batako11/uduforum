import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/user_service.dart';
import '../../models/user_model.dart';
import 'other_user_profile_screen.dart';
import 'profile_screen.dart';

class FollowingListScreen extends StatelessWidget {
  final String userId;

  const FollowingListScreen({super.key, required this.userId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Following')),
      body: FutureBuilder<List<UserModel>>(
        future: UserService.getFollowing(userId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError ||
              !snapshot.hasData ||
              snapshot.data!.isEmpty) {
            return const Center(child: Text('Not following anyone yet'));
          }

          final following = snapshot.data!;
          return ListView.builder(
            itemCount: following.length,
            itemBuilder: (context, index) {
              final user = following[index];
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.grey[300],
                  child: Text(
                    user.fullName.isNotEmpty
                        ? user.fullName[0]
                        : user.username[0],
                    style: const TextStyle(color: Colors.black),
                  ),
                ),
                title: Text(
                  user.fullName.isNotEmpty ? user.fullName : user.username,
                ),
                subtitle: Text('@${user.username}'),
                onTap: () {
                  final currentUserId =
                      Supabase.instance.client.auth.currentUser?.id;
                  if (currentUserId == user.id) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ProfileScreen()),
                    );
                  } else {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => OtherUserProfileScreen(userId: user.id),
                      ),
                    );
                  }
                },
              );
            },
          );
        },
      ),
    );
  }
}
