import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import 'package:intl/intl.dart';
import '/models/post_model.dart';
import '/utils/level_utils.dart';
import '../feed/leaderboard_screen.dart';
import 'followers_list_screen.dart';
import 'following_list_screen.dart';
import '../wallet/wallet_screen.dart';
import 'edit_profile_screen.dart';
import 'full_image_screen.dart';
import '../widgets/banner_ad_widget.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final supabase = Supabase.instance.client;

  // User Data
  String? _username, _fullname, _bio, _department, _level, _profileImageUrl;
  int _followers = 0, _following = 0, _xp = 0, _coins = 0;
  bool _blueTick = false, _goldTick = false;
  DateTime? _blueTickExpiry, _goldTickExpiry;
  List<Post> _userPosts = [];
  List<Map<String, dynamic>> _boostReports = [];
  bool _loading = true;
  int? _previousLevel;

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  void refreshProfile() => mounted ? _loadProfileData() : null;

  Future<void> _loadProfileData() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final [userResponse, postsData, boostReports] = await Future.wait([
        supabase
            .from('users')
            .select('''
        id, username, full_name, bio, department, level, profile_image_url,
        followers, following, xp, coins,
        blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry
      ''')
            .eq('id', user.id)
            .single(),

        supabase
            .from('posts')
            .select('''
        id, user_id, content, image_url, created_at, poll_options,
        is_boosted, boost_expires_at, tagged_user_ids, tags, channel_id,
        channels(name, profile_image_url),
        users!inner(username, handle, level, profile_image_url, blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry),
        likes!post_id(count), comments!post_id(count), reposts!post_id(count),
        liked_by_me:likes!post_id(user_id), reposted_by_me:reposts!post_id(user_id),
        poll_votes!post_id(option_index, user_id)
      ''')
            .eq('user_id', user.id)
            .order('created_at', ascending: false),

        supabase
            .from('boost_metrics')
            .select('''
        post_id, boost_start, boost_end, views, followers_gained,
        posts!inner(like_count:likes!post_id(count), comment_count:comments!post_id(count))
      ''')
            .eq('user_id', user.id)
            .lt('boost_end', DateTime.now().toIso8601String())
            .order('boost_end', ascending: false),
      ]);

      if (!mounted) return;

      final userData = userResponse as Map<String, dynamic>;
      final currentUserId = user.id;
      final newXp = userData['xp'] ?? 0;
      final newLevel = getLevelInfo(newXp)['level'];

      setState(() {
        _username = userData['username'];
        _fullname = userData['full_name'];
        _bio = userData['bio'];
        _department = userData['department'];
        _level = userData['level'];
        _profileImageUrl = userData['profile_image_url'];
        _followers = userData['followers'] ?? 0;
        _following = userData['following'] ?? 0;
        _xp = newXp;
        _coins = userData['coins'] ?? 0;
        _blueTick = userData['blue_tick'] ?? false;
        _blueTickExpiry = _parseDate(userData['blue_tick_expiry']);
        _goldTick = userData['gold_tick'] ?? false;
        _goldTickExpiry = _parseDate(userData['gold_tick_expiry']);

        _userPosts = (postsData as List)
            .map((m) => Post.fromMap(m, currentUserId: currentUserId))
            .toList();

        _boostReports = (boostReports as List)
            .map(
              (e) => {
                'post_id': e['post_id'],
                'boost_start': DateTime.parse(e['boost_start']),
                'boost_end': DateTime.parse(e['boost_end']),
                'views': e['views'],
                'followers_gained': e['followers_gained'],
                'like_count': _getCount(e, 'like_count'),
                'comment_count': _getCount(e, 'comment_count'),
              },
            )
            .toList();

        _loading = false;

        if (_previousLevel != null && newLevel > _previousLevel!) {
          showToast(
            'Level Up! ${getLevelInfo(newXp)['title']} (Level $newLevel)!',
            duration: const Duration(seconds: 3),
          );
        }
        _previousLevel = newLevel;
      });
    } catch (e) {
      debugPrint('Profile load error: $e');
      if (mounted) {
        setState(() => _loading = false);
        showToast('Failed to load profile');
      }
    }
  }

  DateTime? _parseDate(String? date) =>
      date != null ? DateTime.tryParse(date) : null;
  int _getCount(Map e, String key) =>
      (e['posts'][key] as List?)?.isNotEmpty == true
      ? e['posts'][key][0]['count']
      : 0;

  // === TICK DIALOGS ===
  Future<void> _showTickDialog({
    required bool hasTick,
    required DateTime? expiry,
    required String title,
    required String purchaseText,
  }) async {
    final now = DateTime.now();
    if (hasTick && expiry != null && expiry.isAfter(now)) {
      final daysLeft = expiry.difference(now).inDays;
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('$title Status'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Active!'),
              const SizedBox(height: 8),
              Text('Expires: ${DateFormat('MMMM d, yyyy').format(expiry)}'),
              Text('Days left: $daysLeft'),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    } else {
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('$title Status'),
          content: Text('No active $title. Buy one?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const WalletScreen()),
                ).then((_) => _loadProfileData());
              },
              child: Text(purchaseText),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final levelInfo = getLevelInfo(_xp);
    final progress =
        (_xp - levelInfo['currentXp']) /
        (levelInfo['nextXp'] - levelInfo['currentXp']);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'My Profile',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit, color: Color(0xFF1E88E5)),
            onPressed: () => _navigateToEdit(),
          ),
          IconButton(
            icon: const Icon(Icons.leaderboard, color: Color(0xFF1E88E5)),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
            ),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : DefaultTabController(
              length: 3,
              child: Column(
                children: [
                  const _TabBar(),
                  Expanded(
                    child: RefreshIndicator(
                      onRefresh: _loadProfileData,
                      color: const Color(0xFF1E88E5),
                      child: TabBarView(
                        children: [
                          _StatsTab(
                            profileImageUrl: _profileImageUrl,
                            fullname: _fullname,
                            username: _username,
                            level: _level,
                            department: _department,
                            bio: _bio,
                            followers: _followers,
                            following: _following,
                            xp: _xp,
                            coins: _coins,
                            blueTick: _blueTick,
                            blueTickExpiry: _blueTickExpiry,
                            goldTick: _goldTick,
                            goldTickExpiry: _goldTickExpiry,
                            levelInfo: levelInfo,
                            progress: progress,
                            onBlueTickTap: () => _showTickDialog(
                              hasTick: _blueTick,
                              expiry: _blueTickExpiry,
                              title: 'Blue Tick',
                              purchaseText: 'Purchase Blue Tick',
                            ),
                            onGoldTickTap: () => _showTickDialog(
                              hasTick: _goldTick,
                              expiry: _goldTickExpiry,
                              title: 'Gold Tick',
                              purchaseText: 'Purchase Gold Tick',
                            ),
                          ),
                          _PostsTab(posts: _userPosts),
                          _BoostsTab(reports: _boostReports),
                        ],
                      ),
                    ),
                  ),
                  const BannerAdWidget(height: 50), // Add banner ad here
                ],
              ),
            ),
    );
  }

  void _navigateToEdit() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const EditProfileScreen()),
    ).then((success) => success == true ? _loadProfileData() : null);
  }
}

// === EXTRACTED WIDGETS ===

class _TabBar extends StatelessWidget {
  const _TabBar();

  @override
  Widget build(BuildContext context) {
    return TabBar(
      indicatorColor: const Color(0xFF1E88E5),
      labelColor: const Color(0xFF1E88E5),
      unselectedLabelColor: Colors.grey[600],
      tabs: const [
        Tab(icon: Icon(Icons.bar_chart), text: 'Stats'),
        Tab(icon: Icon(Icons.post_add), text: 'Posts'),
        Tab(icon: Icon(Icons.rocket_launch), text: 'Boosts'),
      ],
    );
  }
}

class _StatsTab extends StatelessWidget {
  final String? profileImageUrl, fullname, username, level, department, bio;
  final int followers, following, xp, coins;
  final bool blueTick, goldTick;
  final DateTime? blueTickExpiry, goldTickExpiry;
  final Map<String, dynamic> levelInfo;
  final double progress;
  final VoidCallback onBlueTickTap, onGoldTickTap;

  const _StatsTab({
    required this.profileImageUrl,
    required this.fullname,
    required this.username,
    required this.level,
    required this.department,
    required this.bio,
    required this.followers,
    required this.following,
    required this.xp,
    required this.coins,
    required this.blueTick,
    required this.blueTickExpiry,
    required this.goldTick,
    required this.goldTickExpiry,
    required this.levelInfo,
    required this.progress,
    required this.onBlueTickTap,
    required this.onGoldTickTap,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ProfileHeader(
            imageUrl: profileImageUrl,
            fullname: fullname,
            username: username,
            blueTick: blueTick,
            blueTickExpiry: blueTickExpiry,
            goldTick: goldTick,
            goldTickExpiry: goldTickExpiry,
            onBlueTickTap: onBlueTickTap,
            onGoldTickTap: onGoldTickTap,
          ),
          if (level?.isNotEmpty == true) ...[
            const SizedBox(height: 8),
            Text(level!, style: const TextStyle(fontSize: 16)),
          ],
          if (department?.isNotEmpty == true) ...[
            const SizedBox(height: 8),
            Text(department!, style: TextStyle(color: Colors.grey[600])),
          ],
          if (bio?.isNotEmpty == true) ...[
            const SizedBox(height: 8),
            Text(bio!, style: const TextStyle(color: Colors.black87)),
          ],
          const SizedBox(height: 12),
          _FollowRow(followers: followers, following: following),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WalletScreen()),
            ),
            icon: const Icon(Icons.account_balance_wallet),
            label: const Text('My Wallet'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1E88E5),
              foregroundColor: Colors.white,
            ),
          ),
          const SizedBox(height: 15),
          _ProgressBar(progress: progress, levelInfo: levelInfo, xp: xp),
          const SizedBox(height: 9),
          _XpCoinsCard(xp: xp, coins: coins, color: levelInfo['color']),
        ],
      ),
    );
  }
}

class _ProfileHeader extends StatelessWidget {
  final String? imageUrl, fullname, username;
  final bool blueTick, goldTick;
  final DateTime? blueTickExpiry, goldTickExpiry;
  final VoidCallback onBlueTickTap, onGoldTickTap;

  const _ProfileHeader({
    required this.imageUrl,
    required this.fullname,
    required this.username,
    required this.blueTick,
    required this.blueTickExpiry,
    required this.goldTick,
    required this.goldTickExpiry,
    required this.onBlueTickTap,
    required this.onGoldTickTap,
  });

  @override
  Widget build(BuildContext context) {
    final displayName = fullname?.isNotEmpty == true
        ? fullname!
        : username ?? 'User';
    final showUsername = username != null && username != fullname;

    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => FullImageScreen(
                imageUrl: imageUrl,
                placeholderText:
                    (fullname?.isNotEmpty == true
                            ? fullname![0]
                            : username?[0] ?? 'U')
                        .toUpperCase(),
              ),
            ),
          ),
          child: CircleAvatar(
            radius: 40,
            backgroundColor: Colors.grey[200],
            backgroundImage: imageUrl != null ? NetworkImage(imageUrl!) : null,
            child: imageUrl == null
                ? Text(
                    (fullname?.isNotEmpty == true
                            ? fullname![0]
                            : username?[0] ?? 'U')
                        .toUpperCase(),
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                : null,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    displayName,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (goldTick &&
                      (goldTickExpiry?.isAfter(DateTime.now()) ?? false))
                    _TickIcon(
                      color: Colors.amber.shade700,
                      onTap: onGoldTickTap,
                    )
                  else if (blueTick &&
                      (blueTickExpiry?.isAfter(DateTime.now()) ?? false))
                    _TickIcon(color: Colors.blue, onTap: onBlueTickTap),
                ],
              ),
              if (showUsername)
                Text(
                  '@$username',
                  style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _TickIcon extends StatelessWidget {
  final Color color;
  final VoidCallback onTap;

  const _TickIcon({required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: GestureDetector(
        onTap: onTap,
        child: Icon(Icons.verified, color: color, size: 20),
      ),
    );
  }
}

class _FollowRow extends StatelessWidget {
  final int followers, following;

  const _FollowRow({required this.followers, required this.following});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => FollowersListScreen(
                userId: Supabase.instance.client.auth.currentUser!.id,
              ),
            ),
          ),
          child: Text(
            '$followers Followers',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ),
        const SizedBox(width: 16),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => FollowingListScreen(
                userId: Supabase.instance.client.auth.currentUser!.id,
              ),
            ),
          ),
          child: Text(
            '$following Following',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ),
      ],
    );
  }
}

class _ProgressBar extends StatelessWidget {
  final double progress;
  final Map<String, dynamic> levelInfo;
  final int xp;

  const _ProgressBar({
    required this.progress,
    required this.levelInfo,
    required this.xp,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        LinearProgressIndicator(
          value: progress,
          minHeight: 8,
          backgroundColor: Colors.grey[200],
          valueColor: AlwaysStoppedAnimation(levelInfo['color']),
        ),
        const SizedBox(height: 7),
        Text(
          '$xp / ${levelInfo['nextXp']} XP to Level ${levelInfo['level'] >= 12 ? 12 : levelInfo['level'] + 1}',
          style: TextStyle(color: Colors.grey[600], fontSize: 14),
        ),
        const SizedBox(height: 7),
        Row(
          children: [
            Icon(levelInfo['icon'], color: levelInfo['color']),
            const SizedBox(width: 8),
            Text(
              'Level ${levelInfo['level']}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: levelInfo['color'],
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _XpCoinsCard extends StatelessWidget {
  final int xp, coins;
  final Color color;

  const _XpCoinsCard({
    required this.xp,
    required this.coins,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _stat('XP', xp.toString(), color),
            Container(height: 40, width: 1, color: Colors.grey[300]),
            _stat('Coins', coins.toString(), color),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value, Color color) => Column(
    children: [
      Text(
        value,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 18,
          color: color,
        ),
      ),
      const SizedBox(height: 4),
      Text(label, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
    ],
  );
}

class _PostsTab extends StatelessWidget {
  final List<Post> posts;

  const _PostsTab({required this.posts});

  @override
  Widget build(BuildContext context) {
    return posts.isEmpty
        ? const Center(
            child: Text('No posts yet.', style: TextStyle(color: Colors.grey)),
          )
        : ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: posts.length,
            separatorBuilder: (_, _) => const SizedBox(height: 12),
            itemBuilder: (_, i) {
              final p = posts[i];
              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: Colors.grey[200]!),
                ),
                child: ListTile(
                  title: Text(p.content),
                  subtitle: Text(
                    timeago.format(p.createdAt),
                    style: TextStyle(color: Colors.grey[600], fontSize: 12),
                  ),
                  trailing: p.imageUrl != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            p.imageUrl!,
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                          ),
                        )
                      : null,
                ),
              );
            },
          );
  }
}

class _BoostsTab extends StatelessWidget {
  final List<Map<String, dynamic>> reports;

  const _BoostsTab({required this.reports});

  @override
  Widget build(BuildContext context) {
    return reports.isEmpty
        ? const Center(
            child: Text(
              'No boost history.',
              style: TextStyle(color: Colors.grey),
            ),
          )
        : ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: reports.length,
            separatorBuilder: (_, _) => const SizedBox(height: 12),
            itemBuilder: (_, i) {
              final r = reports[i];
              final rate = r['views'] > 0
                  ? ((r['like_count'] + r['comment_count']) / r['views'] * 100)
                        .toStringAsFixed(2)
                  : '0.00';
              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: Colors.grey[200]!),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Boost Report (Post ${r['post_id']})',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Duration: ${timeago.format(r['boost_start'])} - ${timeago.format(r['boost_end'])}',
                      ),
                      Text('Views: ${r['views']}'),
                      Text('Likes: ${r['like_count']}'),
                      Text('Comments: ${r['comment_count']}'),
                      Text('New Followers: ${r['followers_gained']}'),
                      Text('Engagement: $rate%'),
                      TextButton(
                        onPressed: () => showToast('Boost again'),
                        child: const Text(
                          'Boost Again?',
                          style: TextStyle(color: Color(0xFF1DA1F2)),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
  }
}
