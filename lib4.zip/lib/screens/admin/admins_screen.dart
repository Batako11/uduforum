import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import 'package:timeago/timeago.dart' as timeago;

import '/models/post_model.dart';
import '/utils/level_utils.dart';
import 'users_list_screen.dart';
import '../banned/appeal_screen.dart';

// --------------------------------------------------------------------- //
//                          HELPER CLASS
// --------------------------------------------------------------------- //
class AdminNavItem {
  final IconData icon;
  final String label;
  final int badge;

  AdminNavItem({required this.icon, required this.label, this.badge = 0});
}

// --------------------------------------------------------------------- //
//                            MAIN SCREEN
// --------------------------------------------------------------------- //
class AdminsScreen extends StatefulWidget {
  const AdminsScreen({super.key});

  @override
  State<AdminsScreen> createState() => _AdminsScreenState();
}

class _AdminsScreenState extends State<AdminsScreen> {
  final supabase = Supabase.instance.client;
  String? _userRole;
  bool _loading = true;
  String? _error;

  // ---- Data ----
  List<Post> _flaggedPosts = [];
  List<Map<String, dynamic>> _bannedUsers = [];
  List<Map<String, dynamic>> _appeals = [];
  List<Map<String, dynamic>> _reports = [];

  int _totalActiveUsers = 0;
  int _totalUsers = 0;
  int _totalPosts = 0;
  int _pendingReports = 0;

  // ---- Real‑time ----
  RealtimeChannel? _postsSub;
  RealtimeChannel? _usersSub;
  RealtimeChannel? _reportsSub;
  RealtimeChannel? _appealsSub;

  // ---- UI ----
  int _selectedIndex = 0;
  late final PageController _pageCtrl;

  @override
  void initState() {
    super.initState();
    _pageCtrl = PageController();
    _checkUserRole();
    _subscribeToChanges();
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _postsSub?.unsubscribe();
    _usersSub?.unsubscribe();
    _reportsSub?.unsubscribe();
    _appealsSub?.unsubscribe();
    super.dispose();
  }

  // --------------------------------------------------------------------- //
  //                           AUTH & DATA LOAD
  // --------------------------------------------------------------------- //
  Future<void> _checkUserRole() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      if (!mounted) return;
      setState(() => _error = 'You must be logged in');
      return;
    }

    try {
      final data = await supabase
          .from('users')
          .select('role')
          .eq('id', user.id)
          .single();

      final role = data['role'] is List
          ? (data['role'] as List).cast<String>().join(',')
          : data['role']?.toString();

      if (!mounted) return;
      setState(() => _userRole = role);

      if (!(_userRole?.contains('admin') ?? false) &&
          !(_userRole?.contains('moderator') ?? false)) {
        if (!mounted) return;
        setState(() => _error = 'Access denied');
        return;
      }

      await _loadAdminData();
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    }
  }

  Future<void> _loadAdminData() async {
    try {
      final totalUsers = await supabase.from('users').select('id');
      final active = await supabase
          .from('users')
          .select('id')
          .gte(
            'last_active',
            DateTime.now()
                .subtract(const Duration(hours: 24))
                .toIso8601String(),
          );
      final posts = await supabase.from('posts').select('id');

      final flagged = await supabase
          .from('posts')
          .select('''
            id,user_id,content,image_url,created_at,
            users(username,handle,profile_image_url,blue_tick),
            like_count:likes!post_id(count),
            comment_count:comments!post_id(count),
            repost_count:reposts!post_id(count)
          ''')
          .eq('is_flagged', true)
          .order('created_at', ascending: false);

      final banned = await supabase
          .from('users')
          .select('id,username,full_name,banned,last_active')
          .eq('banned', true);

      final reports = await supabase
          .from('user_reports')
          .select('''
             id,user_id,reason,status,created_at,
             reporter:reporter_id(username),
             reported:user_id(username)
          ''')
          .eq('status', 'pending')
          .order('created_at', ascending: false);

      final appeals = await supabase
          .from('ban_appeals')
          .select('''
      id,user_id,reason,appeal_text,status,created_at,
      user:users(username,handle,profile_image_url)
    ''')
          .eq('status', 'pending')
          .order('created_at', ascending: false);

      if (!mounted) return;
      setState(() {
        _totalUsers = totalUsers.length;
        _totalActiveUsers = active.length;
        _totalPosts = posts.length;
        _pendingReports = reports.length;
        _flaggedPosts = (flagged as List).map((m) {
          final u = m['users'] as Map<String, dynamic>?;
          return Post(
            id: m['id'] as String,
            userId: m['user_id'] as String,
            content: m['content'] as String,
            imageUrl: m['image_url'] as String?,
            createdAt: DateTime.parse(m['created_at'] as String),
            username: u?['username'] as String? ?? 'Deleted',
            handle: u?['handle'] as String? ?? '@deleted',
            profileImageUrl: u?['profile_image_url'] as String?,
            likeCount: (m['like_count']?.isNotEmpty == true)
                ? (m['like_count'][0]['count'] as int? ?? 0)
                : 0,
            commentCount: (m['comment_count']?.isNotEmpty == true)
                ? (m['comment_count'][0]['count'] as int? ?? 0)
                : 0,
            repostCount: (m['repost_count']?.isNotEmpty == true)
                ? (m['repost_count'][0]['count'] as int? ?? 0)
                : 0,
            pollVotes: [],
            pollVoteCounts: {},
            isBoosted: false,
            likedByMe: false,
            repostedByMe: false,
            blueTick: u?['blue_tick'] as bool? ?? false,
            goldTick: false,
            level: 1,
            isTrending: false,
          );
        }).toList();

        _bannedUsers = banned;
        _reports = reports;
        _appeals = appeals;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      debugPrint('Load error: $e');
      if (!mounted) return;
      setState(() => _error = e.toString());
    }
  }

  // --------------------------------------------------------------------- //
  //                         REAL‑TIME SUBSCRIPTIONS
  // --------------------------------------------------------------------- //
  void _subscribeToChanges() {
    // Simple reload on any change
    Null reload(PostgresChangePayload payload) {
      if (!mounted) return;
      _loadAdminData();
    }

    _postsSub = supabase
        .channel('posts')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'posts',
          callback: reload,
        )
        .subscribe();

    _usersSub = supabase
        .channel('users')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'users',
          callback: reload,
        )
        .subscribe();

    _reportsSub = supabase
        .channel('user_reports')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'user_reports',
          callback: reload,
        )
        .subscribe();

    // New appeal → toast + reload
    // New appeal → toast + reload
    _appealsSub = supabase
        .channel('ban_appeals')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'ban_appeals',
          callback: (PostgresChangePayload payload) {
            final record = payload.newRecord as Map<String, dynamic>?;
            final userId = record?['user_id']?.toString() ?? 'unknown';
            if (!mounted) return;
            showToast('New ban appeal from user $userId');
            _loadAdminData();
          },
        )
        .subscribe();

    // Status changes (approve / reject) → just reload
    supabase
        .channel('ban_appeals_updates')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'ban_appeals',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'status',
            value: 'pending',
          ),
          callback: reload,
        )
        .subscribe();
  }

  // --------------------------------------------------------------------- //
  //                         NAVIGATION
  // --------------------------------------------------------------------- //
  void _onNavTap(int index) {
    setState(() => _selectedIndex = index);
    _pageCtrl.jumpToPage(index);
    if (Scaffold.of(context).isDrawerOpen) {
      Navigator.pop(context);
    }
  }

  // --------------------------------------------------------------------- //
  //                         UI: DRAWER
  // --------------------------------------------------------------------- //
  Drawer _buildDrawer() {
    final items = [
      AdminNavItem(
        icon: Icons.post_add,
        label: 'Flagged Posts',
        badge: _flaggedPosts.length,
      ),
      AdminNavItem(
        icon: Icons.person,
        label: 'Banned Users',
        badge: _bannedUsers.length,
      ),
      AdminNavItem(
        icon: Icons.report,
        label: 'Reports',
        badge: _pendingReports,
      ),
      AdminNavItem(icon: Icons.gavel, label: 'Appeals', badge: _appeals.length),
    ];

    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Color(0xFF1E88E5)),
            child: Text(
              'Admin Panel',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          ...items.asMap().entries.map((e) {
            final i = e.key;
            final it = e.value;
            return ListTile(
              leading: Icon(it.icon),
              title: Text(it.label),
              trailing: it.badge > 0
                  ? CircleAvatar(
                      radius: 12,
                      backgroundColor: Colors.red,
                      child: Text(
                        '${it.badge}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    )
                  : null,
              selected: _selectedIndex == i,
              selectedTileColor: Colors.blue.withValues(alpha: 0.1),
              onTap: () => _onNavTap(i),
            );
          }),
        ],
      ),
    );
  }

  // --------------------------------------------------------------------- //
  //                         UI: BODY (PageView)
  // --------------------------------------------------------------------- //
  Widget _buildBody() {
    return PageView(
      controller: _pageCtrl,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        // ---- POSTS ----------------------------------------------------
        _flaggedPosts.isEmpty
            ? const Center(child: Text('No flagged posts'))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _flaggedPosts.length,
                itemBuilder: (_, i) {
                  final p = _flaggedPosts[i];
                  final isAdmin = _userRole?.contains('admin') ?? false;
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      title: Text(
                        p.content.length > 50
                            ? '${p.content.substring(0, 50)}...'
                            : p.content,
                      ),
                      subtitle: Text(
                        '${p.username} • ${timeago.format(p.createdAt)}',
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.check, color: Colors.green),
                            tooltip: 'Approve',
                            onPressed: () => _approvePost(p.id),
                          ),
                          if (isAdmin)
                            IconButton(
                              icon: const Icon(Icons.close, color: Colors.red),
                              tooltip: 'Delete',
                              onPressed: () => _rejectPost(p.id),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),

        // ---- USERS ----------------------------------------------------
        _bannedUsers.isEmpty
            ? const Center(child: Text('No banned users'))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _bannedUsers.length,
                itemBuilder: (_, i) {
                  final u = _bannedUsers[i];
                  final last =
                      DateTime.tryParse(u['last_active'] ?? '') ??
                      DateTime.now();
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      title: Text(u['username'] ?? 'Unknown'),
                      subtitle: Text('Banned ${timeago.format(last)}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(
                              Icons.lock_open,
                              color: Colors.green,
                            ),
                            tooltip: 'Unban',
                            onPressed: () => _unbanUser(u['id']),
                          ),
                          PopupMenuButton<String>(
                            onSelected: (r) => _promoteUser(u['id'], r),
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                value: 'moderator',
                                child: Text('Promote to Moderator'),
                              ),
                              PopupMenuItem(
                                value: 'admin',
                                child: Text('Promote to Admin'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

        // ---- REPORTS --------------------------------------------------
        _reports.isEmpty
            ? const Center(child: Text('No pending reports'))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _reports.length,
                itemBuilder: (_, i) {
                  final r = _reports[i];
                  final created =
                      DateTime.tryParse(r['created_at'] ?? '') ??
                      DateTime.now();
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      title: Text(r['reason'] ?? 'No reason'),
                      subtitle: Text(
                        'From: ${r['reporter']?['username'] ?? '??'} to To: ${r['reported']?['username'] ?? '??'} • ${timeago.format(created)}',
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(
                              Icons.check_circle,
                              color: Colors.green,
                            ),
                            tooltip: 'Resolve',
                            onPressed: () => _resolveReport(r['id']),
                          ),
                          IconButton(
                            icon: const Icon(Icons.block, color: Colors.red),
                            tooltip: 'Ban',
                            onPressed: () => _banUser(r['user_id']),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),

        // ---- APPEALS --------------------------------------------------
        _appeals.isEmpty
            ? const Center(child: Text('No pending appeals'))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _appeals.length,
                itemBuilder: (_, i) {
                  final a = _appeals[i];
                  final created =
                      DateTime.tryParse(a['created_at'] ?? '') ??
                      DateTime.now();
                  final user = a['users'] as Map<String, dynamic>?;
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundImage: user?['profile_image_url'] != null
                            ? NetworkImage(user!['profile_image_url'])
                            : const AssetImage('assets/default_avatar.png')
                                  as ImageProvider,
                      ),
                      title: Text(user?['username'] ?? 'Unknown'),
                      subtitle: Text('Submitted ${timeago.format(created)}'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () async {
                        final refreshed = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AppealScreen(appeal: a),
                          ),
                        );
                        if (refreshed == true && mounted) _loadAdminData();
                      },
                    ),
                  );
                },
              ),
      ],
    );
  }

  // --------------------------------------------------------------------- //
  //                         UI: STATS CARD
  // --------------------------------------------------------------------- //
  Widget _buildStat(
    String label,
    String value,
    Color color,
    IconData icon, {
    VoidCallback? onTap,
  }) {
    final child = Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 4),
            Text(
              value,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(fontSize: 12, color: Colors.grey[600]),
          textAlign: TextAlign.center,
        ),
      ],
    );
    return Expanded(
      child: onTap != null ? InkWell(onTap: onTap, child: child) : child,
    );
  }

  // --------------------------------------------------------------------- //
  //                         MAIN BUILD
  // --------------------------------------------------------------------- //
  @override
  Widget build(BuildContext context) {
    final levelInfo = getLevelInfo(0);
    final font = levelInfo['font'];

    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Admin Dashboard')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  if (!mounted) return;
                  setState(() => _loading = true);
                },
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Text(
          'Admin Dashboard',
          style: font.copyWith(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: _loadAdminData,
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: Column(
        children: [
          // === STATS CARD ===
          Card(
            margin: const EdgeInsets.all(16),
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildStat(
                    'Total Users',
                    '$_totalUsers',
                    Colors.purple,
                    Icons.people,
                    onTap: () async {
                      final user = supabase.auth.currentUser;
                      if (user == null) return;
                      final data = await supabase
                          .from('users')
                          .select('role')
                          .eq('id', user.id)
                          .single();
                      final roles = data['role'] is List
                          ? (data['role'] as List).cast<String>()
                          : [data['role'] ?? ''];
                      if (roles.contains('superadmin')) {
                        if (!mounted) return;
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const UsersListScreen(),
                          ),
                        );
                      } else {
                        showToast('Only SuperAdmins can view all users!');
                      }
                    },
                  ),
                  _buildStat(
                    'Online (24h)',
                    '$_totalActiveUsers',
                    Colors.blue,
                    Icons.online_prediction,
                  ),
                  _buildStat(
                    'Total Posts',
                    '$_totalPosts',
                    Colors.green,
                    Icons.post_add,
                  ),
                  _buildStat(
                    'Pending Reports',
                    '$_pendingReports',
                    Colors.orange,
                    Icons.report_problem,
                  ),
                ],
              ),
            ),
          ),

          // === MAIN CONTENT ===
          Expanded(
            child: Row(
              children: [
                if (MediaQuery.of(context).size.width > 800)
                  NavigationRail(
                    selectedIndex: _selectedIndex,
                    onDestinationSelected: _onNavTap,
                    labelType: NavigationRailLabelType.all,
                    destinations: const [
                      NavigationRailDestination(
                        icon: Icon(Icons.post_add),
                        label: Text('Posts'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.person),
                        label: Text('Users'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.report),
                        label: Text('Reports'),
                      ),
                      NavigationRailDestination(
                        icon: Icon(Icons.gavel),
                        label: Text('Appeals'),
                      ),
                    ],
                  ),
                Expanded(child: _buildBody()),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        mini: true,
        backgroundColor: const Color(0xFF1E88E5),
        onPressed: _loadAdminData,
        child: const Icon(Icons.refresh),
      ),
    );
  }

  // --------------------------------------------------------------------- //
  //                         ACTION METHODS
  // --------------------------------------------------------------------- //
  Future<void> _approvePost(String postId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Approve Post'),
        content: const Text('Are you sure?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Approve', style: TextStyle(color: Colors.green)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await supabase
          .from('posts')
          .update({'is_flagged': false})
          .eq('id', postId);
      if (!mounted) return;
      showToast('Post approved!');
      _loadAdminData();
    } catch (e) {
      if (!mounted) return;
      showToast('Failed: $e');
    }
  }

  Future<void> _rejectPost(String postId) async {
    if (!(_userRole?.contains('admin') ?? false)) {
      showToast('Only admins can delete posts');
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Reject Post'),
        content: const Text('This will delete the post permanently.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Reject', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final post = await supabase
          .from('posts')
          .select('image_url')
          .eq('id', postId)
          .single();
      await supabase.from('posts').delete().eq('id', postId);
      if (post['image_url'] != null &&
          post['image_url'].toString().isNotEmpty) {
        final path = post['image_url'].toString().split('/post-images/').last;
        await supabase.storage.from('post-images').remove([path]);
      }
      if (!mounted) return;
      showToast('Post deleted');
      _loadAdminData();
    } catch (e) {
      if (!mounted) return;
      showToast('Failed: $e');
    }
  }

  Future<void> _banUser(String userId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Ban User'),
        content: const Text('Are you sure?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Ban', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await supabase.from('users').update({'banned': true}).eq('id', userId);
    if (!mounted) return;
    showToast('User banned');
    _loadAdminData();
  }

  Future<void> _unbanUser(String userId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Unban User'),
        content: const Text('Are you sure?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Unban', style: TextStyle(color: Colors.green)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await supabase.from('users').update({'banned': false}).eq('id', userId);
    if (!mounted) return;
    showToast('User unbanned');
    _loadAdminData();
  }

  Future<void> _resolveReport(String reportId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Resolve Report'),
        content: const Text('Mark as resolved?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Resolve', style: TextStyle(color: Colors.green)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await supabase
        .from('user_reports')
        .update({'status': 'resolved'})
        .eq('id', reportId);
    if (!mounted) return;
    showToast('Report resolved');
    _loadAdminData();
  }

  Future<void> _promoteUser(String userId, String newRole) async {
    if (!(_userRole?.contains('admin') ?? false)) {
      showToast('Only admins can promote');
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Promote to $newRole'),
        content: Text('Make this user a $newRole?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Promote', style: TextStyle(color: Colors.green)),
          ),
        ],
      ),
    );
    if (ok != true) return;

    final data = await supabase
        .from('users')
        .select('role')
        .eq('id', userId)
        .single();
    List<String> roles = data['role'] is List
        ? (data['role'] as List).cast<String>()
        : data['role'] != null
        ? [data['role'].toString()]
        : [];

    if (!roles.contains(newRole)) {
      roles.add(newRole);
      await supabase.from('users').update({'role': roles}).eq('id', userId);
      if (!mounted) return;
      showToast('Promoted to $newRole');
      _loadAdminData();
    } else {
      showToast('Already $newRole');
    }
  }
}
