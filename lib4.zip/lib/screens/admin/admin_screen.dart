import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:oktoast/oktoast.dart';
import '/utils/level_utils.dart';
import '/models/post_model.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final supabase = Supabase.instance.client;
  int adminCoins = 0;
  int totalUserCoins = 0;
  List<Map<String, dynamic>> transactions = [];
  List<Post> posts = [];
  List<Map<String, dynamic>> blueTickUsers = [];
  List<Map<String, dynamic>> adminModerators = [];
  List<Map<String, dynamic>> coinPurchaseRequests = [];
  bool loading = true;
  String? errorMessage;
  String? userRole;
  String selectedFilter = 'all';

  @override
  void initState() {
    super.initState();
    _checkUserRole();
  }

  Future<void> _checkUserRole() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      setState(() {
        errorMessage = 'You must be logged in';
        loading = false;
      });
      return;
    }

    try {
      final userData = await supabase
          .from('users')
          .select('role')
          .eq('id', user.id)
          .single();

      // Handle both boolean and list
      final dynamic roleValue = userData['role'];
      bool isSuperAdmin = false;

      if (roleValue is List) {
        final roles = roleValue.cast<String>();
        isSuperAdmin = roles.contains('superadmin');
        setState(() {
          userRole = roles.join(', ');
        });
      } else if (roleValue is bool) {
        isSuperAdmin = roleValue; // true = superadmin
        setState(() {
          userRole = roleValue ? 'superadmin' : 'user';
        });
      } else {
        setState(() {
          userRole = 'user';
        });
      }

      if (!isSuperAdmin) {
        setState(() {
          errorMessage = 'Access denied: Superadmin role required';
          loading = false;
        });
        return;
      }

      await _loadAdminData();
    } catch (e) {
      debugPrint('Error checking user role: $e');
      setState(() {
        errorMessage = 'Error checking role: $e';
        loading = false;
      });
    }
  }

  Future<void> _loadAdminData() async {
    try {
      final adminData = await supabase
          .from('admin_balance')
          .select('coins')
          .limit(1)
          .maybeSingle();
      final userCoinsData = await supabase
          .from('users')
          .select('coins')
          .not('coins', 'is', null);
      final transactionData = await supabase
          .from('wallet_transactions')
          .select('*, users(username)')
          .order('created_at', ascending: false)
          .limit(50);
      final postData = await supabase
          .from('posts')
          .select('''
            id, user_id, content, image_url, created_at, poll_options, is_boosted, boost_expires_at,
            users!inner(username, handle, profile_image_url, blue_tick, blue_tick_expiry),
            like_count:likes!post_id(count),
            comment_count:comments!post_id(count),
            repost_count:reposts!post_id(count),
            liked_by_me:likes!post_id(user_id)
          ''')
          .order('created_at', ascending: false)
          .limit(50);
      final blueTickData = await supabase
          .from('users')
          .select('id, username, blue_tick, blue_tick_expiry')
          .eq('blue_tick', true)
          .gt('blue_tick_expiry', DateTime.now().toIso8601String());
      final adminModData = await supabase
          .from('users')
          .select('id, username, role, last_active')
          .or('role.cs.{admin},role.cs.{moderator}')
          .order('last_active', ascending: false);
      final purchaseRequests = await supabase
          .from('coin_purchase_requests')
          .select('*, users!inner(username, email)')
          .eq('status', 'pending')
          .order('created_at', ascending: false);

      if (mounted) {
        setState(() {
          adminCoins = (adminData?['coins'] as int?) ?? 0;
          totalUserCoins = userCoinsData.fold(
            0,
            (sum, item) => sum + ((item['coins'] as int?) ?? 0),
          );
          transactions = List<Map<String, dynamic>>.from(
            transactionData.map((tx) {
              tx['users'] ??= {'username': 'Unknown'};
              return tx;
            }),
          );
          posts = postData.map((map) {
            final m = map;

            // --- BULLETPROOF: Force all list fields to be Lists ---
            final safeMap = {
              ...m,
              'liked_by_me': m['liked_by_me'] is List ? m['liked_by_me'] : [],
              'reposted_by_me': m['reposted_by_me'] is List
                  ? m['reposted_by_me']
                  : [],
              'poll_votes': m['poll_votes'] is List ? m['poll_votes'] : [],
              'likes': m['like_count'] is List ? m['like_count'] : [],
              'comments': m['comment_count'] is List ? m['comment_count'] : [],
              'reposts': m['repost_count'] is List ? m['repost_count'] : [],
              'users': m['users'] is Map<String, dynamic> ? m['users'] : {},
              'channels': m['channels'] is Map ? m['channels'] : null,
              'trending_posts': m['trending_posts'] is Map
                  ? m['trending_posts']
                  : null,
            };

            return Post.fromMap(safeMap);
          }).toList();
          blueTickUsers = List<Map<String, dynamic>>.from(blueTickData);
          adminModerators = List<Map<String, dynamic>>.from(adminModData);
          coinPurchaseRequests = List<Map<String, dynamic>>.from(
            purchaseRequests,
          );
          loading = false;
          errorMessage = null;
        });
      }
    } catch (e) {
      debugPrint('Error loading admin data: $e');
      setState(() {
        errorMessage = 'Failed to load admin data: $e';
        loading = false;
      });
    }
  }

  Future<void> _distributeCoins({String? username, int? amount}) async {
    final TextEditingController amountController = TextEditingController(
      text: amount?.toString(),
    );
    final TextEditingController usernameController = TextEditingController(
      text: username,
    );

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(
          'Distribute Coins',
          style: TextStyle(fontFamily: 'Roboto'),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: usernameController,
              decoration: const InputDecoration(
                labelText: 'Username (leave blank for all users)',
                border: OutlineInputBorder(),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFE5E7EB)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF1DA1F2)),
                ),
              ),
              style: const TextStyle(fontFamily: 'Roboto'),
              enabled: username == null,
            ),
            const SizedBox(height: 8),
            TextField(
              controller: amountController,
              decoration: const InputDecoration(
                labelText: 'Coins to Distribute',
                border: OutlineInputBorder(),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFE5E7EB)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF1DA1F2)),
                ),
              ),
              keyboardType: TextInputType.number,
              style: const TextStyle(fontFamily: 'Roboto'),
              enabled: amount == null,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Color(0xFF1DA1F2), fontFamily: 'Roboto'),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text(
              'Distribute',
              style: TextStyle(color: Color(0xFF1DA1F2), fontFamily: 'Roboto'),
            ),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final inputAmount = int.tryParse(amountController.text) ?? 0;
    final inputUsername = usernameController.text.trim();

    if (inputAmount <= 0 || inputAmount > adminCoins) {
      showToast('Invalid amount or insufficient admin coins');
      return;
    }

    try {
      setState(() => loading = true);

      if (inputUsername.isEmpty) {
        final userData = await supabase.from('users').select('id, coins');
        final userCount = userData.length;
        if (userCount == 0) {
          showToast('No users found to distribute coins');
          return;
        }
        final coinsPerUser = inputAmount ~/ userCount;

        for (var user in userData) {
          final userId = user['id'] as String;
          final currentCoins = (user['coins'] as int?) ?? 0;
          await supabase
              .from('users')
              .update({'coins': currentCoins + coinsPerUser})
              .eq('id', userId);
        }

        await supabase
            .from('wallet_transactions')
            .insert(
              userData
                  .map(
                    (user) => {
                      'user_id': user['id'],
                      'type': 'coin_credit',
                      'amount': coinsPerUser,
                      'description': 'Admin coin distribution',
                      'created_at': DateTime.now().toIso8601String(),
                    },
                  )
                  .toList(),
            );
      } else {
        final userData = await supabase
            .from('users')
            .select('id, coins')
            .eq('username', inputUsername)
            .single();
        final userId = userData['id'] as String;
        final currentCoins = (userData['coins'] as int?) ?? 0;

        await supabase
            .from('users')
            .update({'coins': currentCoins + inputAmount})
            .eq('id', userId);

        await supabase.from('wallet_transactions').insert({
          'user_id': userId,
          'type': 'coin_credit',
          'amount': inputAmount,
          'description': 'Admin coin distribution to $inputUsername',
          'created_at': DateTime.now().toIso8601String(),
        });
      }

      final adminBalanceId = (await supabase
          .from('admin_balance')
          .select('id')
          .single())['id'];
      await supabase
          .from('admin_balance')
          .update({
            'coins': adminCoins - inputAmount,
            'updated_at': DateTime.now().toIso8601String(),
          })
          .eq('id', adminBalanceId);

      showToast('✅ Coins distributed successfully!');
      await _loadAdminData();
    } catch (e) {
      debugPrint('Error distributing coins: $e');
      showToast('Failed to distribute coins: $e');
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> _demoteUser(String userId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Demote User'),
        content: const Text(
          'Are you sure you want to demote this user to regular user?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Demote', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await supabase
          .from('users')
          .update({
            'role': ['user'],
          })
          .eq('id', userId);
      showToast('✅ User demoted to regular user!');
      await _loadAdminData();
    } catch (e) {
      debugPrint('Error demoting user: $e');
      showToast('Failed to demote user: $e');
    }
  }

  Future<void> _processPurchaseRequest(
    String requestId,
    String username,
    int amount,
    bool approve,
  ) async {
    try {
      if (approve) {
        await _distributeCoins(username: username, amount: amount);
        await supabase
            .from('coin_purchase_requests')
            .update({'status': 'approved'})
            .eq('id', requestId);
        final userData = await supabase
            .from('users')
            .select('id')
            .eq('username', username)
            .single();
        await supabase.from('notifications').insert({
          'user_id': userData['id'],
          'actor_id': supabase.auth.currentUser!.id,
          'type': 'coin_purchase_approved',
          'message': 'Your purchase of $amount coins was approved!',
          'created_at': DateTime.now().toIso8601String(),
        });
      } else {
        await supabase
            .from('coin_purchase_requests')
            .update({'status': 'rejected'})
            .eq('id', requestId);
        final userData = await supabase
            .from('users')
            .select('id')
            .eq('username', username)
            .single();
        await supabase.from('notifications').insert({
          'user_id': userData['id'],
          'actor_id': supabase.auth.currentUser!.id,
          'type': 'coin_purchase_rejected',
          'message': 'Your purchase request for $amount coins was rejected.',
          'created_at': DateTime.now().toIso8601String(),
        });
      }
      showToast(approve ? 'Purchase approved!' : 'Purchase rejected.');
      await _loadAdminData();
    } catch (e) {
      debugPrint('Error processing purchase request: $e');
      showToast('Failed to process request: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final levelInfo = getLevelInfo(0);
    final font = levelInfo['font'] as TextStyle;

    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }

    if (errorMessage != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text(
            'Admin Dashboard',
            style: TextStyle(fontFamily: 'Roboto'),
          ),
          backgroundColor: Colors.white,
          elevation: 0.5,
        ),
        body: Center(
          child: Text(
            errorMessage!,
            style: const TextStyle(
              color: Colors.red,
              fontSize: 14,
              fontFamily: 'Roboto',
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Text(
          'Admin Dashboard',
          style: font.copyWith(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: (font.fontSize ?? 16.0).toDouble(),
            fontFamily: 'Roboto',
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadAdminData,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(color: Color(0xFF1DA1F2)),
              ),
              elevation: 2,
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Coin System Overview',
                      style: font.copyWith(
                        fontSize: (font.fontSize ?? 18.0).toDouble(),
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1DA1F2),
                        fontFamily: 'Roboto',
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Expanded(
                          child: _buildStat(
                            'Admin Balance',
                            '$adminCoins',
                            Color(0xFF1DA1F2),
                          ),
                        ),
                        Expanded(
                          child: _buildStat(
                            'Total User Coins',
                            '$totalUserCoins',
                            Color(0xFF1DA1F2),
                          ),
                        ),
                        Expanded(
                          child: _buildStat(
                            'System Total',
                            '${adminCoins + totalUserCoins}/1,000,000',
                            Color(0xFF1DA1F2),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Earnings: 5 coins/post, 5 coins/ad, 5 XP/comment, 100 XP = 4 coins',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF757575),
                        fontFamily: 'Roboto',
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _distributeCoins,
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF1DA1F2),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              icon: const Icon(Icons.monetization_on, size: 20),
              label: const Text(
                'Distribute Coins',
                style: TextStyle(fontFamily: 'Roboto'),
              ),
            ),
            const SizedBox(height: 20),
            ExpansionTile(
              title: Text(
                'Coin Purchase Requests (${coinPurchaseRequests.length})',
                style: font.copyWith(
                  fontSize: (font.fontSize ?? 18.0).toDouble(),
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  fontFamily: 'Roboto',
                ),
              ),
              initiallyExpanded: coinPurchaseRequests.isNotEmpty,
              children: coinPurchaseRequests.isEmpty
                  ? [
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'No pending coin purchase requests.',
                          style: TextStyle(
                            color: Color(0xFF757575),
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ),
                    ]
                  : coinPurchaseRequests
                        .map(
                          (request) => Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                              side: const BorderSide(color: Color(0xFFE0E0E0)),
                            ),
                            elevation: 0,
                            color: Colors.white,
                            child: ListTile(
                              title: Text(
                                'User: ${request['users']['username'] ?? 'Unknown'} (${request['users']['email'] ?? 'N/A'})',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                              subtitle: Text(
                                'Coins: ${request['amount']} (₦${request['amount']}) • ${timeago.format(DateTime.parse(request['created_at']))}',
                                style: const TextStyle(
                                  color: Color(0xFF757575),
                                  fontSize: 12,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(
                                      Icons.cancel,
                                      color: Colors.red,
                                    ),
                                    onPressed: () => _processPurchaseRequest(
                                      request['id'],
                                      request['users']['username'],
                                      request['amount'],
                                      false,
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(
                                      Icons.check_circle,
                                      color: Colors.green,
                                    ),
                                    onPressed: () => _processPurchaseRequest(
                                      request['id'],
                                      request['users']['username'],
                                      request['amount'],
                                      true,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                        .toList(),
            ),
            const SizedBox(height: 20),
            ExpansionTile(
              title: Text(
                'Blue Tick Users (${blueTickUsers.length})',
                style: font.copyWith(
                  fontSize: (font.fontSize ?? 18.0).toDouble(),
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  fontFamily: 'Roboto',
                ),
              ),
              initiallyExpanded: false,
              children: blueTickUsers.isEmpty
                  ? [
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'No users with active Blue Ticks.',
                          style: TextStyle(
                            color: Color(0xFF757575),
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ),
                    ]
                  : blueTickUsers
                        .map(
                          (user) => Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                              side: const BorderSide(color: Color(0xFFE0E0E0)),
                            ),
                            elevation: 0,
                            color: Colors.white,
                            child: ListTile(
                              title: Text(
                                user['username'] ?? 'Unknown',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                              subtitle: Text(
                                'Expires: ${user['blue_tick_expiry'] != null ? DateTime.parse(user['blue_tick_expiry']).toLocal().toString().substring(0, 16) : 'N/A'}',
                                style: const TextStyle(
                                  color: Color(0xFF757575),
                                  fontSize: 12,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                            ),
                          ),
                        )
                        .toList(),
            ),
            const SizedBox(height: 20),
            ExpansionTile(
              title: Text(
                'Recent Posts (${posts.length})',
                style: font.copyWith(
                  fontSize: (font.fontSize ?? 18.0).toDouble(),
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  fontFamily: 'Roboto',
                ),
              ),
              initiallyExpanded: false,
              children: posts.isEmpty
                  ? [
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'No posts yet.',
                          style: TextStyle(
                            color: Color(0xFF757575),
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ),
                    ]
                  : posts
                        .map(
                          (post) => Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                              side: const BorderSide(color: Color(0xFFE0E0E0)),
                            ),
                            elevation: 0,
                            color: Colors.white,
                            child: ListTile(
                              title: Text(
                                post.content.length > 50
                                    ? '${post.content.substring(0, 50)}...'
                                    : post.content,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                              subtitle: Text(
                                '${post.username}${post.blueTick && (post.blueTickExpiry?.isAfter(DateTime.now()) ?? false) ? ' ✅' : ''} • ${DateTime.now().difference(post.createdAt).inHours}h ago',
                                style: const TextStyle(
                                  color: Color(0xFF757575),
                                  fontSize: 12,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                            ),
                          ),
                        )
                        .toList(),
            ),
            const SizedBox(height: 20),
            ExpansionTile(
              title: Text(
                'Admins & Moderators (${adminModerators.length})',
                style: font.copyWith(
                  fontSize: (font.fontSize ?? 18.0).toDouble(),
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                  fontFamily: 'Roboto',
                ),
              ),
              initiallyExpanded: false,
              children: adminModerators.isEmpty
                  ? [
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'No admins or moderators found.',
                          style: TextStyle(
                            color: Color(0xFF757575),
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ),
                    ]
                  : adminModerators
                        .map(
                          (user) => Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                              side: const BorderSide(color: Color(0xFFE0E0E0)),
                            ),
                            elevation: 0,
                            color: Colors.white,
                            child: ListTile(
                              title: Text(
                                user['username'] ?? 'Unknown',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                              subtitle: Text(
                                'Role: ${user['role'] is List ? (user['role'] as List).cast<String>().join(', ') : (user['role'] == true ? 'admin' : 'user')} • Last Active: ${timeago.format(DateTime.parse(user['last_active'] ?? DateTime.now().toIso8601String()))}',
                                style: const TextStyle(
                                  color: Color(0xFF757575),
                                  fontSize: 12,
                                  fontFamily: 'Roboto',
                                ),
                              ),
                              trailing: IconButton(
                                icon: const Icon(
                                  Icons.remove_circle,
                                  color: Colors.red,
                                ),
                                onPressed: () => _demoteUser(user['id']),
                              ),
                            ),
                          ),
                        )
                        .toList(),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Recent Transactions',
                  style: font.copyWith(
                    fontSize: (font.fontSize ?? 18.0).toDouble(),
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                    fontFamily: 'Roboto',
                  ),
                ),
                DropdownButton<String>(
                  value: selectedFilter,
                  items: const [
                    DropdownMenuItem(
                      value: 'all',
                      child: Text(
                        'All',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'poll',
                      child: Text(
                        'Polls',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'boost',
                      child: Text(
                        'Boosts',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'blue_tick_purchase',
                      child: Text(
                        'Blue Tick Purchases',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'gift_sent',
                      child: Text(
                        'Gifts Sent',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'gift_received',
                      child: Text(
                        'Gifts Received',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'coin_credit',
                      child: Text(
                        'Coin Credits',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'coin_debit',
                      child: Text(
                        'Coin Debits',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'xp_credit',
                      child: Text(
                        'XP Credits',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'xp_debit',
                      child: Text(
                        'XP Debits',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'coin_purchase_approved',
                      child: Text(
                        'Coin Purchases',
                        style: TextStyle(fontFamily: 'Roboto'),
                      ),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => selectedFilter = value);
                    }
                  },
                  style: const TextStyle(
                    color: Colors.black87,
                    fontFamily: 'Roboto',
                  ),
                  dropdownColor: Colors.white,
                  underline: Container(height: 1, color: Color(0xFF1DA1F2)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (transactions.isEmpty)
              const Text(
                'No transactions yet.',
                style: TextStyle(
                  color: Color(0xFF757575),
                  fontFamily: 'Roboto',
                ),
              )
            else
              ...transactions
                  .where(
                    (tx) =>
                        selectedFilter == 'all' || tx['type'] == selectedFilter,
                  )
                  .map((tx) {
                    String title;
                    Color titleColor;

                    switch (tx['type']) {
                      case 'xp_credit':
                        title = 'XP +${tx['amount'] ?? 0}';
                        titleColor = Colors.green;
                        break;
                      case 'xp_debit':
                        title = 'XP -${tx['amount'] ?? 0}';
                        titleColor = Colors.red;
                        break;
                      case 'coin_credit':
                        title = 'Coins +${tx['amount'] ?? 0} (Admin)';
                        titleColor = Colors.green;
                        break;
                      case 'coin_debit':
                        title = 'Coins -${tx['amount'] ?? 0} (User)';
                        titleColor = Colors.red;
                        break;
                      case 'poll':
                        title = 'Poll -${tx['amount'] ?? 0} coins (to Admin)';
                        titleColor = Colors.red;
                        break;
                      case 'boost':
                        title = 'Boost -${tx['amount'] ?? 0} coins (to Admin)';
                        titleColor = Colors.red;
                        break;
                      case 'blue_tick_purchase':
                        title =
                            'Blue Tick -${tx['amount'] ?? 0} coins (to Admin)';
                        titleColor = Colors.red;
                        break;
                      case 'gift_sent':
                        title = 'Gift Sent -${tx['amount'] ?? 0} coins';
                        titleColor = Colors.red;
                        break;
                      case 'gift_received':
                        title = 'Gift Received';
                        titleColor = Colors.green;
                        break;
                      case 'coin_purchase_approved':
                        title = 'Coin Purchase +${tx['amount'] ?? 0} coins';
                        titleColor = Colors.green;
                        break;
                      default:
                        title = 'Unknown ${tx['amount'] ?? 0}';
                        titleColor = Colors.grey;
                    }

                    return Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                        side: const BorderSide(color: Color(0xFFE0E0E0)),
                      ),
                      elevation: 0,
                      color: Colors.white,
                      child: ListTile(
                        title: Text(
                          title,
                          style: TextStyle(
                            color: titleColor,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                          ),
                        ),
                        subtitle: Text(
                          '${tx['description'] ?? 'Transaction'} • User ${tx['users']['username'] ?? tx['user_id']?.substring(0, 8) ?? 'Unknown'} • ${DateTime.parse(tx['created_at'] ?? DateTime.now().toIso8601String()).toLocal().toString().substring(0, 16)}',
                          style: const TextStyle(
                            color: Color(0xFF757575),
                            fontSize: 12,
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ),
                    );
                  }),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(String label, String value, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: color,
            fontFamily: 'Roboto',
            overflow: TextOverflow.ellipsis,
          ),
          maxLines: 1,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Color(0xFF757575),
            fontFamily: 'Roboto',
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
        ),
      ],
    );
  }
}
