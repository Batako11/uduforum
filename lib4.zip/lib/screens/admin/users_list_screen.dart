// screens/users_list_screen.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';

class UsersListScreen extends StatefulWidget {
  const UsersListScreen({super.key});

  @override
  State<UsersListScreen> createState() => _UsersListScreenState();
}

class _UsersListScreenState extends State<UsersListScreen> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _checkRoleAndLoad();
  }

  Future<void> _checkRoleAndLoad() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      Navigator.pop(context);
      return;
    }

    try {
      final data = await supabase
          .from('users')
          .select('role')
          .eq('id', user.id)
          .single();

      List<String> roles = data['role'] is List
          ? (data['role'] as List).cast<String>()
          : data['role'] != null
          ? [data['role'] as String]
          : [];

      setState(() {});

      if (!roles.contains('superadmin')) {
        showToast('Only SuperAdmins can access this!');
        if (mounted) Navigator.pop(context);
        return;
      }

      await _loadUsers();
    } catch (e) {
      showToast('Error: $e');
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> _loadUsers() async {
    try {
      final users = await supabase
          .from('users')
          .select(
            'id, username, full_name, email, role, blue_tick, gold_tick, created_at',
          )
          .order('created_at', ascending: false);

      setState(() {
        _users = users;
        _loading = false;
      });
    } catch (e) {
      showToast('Failed to load users');
      setState(() => _loading = false);
    }
  }

  Future<void> _promoteUser(String userId, String newRole) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Promote to $newRole'),
        content: Text('Make this user a $newRole?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Promote', style: TextStyle(color: Colors.green)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final userData = await supabase
          .from('users')
          .select('role')
          .eq('id', userId)
          .single();
      List<String> currentRoles = userData['role'] is List
          ? (userData['role'] as List).cast<String>()
          : userData['role'] != null
          ? [userData['role'] as String]
          : [];

      if (currentRoles.contains(newRole)) {
        showToast('Already a $newRole!');
        return;
      }

      currentRoles.add(newRole);
      await supabase
          .from('users')
          .update({'role': currentRoles})
          .eq('id', userId);
      showToast('User promoted to $newRole!');
      _loadUsers();
    } catch (e) {
      showToast('Failed: $e');
    }
  }

  Future<void> _toggleTick(
    String userId,
    String tickType,
    bool currentValue,
  ) async {
    final action = currentValue ? 'Remove' : 'Add';
    final tickName = tickType == 'blue_tick' ? 'Blue Tick' : 'Gold Tick';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('$action $tickName'),
        content: Text('$action $tickName for this user?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              action,
              style: TextStyle(color: currentValue ? Colors.red : Colors.green),
            ),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await supabase
          .from('users')
          .update({tickType: !currentValue})
          .eq('id', userId);

      showToast('$tickName ${!currentValue ? 'added' : 'removed'}!');
      _loadUsers();
    } catch (e) {
      showToast('Failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('All Users'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadUsers),
        ],
      ),
      body: _users.isEmpty
          ? const Center(child: Text('No users found'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _users.length,
              itemBuilder: (context, index) {
                final user = _users[index];
                final roles = user['role'] is List
                    ? (user['role'] as List).cast<String>().join(', ')
                    : user['role'] ?? 'user';

                final bool hasBlueTick = user['blue_tick'] as bool? ?? false;
                final bool hasGoldTick = user['gold_tick'] as bool? ?? false;

                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: hasGoldTick
                          ? Colors.amber.shade100
                          : hasBlueTick
                          ? Colors.blue.shade100
                          : null,
                      child: Text(
                        user['username']?[0].toUpperCase() ?? '?',
                        style: TextStyle(
                          color: hasGoldTick
                              ? Colors.amber.shade800
                              : hasBlueTick
                              ? Colors.blue.shade800
                              : null,
                        ),
                      ),
                    ),
                    title: Row(
                      children: [
                        Expanded(child: Text(user['username'] ?? 'Unknown')),
                        if (hasGoldTick)
                          const Icon(
                            Icons.verified,
                            color: Colors.amber,
                            size: 18,
                          ),
                        if (hasBlueTick && !hasGoldTick)
                          const Icon(
                            Icons.verified,
                            color: Colors.blue,
                            size: 18,
                          ),
                      ],
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user['email'] ?? 'No email'),
                        Text(
                          'Roles: $roles',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'moderator' || value == 'admin') {
                          _promoteUser(user['id'], value);
                        } else if (value == 'toggle_blue') {
                          _toggleTick(user['id'], 'blue_tick', hasBlueTick);
                        } else if (value == 'toggle_gold') {
                          _toggleTick(user['id'], 'gold_tick', hasGoldTick);
                        }
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(
                          value: 'moderator',
                          child: Text('Promote to Moderator'),
                        ),
                        const PopupMenuItem(
                          value: 'admin',
                          child: Text('Promote to Admin'),
                        ),
                        const PopupMenuDivider(),
                        PopupMenuItem(
                          value: 'toggle_blue',
                          child: Row(
                            children: [
                              Icon(
                                hasBlueTick
                                    ? Icons.verified
                                    : Icons.verified_outlined,
                                color: hasBlueTick ? Colors.blue : Colors.grey,
                                size: 16,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                hasBlueTick
                                    ? 'Remove Blue Tick'
                                    : 'Add Blue Tick',
                                style: TextStyle(
                                  color: hasBlueTick ? Colors.red : Colors.blue,
                                ),
                              ),
                            ],
                          ),
                        ),
                        PopupMenuItem(
                          value: 'toggle_gold',
                          child: Row(
                            children: [
                              Icon(
                                hasGoldTick
                                    ? Icons.verified
                                    : Icons.verified_outlined,
                                color: hasGoldTick ? Colors.amber : Colors.grey,
                                size: 16,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                hasGoldTick
                                    ? 'Remove Gold Tick'
                                    : 'Add Gold Tick',
                                style: TextStyle(
                                  color: hasGoldTick
                                      ? Colors.red
                                      : Colors.amber.shade700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
