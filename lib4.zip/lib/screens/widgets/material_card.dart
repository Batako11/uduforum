// lib/widgets/material_card.dart
import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../services/offline_service.dart';
import '/models/material_model.dart';
import '../library/material_detail_screen.dart';

class MaterialCard extends StatelessWidget {
  final MaterialModel material;

  const MaterialCard({super.key, required this.material});

  String getTypeLabel() {
    switch (material.type) {
      case 'past_question':
        return 'Past Questions';
      case 'handout':
        return 'Handout';
      case 'slides':
        return 'Slides';
      case 'textbook':
        return 'Textbook';
      case 'assignment':
        return 'Assignment';
      default:
        return 'File';
    }
  }

  Widget? getPopularityBadge() {
    if (material.downloadsCount >= 1000) {
      return Row(
        children: const [
          Icon(Icons.local_fire_department, color: Colors.red, size: 18),
          SizedBox(width: 4),
          Text(
            'Very Popular',
            style: TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      );
    }
    if (material.downloadsCount >= 500) {
      return Row(
        children: const [
          Icon(Icons.whatshot, color: Colors.orange, size: 18),
          SizedBox(width: 4),
          Text(
            'Popular',
            style: TextStyle(
              color: Colors.orange,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      );
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final badge = getPopularityBadge();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      elevation: 4,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => MaterialDetailScreen(material: material),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Course Code + Title
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      material.courseCode,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      material.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Uploader + Time
              Row(
                children: [
                  CircleAvatar(
                    radius: 14,
                    backgroundImage: material.uploaderAvatar != null
                        ? NetworkImage(material.uploaderAvatar!)
                        : null,
                    child: material.uploaderAvatar == null
                        ? Text(
                            material.uploaderName.isNotEmpty
                                ? material.uploaderName[0].toUpperCase()
                                : '?',
                            style: const TextStyle(fontSize: 12),
                          )
                        : null,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'by ${material.uploaderName}',
                      style: TextStyle(color: Colors.grey[700], fontSize: 13),
                    ),
                  ),
                  Text(
                    timeago.format(material.createdAt),
                    style: TextStyle(color: Colors.grey[600], fontSize: 12),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Type + Popularity + Downloads + Action
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Type Badge
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      getTypeLabel(),
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Popularity Badge
                  if (badge != null) ...[badge, const SizedBox(width: 12)],

                  // Download Count
                  const Icon(
                    Icons.download_rounded,
                    size: 18,
                    color: Colors.grey,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '${material.downloadsCount}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[800],
                      fontSize: 13,
                    ),
                  ),

                  const Spacer(),

                  // Action button (Download / Open)
                  ValueListenableBuilder(
                    valueListenable: OfflineService.listenable,
                    builder: (context, box, _) {
                      final localPath = OfflineService.getLocalPath(
                        material.id,
                      );
                      final isDownloaded = localPath != null;

                      return ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        icon: Icon(
                          isDownloaded ? Icons.open_in_new : Icons.download,
                          size: 18,
                        ),
                        label: Text(isDownloaded ? 'Open' : 'Download'),
                        onPressed: () {
                          if (isDownloaded) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    MaterialDetailScreen(material: material),
                              ),
                            );
                            return;
                          }

                          // Trigger download and show feedback
                          OfflineService.downloadMaterial(
                                material.id,
                                material.fileUrl,
                                material.title,
                              )
                              .then((_) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Download started'),
                                  ),
                                );
                              })
                              .catchError((e) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Download failed: $e'),
                                  ),
                                );
                              });
                        },
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
