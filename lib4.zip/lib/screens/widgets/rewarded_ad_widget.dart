// lib/widgets/rewarded_ad_widget.dart
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '/services/ad_manager.dart';

class RewardedAdManager {
  // Singleton
  static final RewardedAdManager _instance = RewardedAdManager._internal();
  factory RewardedAdManager() => _instance;
  RewardedAdManager._internal();

  RewardedAd? _rewardedAd;
  bool _isLoading = false;
  bool _isRewarded = false;

  void loadAd() {
    if (_isLoading || _rewardedAd != null) return;

    _isLoading = true;
    RewardedAd.load(
      adUnitId: AdManager().rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _isLoading = false;
          _isRewarded = false;
        },
        onAdFailedToLoad: (err) {
          debugPrint('RewardedAd failed: $err');
          _rewardedAd = null;
          _isLoading = false;
        },
      ),
    );
  }

  Future<void> show({
    required BuildContext context,
    required VoidCallback onReward,
  }) async {
    if (!AdManager().rewardedAdEnabled || !AdManager().adsEnabled) {
      onReward();
      return;
    }

    if (!AdManager().canWatchRewardedAd()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please wait before watching again')),
      );
      return;
    }

    if (_rewardedAd == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ad not ready yet, try again soon')),
      );
      loadAd();
      return;
    }

    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _rewardedAd = null;
        loadAd(); // Preload next

        if (_isRewarded) {
          AdManager().recordRewardedAdWatched();
          onReward();
        }
      },
      onAdFailedToShowFullScreenContent: (ad, err) {
        ad.dispose();
        _rewardedAd = null;
        loadAd();
      },
    );

    await _rewardedAd!.show(
      onUserEarnedReward: (ad, reward) {
        _isRewarded = true;
      },
    );
  }
}
