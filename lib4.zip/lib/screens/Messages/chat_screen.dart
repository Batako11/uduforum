import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:open_file/open_file.dart';

class ChatScreen extends StatefulWidget {
  final String conversationId;
  final String otherUserId;
  final String otherUserName;
  final String? otherUserImageUrl;

  const ChatScreen({
    super.key,
    required this.conversationId,
    required this.otherUserId,
    required this.otherUserName,
    this.otherUserImageUrl,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final supabase = Supabase.instance.client;
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();
  final _focusNode = FocusNode();

  List<Map<String, dynamic>> messages = [];
  bool loading = true;
  String? errorMessage;
  RealtimeChannel? _subscription;
  bool _isTyping = false;
  Timer? _typingTimer;
  bool _isUploading = false;

  // Edit state
  String? _editingMessageId;

  @override
  void initState() {
    super.initState();
    _validateConversationId();
    _loadMessages();
    _subscribeToMessages();
    _subscribeToTyping();
  }

  void _validateConversationId() {
    if (!RegExp(
      r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
    ).hasMatch(widget.conversationId)) {
      setState(() {
        errorMessage = 'Invalid conversation ID';
        loading = false;
      });
    }
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _focusNode.dispose();
    _subscription?.unsubscribe();
    _typingTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadMessages() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      if (mounted) {
        setState(() {
          errorMessage = 'You must be logged in';
          loading = false;
        });
      }
      return;
    }

    try {
      final response = await supabase
          .from('messages')
          .select('''
            id, content, created_at, sender_id, is_read, reactions, deleted_for, file_url, file_name, file_type, edited_at,
            users!sender_id(username, full_name, profile_image_url)
          ''')
          .eq('conversation_id', widget.conversationId)
          .order('created_at', ascending: true);

      await supabase
          .from('messages')
          .update({'is_read': true})
          .eq('conversation_id', widget.conversationId)
          .eq('is_read', false)
          .neq('sender_id', user.id);

      if (mounted) {
        setState(() {
          messages = List<Map<String, dynamic>>.from(response)
              .where(
                (m) => !(m['deleted_for'] as List? ?? []).contains(user.id),
              )
              .toList();
          loading = false;
          errorMessage = null;
        });
        _scrollToBottom();
      }
    } catch (e) {
      debugPrint('Error loading messages: $e');
      if (mounted) {
        setState(() {
          errorMessage = 'Failed to load messages';
          loading = false;
        });
      }
    }
  }

  void _sendTypingIndicator(bool isTyping) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      if (isTyping) {
        await supabase.from('typing_indicators').upsert({
          'conversation_id': widget.conversationId,
          'user_id': user.id,
          'created_at': DateTime.now().toIso8601String(),
        });
      } else {
        await supabase
            .from('typing_indicators')
            .delete()
            .eq('conversation_id', widget.conversationId)
            .eq('user_id', user.id);
      }
    } catch (e) {
      debugPrint('Typing indicator error: $e');
    }
  }

  void _subscribeToMessages() {
    _subscription = supabase
        .channel('public:messages:${widget.conversationId}')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'messages',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'conversation_id',
            value: widget.conversationId,
          ),
          callback: (payload) async {
            final newMessage = payload.newRecord;
            final deletedFor = List<String>.from(
              newMessage['deleted_for'] ?? [],
            );
            final currentUserId = supabase.auth.currentUser?.id;

            if (deletedFor.contains(currentUserId)) return;

            final senderResponse = await supabase
                .from('users')
                .select('username, full_name, profile_image_url')
                .eq('id', newMessage['sender_id'])
                .single();

            if (mounted) {
              setState(() {
                messages.add({...newMessage, 'users': senderResponse});
              });
              _scrollToBottom();
            }

            if (newMessage['sender_id'] != currentUserId) {
              await supabase
                  .from('messages')
                  .update({'is_read': true})
                  .eq('id', newMessage['id']);
            }

            await supabase
                .from('conversations')
                .update({'updated_at': DateTime.now().toIso8601String()})
                .eq('id', widget.conversationId);
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'messages',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'conversation_id',
            value: widget.conversationId,
          ),
          callback: (payload) {
            final updated = payload.newRecord;
            final currentUserId = supabase.auth.currentUser?.id;
            final deletedFor = List<String>.from(updated['deleted_for'] ?? []);

            if (deletedFor.contains(currentUserId)) {
              if (mounted) {
                setState(() {
                  messages.removeWhere((m) => m['id'] == updated['id']);
                });
              }
              return;
            }

            if (mounted) {
              setState(() {
                final index = messages.indexWhere(
                  (m) => m['id'] == updated['id'],
                );
                if (index != -1) {
                  messages[index] = {
                    ...messages[index],
                    'content': updated['content'],
                    'reactions': updated['reactions'],
                    'deleted_for': updated['deleted_for'],
                    'edited_at': updated['edited_at'],
                  };
                }
              });
            }
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.delete,
          schema: 'public',
          table: 'messages',
          callback: (payload) {
            final deletedId = payload.oldRecord['id'];
            if (mounted) {
              setState(() {
                messages.removeWhere((m) => m['id'] == deletedId);
              });
            }
          },
        )
        .subscribe();
  }

  void _subscribeToTyping() {
    supabase
        .channel('typing:${widget.conversationId}')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'typing_indicators',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'conversation_id',
            value: widget.conversationId,
          ),
          callback: (payload) {
            final record = payload.newRecord;
            if (record['user_id'] != supabase.auth.currentUser?.id) {
              if (mounted) {
                setState(() => _isTyping = true);
                _typingTimer?.cancel();
                _typingTimer = Timer(const Duration(seconds: 3), () {
                  if (mounted) setState(() => _isTyping = false);
                });
              }
            }
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.delete,
          schema: 'public',
          table: 'typing_indicators',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'conversation_id',
            value: widget.conversationId,
          ),
          callback: (_) {
            if (mounted) setState(() => _isTyping = false);
          },
        )
        .subscribe();
  }

  Future<void> _sendMessage() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('Please log in.');
      return;
    }

    final content = _messageController.text.trim();
    if (content.isEmpty) return;

    final tempId = DateTime.now().millisecondsSinceEpoch.toString();
    final tempMessage = {
      'id': tempId,
      'content': content,
      'sender_id': user.id,
      'created_at': DateTime.now().toIso8601String(),
      'is_read': false,
      'reactions': <String, dynamic>{},
      'deleted_for': <String>[],
      'users': {
        'username': 'You',
        'full_name': user.userMetadata?['full_name'] ?? 'You',
        'profile_image_url': user.userMetadata?['profile_image_url'],
      },
    };

    setState(() {
      // Add temp message only if it's not already there
      if (!messages.any((m) => m['id'] == tempMessage['id'])) {
        messages.add(tempMessage);
      }
      _messageController.clear();
      _editingMessageId = null;
    });
    _scrollToBottom();

    try {
      final response = await supabase
          .from('messages')
          .insert({
            'conversation_id': widget.conversationId,
            'sender_id': user.id,
            'content': content,
            'created_at': DateTime.now().toIso8601String(),
            'is_read': false,
            'reactions': {},
            'deleted_for': [],
          })
          .select()
          .single();

      if (mounted) {
        setState(() {
          final index = messages.indexWhere((m) => m['id'] == tempId);
          if (index != -1) messages[index] = response;
        });
      }
    } catch (e) {
      debugPrint('Send error: $e');
      showToast('Failed to send.');
      setState(() {
        messages.removeWhere((m) => m['id'] == tempId);
      });
    }
  }

  Future<void> _editMessage(String messageId, String newContent) async {
    if (newContent.trim().isEmpty) {
      showToast('Message cannot be empty');
      return;
    }

    try {
      await supabase
          .from('messages')
          .update({
            'content': newContent.trim(),
            'edited_at': DateTime.now().toIso8601String(),
          })
          .eq('id', messageId);

      setState(() {
        _editingMessageId = null;
        _messageController.clear();
      });
      showToast('Message edited');
    } catch (e) {
      debugPrint('Edit error: $e');
      showToast('Failed to edit message');
    }
  }

  void _startEditing(String messageId, String currentContent) {
    setState(() {
      _editingMessageId = messageId;
      _messageController.text = currentContent;
      _focusNode.requestFocus();
    });
    _scrollToBottom();
  }

  void _cancelEditing() {
    setState(() {
      _editingMessageId = null;
      _messageController.clear();
    });
  }

  Future<void> _uploadAndSendFile({
    required File file,
    required String fileName,
    required String mimeType,
  }) async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('Please log in.');
      return;
    }

    setState(() => _isUploading = true);

    final tempId = DateTime.now().millisecondsSinceEpoch.toString();
    final tempMessage = {
      'id': tempId,
      'content': '[Uploading $fileName...]',
      'sender_id': user.id,
      'created_at': DateTime.now().toIso8601String(),
      'is_read': false,
      'users': {
        'username': 'You',
        'full_name': user.userMetadata?['full_name'] ?? 'You',
      },
    };

    setState(() {
      messages.add(tempMessage);
    });
    _scrollToBottom();

    try {
      final path =
          'chat_files/${widget.conversationId}/$tempId-${DateTime.now().millisecondsSinceEpoch}';
      await supabase.storage
          .from('chat-files')
          .upload(
            path,
            file,
            fileOptions: const FileOptions(upsert: false),
            retryAttempts: 3,
          );

      final fileUrl = supabase.storage.from('chat-files').getPublicUrl(path);

      final response = await supabase
          .from('messages')
          .insert({
            'conversation_id': widget.conversationId,
            'sender_id': user.id,
            'content': '',
            'file_url': fileUrl,
            'file_name': fileName,
            'file_type': mimeType,
            'created_at': DateTime.now().toIso8601String(),
            'is_read': false,
            'reactions': {},
            'deleted_for': [],
          })
          .select()
          .single();

      if (mounted) {
        setState(() {
          final index = messages.indexWhere((m) => m['id'] == tempId);
          if (index != -1) messages[index] = response;
          _isUploading = false;
        });
      }
    } catch (e) {
      debugPrint('Upload error: $e');
      showToast('Failed to send file.');
      setState(() {
        messages.removeWhere((m) => m['id'] == tempId);
        _isUploading = false;
      });
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final result = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
    );
    if (result != null) {
      final file = File(result.path);
      final fileName = result.name;
      await _uploadAndSendFile(
        file: file,
        fileName: fileName,
        mimeType: 'image/jpeg',
      );
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result != null && result.files.single.path != null) {
      final file = File(result.files.single.path!);
      final fileName = result.files.single.name;
      final mimeType =
          result.files.single.extension ?? 'application/octet-stream';
      await _uploadAndSendFile(
        file: file,
        fileName: fileName,
        mimeType: mimeType,
      );
    }
  }

  void _showAttachmentPicker() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo, color: Color(0xFF1E88E5)),
              title: const Text('Photo'),
              onTap: () {
                Navigator.pop(context);
                _pickImage();
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_file, color: Color(0xFF1E88E5)),
              title: const Text('File'),
              onTap: () {
                Navigator.pop(context);
                _pickFile();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _addReaction(String messageId, String emoji) async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final response = await supabase
          .from('messages')
          .select('reactions')
          .eq('id', messageId)
          .single();

      final current = Map<String, dynamic>.from(response['reactions'] ?? {});
      final userReactions = List<String>.from(current[userId] ?? []);

      if (userReactions.contains(emoji)) {
        userReactions.remove(emoji);
      } else {
        userReactions.add(emoji);
      }

      if (userReactions.isEmpty) {
        current.remove(userId);
      } else {
        current[userId] = userReactions;
      }

      await supabase
          .from('messages')
          .update({'reactions': current})
          .eq('id', messageId);
    } catch (e) {
      debugPrint('Reaction error: $e');
    }
  }

  void _showReactionPicker(String messageId) {
    final emojis = ['✅', '❤️', '😂', '😮', '😢', '😡'];

    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          alignment: WrapAlignment.center,
          children: emojis.map((emoji) {
            return IconButton(
              icon: Text(emoji, style: const TextStyle(fontSize: 26)),
              onPressed: () {
                _addReaction(messageId, emoji);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  void _showMessageOptions(String messageId, bool isMe, String content) {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            if (isMe && content.isNotEmpty)
              ListTile(
                leading: const Icon(Icons.edit, color: Colors.blue),
                title: const Text('Edit'),
                onTap: () {
                  Navigator.pop(context);
                  _startEditing(messageId, content);
                },
              ),
            ListTile(
              leading: Icon(
                isMe ? Icons.delete : Icons.delete_outline,
                color: Colors.red,
              ),
              title: Text(isMe ? 'Delete' : 'Delete for me'),
              onTap: () {
                Navigator.pop(context);
                _showDeleteDialog(messageId, isMe);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteDialog(String messageId, bool isMe) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Message'),
        content: Text(
          isMe
              ? 'Delete for everyone or just for you?'
              : 'Delete for you only?',
        ),
        actions: [
          if (isMe)
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _deleteForMe(messageId);
              },
              child: const Text('For Me'),
            ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              if (isMe) {
                _deleteForEveryone(messageId);
              } else {
                _deleteForMe(messageId);
              }
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: Text(isMe ? 'For Everyone' : 'Delete'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteForMe(String messageId) async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final response = await supabase
          .from('messages')
          .select('deleted_for')
          .eq('id', messageId)
          .single();

      final deletedFor = List<String>.from(response['deleted_for'] ?? []);
      if (!deletedFor.contains(userId)) {
        deletedFor.add(userId);
      }

      await supabase
          .from('messages')
          .update({'deleted_for': deletedFor})
          .eq('id', messageId);

      setState(() {
        messages.removeWhere((m) => m['id'] == messageId);
      });
    } catch (e) {
      debugPrint('Delete for me error: $e');
    }
  }

  Future<void> _deleteForEveryone(String messageId) async {
    try {
      await supabase.from('messages').delete().eq('id', messageId);
      showToast('Message deleted for everyone');
    } catch (e) {
      debugPrint('Delete for everyone error: $e');
      showToast('Failed to delete');
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = supabase.auth.currentUser;
    bool isMe(String id) => id == user?.id;

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: Colors.grey[200],
              backgroundImage: widget.otherUserImageUrl != null
                  ? NetworkImage(widget.otherUserImageUrl!)
                  : null,
              child: widget.otherUserImageUrl == null
                  ? Text(
                      widget.otherUserName[0].toUpperCase(),
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.otherUserName,
                    style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  if (_isTyping)
                    Text(
                      'typing...',
                      style: TextStyle(color: Colors.green[600], fontSize: 12),
                    ),
                ],
              ),
            ),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1E88E5)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          if (errorMessage != null)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                : messages.isEmpty
                ? Center(
                    child: Text(
                      'No messages yet. Say hi!',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final message = messages[index];
                      final reactions = Map<String, dynamic>.from(
                        message['reactions'] ?? {},
                      );
                      final fileUrl = message['file_url'] as String?;
                      final fileName = message['file_name'] as String?;
                      final fileType = message['file_type'] as String?;
                      final isEdited = message['edited_at'] != null;

                      return GestureDetector(
                        onLongPress: () => _showMessageOptions(
                          message['id'],
                          isMe(message['sender_id']),
                          message['content']?.toString() ?? '',
                        ),
                        onTap: () => _showReactionPicker(message['id']),
                        child: Align(
                          alignment: isMe(message['sender_id'])
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            constraints: BoxConstraints(
                              maxWidth:
                                  MediaQuery.of(context).size.width * 0.75,
                            ),
                            decoration: BoxDecoration(
                              color: isMe(message['sender_id'])
                                  ? const Color(0xFF1E88E5)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(18),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black12,
                                  blurRadius: 2,
                                  offset: const Offset(0, 1),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: isMe(message['sender_id'])
                                  ? CrossAxisAlignment.end
                                  : CrossAxisAlignment.start,
                              children: [
                                if (fileUrl != null && fileName != null)
                                  GestureDetector(
                                    onTap: () => OpenFile.open(fileUrl),
                                    child: Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: isMe(message['sender_id'])
                                            ? Colors.white24
                                            : Colors.grey[100],
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            fileType?.startsWith('image/') ==
                                                    true
                                                ? Icons.image
                                                : Icons.description,
                                            size: 32,
                                            color: isMe(message['sender_id'])
                                                ? Colors.white70
                                                : Colors.black54,
                                          ),
                                          const SizedBox(width: 8),
                                          Expanded(
                                            child: Text(
                                              fileName,
                                              style: TextStyle(
                                                color:
                                                    isMe(message['sender_id'])
                                                    ? Colors.white
                                                    : Colors.black87,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                if (message['content']?.toString().isNotEmpty ==
                                    true)
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        message['content'],
                                        style: TextStyle(
                                          color: isMe(message['sender_id'])
                                              ? Colors.white
                                              : Colors.black87,
                                          fontSize: 15,
                                        ),
                                      ),
                                      if (isEdited)
                                        Text(
                                          ' (edited)',
                                          style: TextStyle(
                                            color: isMe(message['sender_id'])
                                                ? Colors.white70
                                                : Colors.grey[500],
                                            fontSize: 10,
                                            fontStyle: FontStyle.italic,
                                          ),
                                        ),
                                    ],
                                  ),
                                const SizedBox(height: 4),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      timeago.format(
                                        DateTime.parse(message['created_at']),
                                      ),
                                      style: TextStyle(
                                        color: isMe(message['sender_id'])
                                            ? Colors.white70
                                            : Colors.grey[600],
                                        fontSize: 10,
                                      ),
                                    ),
                                    if (isMe(message['sender_id']) &&
                                        message['is_read'] == true)
                                      const Padding(
                                        padding: EdgeInsets.only(left: 4),
                                        child: Icon(
                                          Icons.done_all,
                                          size: 14,
                                          color: Colors.white70,
                                        ),
                                      ),
                                  ],
                                ),
                                if (reactions.isNotEmpty)
                                  Container(
                                    margin: const EdgeInsets.only(top: 4),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 6,
                                      vertical: 2,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(
                                        alpha: 0.25,
                                      ),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Wrap(
                                      spacing: 4,
                                      children: reactions.values
                                          .expand((v) => (v as List))
                                          .toSet() // avoid duplicates
                                          .map(
                                            (emoji) => Text(
                                              emoji,
                                              style: const TextStyle(
                                                fontSize: 14,
                                              ),
                                            ),
                                          )
                                          .toList(),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          if (_isTyping)
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                margin: const EdgeInsets.only(left: 16, bottom: 8),
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('typing', style: TextStyle(color: Colors.grey)),
                    SizedBox(width: 8),
                    SizedBox(
                      width: 12,
                      height: 12,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  ],
                ),
              ),
            ),
          Container(
            padding: const EdgeInsets.all(12),
            color: Colors.white,
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.attach_file, color: Color(0xFF1E88E5)),
                  onPressed: _isUploading ? null : _showAttachmentPicker,
                ),
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    focusNode: _focusNode,
                    decoration: InputDecoration(
                      hintText: _editingMessageId != null
                          ? 'Edit message...'
                          : 'Type a message...',
                      hintStyle: TextStyle(color: Colors.grey[600]),
                      filled: true,
                      fillColor: Colors.grey[100],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 10,
                      ),
                      suffixIcon: _editingMessageId != null
                          ? Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.close, size: 18),
                                  onPressed: _cancelEditing,
                                ),
                                IconButton(
                                  icon: const Icon(
                                    Icons.check,
                                    size: 18,
                                    color: Colors.green,
                                  ),
                                  onPressed: () => _editMessage(
                                    _editingMessageId!,
                                    _messageController.text,
                                  ),
                                ),
                              ],
                            )
                          : null,
                    ),
                    onChanged: (text) {
                      _sendTypingIndicator(text.isNotEmpty);
                    },
                    onSubmitted: (_) => _editingMessageId != null
                        ? _editMessage(
                            _editingMessageId!,
                            _messageController.text,
                          )
                        : _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                FloatingActionButton(
                  mini: true,
                  elevation: 0,
                  backgroundColor: const Color(0xFF1E88E5),
                  onPressed: _isUploading
                      ? null
                      : _editingMessageId != null
                      ? () => _editMessage(
                          _editingMessageId!,
                          _messageController.text,
                        )
                      : _sendMessage,
                  child: const Icon(Icons.send, color: Colors.white, size: 20),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
