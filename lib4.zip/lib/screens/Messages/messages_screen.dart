import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';
import 'chat_screen.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  final supabase = Supabase.instance.client;
  final _searchController = TextEditingController();
  List<Map<String, dynamic>> conversations = [];
  List<Map<String, dynamic>> filteredConversations = [];
  bool loading = true;
  bool isSearching = false;
  String? errorMessage;
  RealtimeChannel? _subscription;

  @override
  void initState() {
    super.initState();
    _loadConversations();
    _subscribeToConversations();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _subscription?.unsubscribe();
    super.dispose();
  }

  Future<void> _loadConversations() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      setState(() {
        errorMessage = 'You must be logged in';
        loading = false;
      });
      return;
    }

    try {
      final user = supabase.auth.currentUser;
      final response = await supabase
          .from('conversations')
          .select('''
    id,
    user1_id,
    user2_id,
    updated_at,
    user1:users!conversations_user1_id_fkey(username, full_name, profile_image_url),
    user2:users!conversations_user2_id_fkey(username, full_name, profile_image_url),
    messages!messages_conversation_id_fkey(content, created_at, sender_id, is_read)
  ''')
          .or('user1_id.eq.${user!.id},user2_id.eq.${user.id}')
          .order('updated_at', ascending: false);

      final validConversations = List<Map<String, dynamic>>.from(response)
          .where((conv) => _isValidUuid(conv['id']))
          .map((conv) {
            final messages = List<Map<String, dynamic>>.from(
              conv['messages'] ?? [],
            );
            messages.sort(
              (a, b) => DateTime.parse(
                b['created_at'],
              ).compareTo(DateTime.parse(a['created_at'])),
            );
            if (messages.isNotEmpty) {
              conv['messages'] = [messages.first]; // keep only the latest
            }
            return conv;
          })
          .toList();

      setState(() {
        conversations = validConversations;
        filteredConversations = validConversations;
        loading = false;
        errorMessage = null;
      });
    } catch (e) {
      debugPrint('Error loading conversations: $e');
      setState(() {
        errorMessage = 'Failed to load conversations';
        loading = false;
      });
    }
  }

  bool _isValidUuid(dynamic id) {
    return id != null &&
        id.toString().isNotEmpty &&
        RegExp(
          r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
          caseSensitive: false,
        ).hasMatch(id.toString());
  }

  void _subscribeToConversations() {
    _subscription = supabase
        .channel('conversations')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'conversations',
          callback: (_) => _loadConversations(),
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'messages',
          callback: (_) => _loadConversations(),
        )
        .subscribe();
  }

  void _filterConversations(String query) {
    final lowerQuery = query.toLowerCase();
    setState(() {
      filteredConversations = conversations.where((conv) {
        final otherUser = conv['user1_id'] == supabase.auth.currentUser!.id
            ? conv['user2']
            : conv['user1'];
        final name = (otherUser['full_name'] ?? '').toLowerCase();
        final username = (otherUser['username'] ?? '').toLowerCase();
        return name.contains(lowerQuery) || username.contains(lowerQuery);
      }).toList();
    });
  }

  int _getUnreadCount(Map<String, dynamic> conv) {
    final messages = (conv['messages'] as List?) ?? [];
    final userId = supabase.auth.currentUser!.id;
    return messages
        .where(
          (m) =>
              (m['is_read'] == false || m['is_read'] == null) &&
              m['sender_id'] != userId,
        )
        .length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: isSearching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: 'Search by name or @username...',
                  border: InputBorder.none,
                  hintStyle: TextStyle(color: Colors.grey[600]),
                ),
                style: const TextStyle(color: Colors.black87),
                onChanged: _filterConversations,
              )
            : const Text(
                'Messages',
                style: TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.bold,
                ),
              ),
        leading: isSearching
            ? IconButton(
                icon: const Icon(Icons.arrow_back, color: Color(0xFF1E88E5)),
                onPressed: () {
                  setState(() {
                    isSearching = false;
                    _searchController.clear();
                    filteredConversations = conversations;
                  });
                },
              )
            : null,
        actions: [
          IconButton(
            icon: Icon(isSearching ? Icons.clear : Icons.search),
            color: const Color(0xFF1E88E5),
            onPressed: () {
              if (isSearching) {
                setState(() {
                  isSearching = false;
                  _searchController.clear();
                  filteredConversations = conversations;
                });
              } else {
                setState(() => isSearching = true);
              }
            },
          ),
        ],
      ),
      // MAIN CONTENT
      body: loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : RefreshIndicator(
              onRefresh: _loadConversations,
              child: filteredConversations.isEmpty
                  ? ListView(
                      children: [
                        const SizedBox(height: 100),
                        Center(
                          child: Text(
                            isSearching
                                ? 'No users found'
                                : 'No conversations yet.',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ],
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: filteredConversations.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 8),
                      itemBuilder: (_, index) {
                        final conv = filteredConversations[index];
                        final otherUser =
                            conv['user1_id'] == supabase.auth.currentUser!.id
                            ? conv['user2']
                            : conv['user1'];
                        final lastMessage =
                            (conv['messages'] as List?)?.isNotEmpty == true
                            ? conv['messages'][0]
                            : null;
                        final unreadCount = _getUnreadCount(conv);

                        return Card(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                            side: BorderSide(color: Colors.grey[200]!),
                          ),
                          elevation: 0,
                          child: ListTile(
                            leading: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                CircleAvatar(
                                  radius: 26,
                                  backgroundColor: Colors.grey[200],
                                  backgroundImage:
                                      otherUser['profile_image_url'] != null
                                      ? NetworkImage(
                                          otherUser['profile_image_url'],
                                        )
                                      : null,
                                  child: otherUser['profile_image_url'] == null
                                      ? Text(
                                          (otherUser['full_name']?.isNotEmpty ==
                                                      true
                                                  ? otherUser['full_name'][0]
                                                  : otherUser['username']?[0] ??
                                                        'U')
                                              .toUpperCase(),
                                          style: const TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black87,
                                          ),
                                        )
                                      : null,
                                ),
                                if (unreadCount > 0)
                                  Positioned(
                                    right: -4,
                                    top: -4,
                                    child: Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: const BoxDecoration(
                                        color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Text(
                                        unreadCount > 99
                                            ? '99+'
                                            : unreadCount.toString(),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                            title: Text(
                              otherUser['full_name']?.isNotEmpty == true
                                  ? otherUser['full_name']
                                  : otherUser['username'] ?? 'Unknown',
                              style: TextStyle(
                                fontWeight: unreadCount > 0
                                    ? FontWeight.bold
                                    : FontWeight.w500,
                                color: Colors.black87,
                              ),
                            ),
                            subtitle: Text(
                              lastMessage != null
                                  ? (lastMessage['content'] as String).length >
                                            35
                                        ? '${(lastMessage['content'] as String).substring(0, 35)}...'
                                        : lastMessage['content']
                                  : 'No messages yet',
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontWeight: unreadCount > 0
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                fontSize: 14,
                              ),
                            ),
                            trailing: lastMessage != null
                                ? Text(
                                    timeago.format(
                                      DateTime.parse(lastMessage['created_at']),
                                    ),
                                    style: TextStyle(
                                      color: Colors.grey[500],
                                      fontSize: 12,
                                    ),
                                  )
                                : null,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    conversationId: conv['id'],
                                    otherUserId:
                                        conv['user1_id'] ==
                                            supabase.auth.currentUser!.id
                                        ? conv['user2_id']
                                        : conv['user1_id'],
                                    otherUserName:
                                        otherUser['full_name']?.isNotEmpty ==
                                            true
                                        ? otherUser['full_name']
                                        : otherUser['username'] ?? 'Unknown',
                                    otherUserImageUrl:
                                        otherUser['profile_image_url'],
                                  ),
                                ),
                              ).then((_) => _loadConversations());
                            },
                          ),
                        );
                      },
                    ),
            ),
      // FIXED BANNER AD AT BOTTOM – ALWAYS VISIBLE
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(height: 0.5, color: Colors.grey[300]),
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }
}
