// lib/screens/channel/channel_follower_screen.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../profile/other_user_profile_screen.dart';
import '../profile/profile_screen.dart';
import '../../services/ad_manager.dart'; // ← ADD THIS
import '../widgets/banner_ad_widget.dart';

class ChannelFollowerScreen extends StatefulWidget {
  final String channelId;
  final List<dynamic> followerIds;
  const ChannelFollowerScreen({
    super.key,
    required this.channelId,
    required this.followerIds,
  });

  @override
  State<ChannelFollowerScreen> createState() => _ChannelFollowerScreenState();
}

class _ChannelFollowerScreenState extends State<ChannelFollowerScreen> {
  List<Map<String, dynamic>> _followers = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetchFollowers();
  }

  Future<void> _fetchFollowers() async {
    if (widget.followerIds.isEmpty) {
      setState(() => _loading = false);
      return;
    }

    try {
      final response = await Supabase.instance.client
          .from('users')
          .select(
            'id, username, handle, profile_image_url, blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry',
          )
          .inFilter('id', widget.followerIds);

      setState(() {
        _followers = List<Map<String, dynamic>>.from(response);
        _loading = false;
      });
    } catch (e) {
      debugPrint('Error fetching followers: $e');
      setState(() => _loading = false);
    }
  }

  void _navigateToProfile(String userId) {
    final currentUserId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == currentUserId) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfileScreen()),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OtherUserProfileScreen(userId: userId),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: Text(
          'Followers (${widget.followerIds.length})',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontFamily: 'Roboto',
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1DA1F2)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : widget.followerIds.isEmpty
          ? const Center(
              child: Text(
                'No followers yet.',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _followers.length,
              itemBuilder: (context, index) {
                final user = _followers[index];
                final isVerified =
                    user['blue_tick'] == true &&
                    user['blue_tick_expiry'] != null &&
                    DateTime.parse(
                      user['blue_tick_expiry'],
                    ).isAfter(DateTime.now());

                return ListTile(
                  onTap: () => _navigateToProfile(user['id']),
                  leading: CircleAvatar(
                    radius: 24,
                    backgroundImage: user['profile_image_url'] != null
                        ? NetworkImage(user['profile_image_url'])
                        : null,
                    child: user['profile_image_url'] == null
                        ? Text(
                            user['username']?[0].toUpperCase() ?? '@',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          )
                        : null,
                  ),
                  title: Row(
                    children: [
                      Text(
                        user['username'] ?? 'User',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      if (isVerified) ...[
                        const SizedBox(width: 4),
                        const Icon(
                          Icons.verified,
                          color: Colors.blue,
                          size: 18,
                        ),
                      ],
                    ],
                  ),
                  subtitle: Text(
                    '@${user['handle'] ?? 'handle'}',
                    style: const TextStyle(color: Colors.grey),
                  ),
                );
              },
            ),
      // FIXED BANNER AD AT BOTTOM
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(height: 0.5, color: Colors.grey[300]),
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }
}
