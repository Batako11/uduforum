import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';
import 'channel_feed_screen.dart';

class DiscoverChannelsScreen extends StatefulWidget {
  const DiscoverChannelsScreen({super.key});

  @override
  State<DiscoverChannelsScreen> createState() => _DiscoverChannelsScreenState();
}

class _DiscoverChannelsScreenState extends State<DiscoverChannelsScreen> {
  final supabase = Supabase.instance.client;
  bool _loading = true;
  List<Map<String, dynamic>> _channels = [];
  List<String> _following = [];

  @override
  void initState() {
    super.initState();
    _loadChannels();
  }

  Future<void> _loadChannels() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('Please log in to discover channels.');
      return;
    }

    try {
      final response = await supabase
          .from('channels')
          .select('id, name, followers, creator_id, profile_image_url')
          .order('created_at', ascending: false);

      final channels = List<Map<String, dynamic>>.from(response);

      setState(() {
        _channels = channels;
        _following = channels
            .where((c) => (c['followers'] as List?)?.contains(user.id) ?? false)
            .map((c) => c['id'] as String)
            .toList();
        _loading = false;
      });
    } catch (e) {
      showToast('Error loading channels: $e');
      setState(() => _loading = false);
    }
  }

  Future<void> _toggleFollow(String channelId) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final isFollowing = _following.contains(channelId);
    try {
      final channel = _channels.firstWhere((c) => c['id'] == channelId);
      final currentFollowers = List<String>.from(channel['followers'] ?? []);

      if (isFollowing) {
        currentFollowers.remove(user.id);
        _following.remove(channelId);
      } else {
        currentFollowers.add(user.id);
        _following.add(channelId);
      }

      await supabase
          .from('channels')
          .update({'followers': currentFollowers})
          .eq('id', channelId);

      setState(() {
        channel['followers'] = currentFollowers;
      });

      showToast(isFollowing ? 'Unfollowed channel' : 'Followed channel');
    } catch (e) {
      showToast('Error updating follow: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset:
          true, // Important for future text fields + FAB safety

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        iconTheme: const IconThemeData(color: Color(0xFF1DA1F2)),
        title: const Text(
          'Discover Channels',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
      ),

      // MAIN CONTENT
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              color: const Color(0xFF1DA1F2),
              onRefresh: _loadChannels,
              child: _channels.isEmpty
                  ? const Center(child: Text('No channels available yet.'))
                  : ListView.builder(
                      padding: const EdgeInsets.only(
                        bottom: 80,
                      ), // ← Prevents content from hiding under banner
                      itemCount: _channels.length,
                      itemBuilder: (context, index) {
                        final channel = _channels[index];
                        final followers = (channel['followers'] as List?) ?? [];
                        final isFollowing = _following.contains(channel['id']);
                        final imageUrl =
                            channel['profile_image_url'] as String?;

                        return Card(
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ListTile(
                            leading: CircleAvatar(
                              radius: 24,
                              backgroundColor: Colors.grey[300],
                              backgroundImage:
                                  imageUrl != null && imageUrl.isNotEmpty
                                  ? NetworkImage(imageUrl)
                                  : null,
                              child: imageUrl == null || imageUrl.isEmpty
                                  ? Text(
                                      channel['name']?[0].toUpperCase() ?? '?',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                    )
                                  : null,
                            ),
                            title: Text(
                              channel['name'] ?? 'Unnamed Channel',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              '${followers.length} followers',
                              style: const TextStyle(color: Colors.grey),
                            ),
                            trailing: ElevatedButton(
                              onPressed: () => _toggleFollow(channel['id']),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: isFollowing
                                    ? Colors.grey[300]
                                    : const Color(0xFF1DA1F2),
                                foregroundColor: isFollowing
                                    ? Colors.black
                                    : Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6),
                                ),
                              ),
                              child: Text(isFollowing ? 'Following' : 'Follow'),
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChannelFeedScreen(
                                    channelId: channel['id'],
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
            ),

      // FIXED BANNER AD AT BOTTOM – NEVER MOVES
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(
                    height: 0.5,
                    color: Colors.grey[300],
                  ), // subtle top line
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }
}
