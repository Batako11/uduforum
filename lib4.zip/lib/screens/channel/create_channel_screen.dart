import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/ad_manager.dart'; // ← ADD THIS
import '../widgets/banner_ad_widget.dart';

class CreateChannelScreen extends StatefulWidget {
  const CreateChannelScreen({super.key});

  @override
  State<CreateChannelScreen> createState() => _CreateChannelScreenState();
}

class _CreateChannelScreenState extends State<CreateChannelScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _handleController = TextEditingController();
  final _descController = TextEditingController();
  bool _allowPublicPost = true;
  bool _loading = false;
  File? _imageFile;

  final supabase = Supabase.instance.client;

  Future<void> _createChannel() async {
    if (!_formKey.currentState!.validate()) return;

    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('Please log in');
      return;
    }

    setState(() => _loading = true);

    try {
      final handle = _handleController.text.trim().replaceAll('@', '');
      if (!RegExp(r'^[a-zA-Z0-9_]+$').hasMatch(handle)) {
        showToast('Handle: letters, numbers, _ only');
        return;
      }

      // Check duplicate handle
      final exists = await supabase
          .from('channels')
          .select('id')
          .eq('handle', handle)
          .maybeSingle();
      if (exists != null) {
        showToast('Handle @$handle taken');
        return;
      }

      // Upload image first (so we have URL)
      String? imageUrl;
      if (_imageFile != null) {
        final channelId = DateTime.now().millisecondsSinceEpoch.toString();
        imageUrl = await _uploadChannelImage(channelId);
        if (imageUrl == null) return;
      }

      // CALL RPC — ONE ATOMIC CALL
      final result = await supabase.rpc(
        'create_channel_with_fee',
        params: {
          'p_user_id': user.id,
          'p_name': _nameController.text.trim(),
          'p_handle': handle,
          'p_description': _descController.text.trim(),
          'p_allow_public_post': _allowPublicPost,
        },
      );

      final channelId = result as String;

      // Update image if uploaded
      if (imageUrl != null) {
        await supabase
            .from('channels')
            .update({'profile_image_url': imageUrl})
            .eq('id', channelId);
      }

      showToast('Channel #${_nameController.text.trim()} created! -500 coins');
      if (mounted) Navigator.pop(context, true);
    } on PostgrestException catch (e) {
      String msg = 'Failed';
      if (e.message.contains('insufficient_coins')) {
        msg = 'You need 500 coins';
      } else if (e.message.contains('duplicate key')) {
        msg = 'Handle already taken';
      } else {
        msg = e.message;
      }
      showToast(msg);
    } catch (e) {
      showToast('Error: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
    );
    if (picked != null) {
      setState(() => _imageFile = File(picked.path));
    }
  }

  Future<String?> _uploadChannelImage(String channelId) async {
    if (_imageFile == null) return null;
    try {
      final fileExt = _imageFile!.path.split('.').last;
      final fileName = '${channelId}_pfp.$fileExt';
      final filePath = 'channel_pfps/$fileName';

      await supabase.storage
          .from('public')
          .upload(
            filePath,
            _imageFile!,
            fileOptions: const FileOptions(upsert: true),
          );

      final publicUrl = supabase.storage.from('public').getPublicUrl(filePath);
      return publicUrl;
    } catch (e) {
      debugPrint('Upload error: $e');
      showToast('Image upload failed.');
      return null;
    }
  }

  // --------------------------------------------------------------------------
  // UI SECTION
  // --------------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Create Channel',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontFamily: 'Roboto',
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1DA1F2)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Center(
                child: GestureDetector(
                  onTap: _pickImage,
                  child: CircleAvatar(
                    radius: 45,
                    backgroundColor: Colors.grey[200],
                    backgroundImage: _imageFile != null
                        ? FileImage(_imageFile!)
                        : null,
                    child: _imageFile == null
                        ? const Icon(
                            Icons.camera_alt,
                            color: Colors.grey,
                            size: 30,
                          )
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Channel Name',
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  hintText: 'e.g. UDUS Newsline',
                ),
                validator: (value) =>
                    value == null || value.isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 16),
              const Text(
                'Handle',
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextFormField(
                controller: _handleController,
                decoration: const InputDecoration(
                  hintText: 'e.g. @udusnewsline',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) return 'Required';
                  if (!RegExp(r'^[a-zA-Z0-9_@]+$').hasMatch(value)) {
                    return 'Only letters, numbers, and underscores allowed';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              const Text(
                'Description',
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextFormField(
                controller: _descController,
                maxLines: 3,
                decoration: const InputDecoration(
                  hintText: 'Tell people what your channel is about...',
                ),
              ),
              const SizedBox(height: 16),
              SwitchListTile(
                title: const Text('Allow Public Posts'),
                subtitle: const Text(
                  'If off, only you can post in this channel',
                ),
                value: _allowPublicPost,
                onChanged: (val) => setState(() => _allowPublicPost = val),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _loading
                    ? null
                    : () async {
                        if (!_formKey.currentState!.validate()) return;
                        await _createChannel();
                      },
                icon: _loading
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.rocket_launch),
                label: const Text('Create Channel (500 coins)'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1DA1F2),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      // FIXED BANNER AD AT BOTTOM – NEVER MOVES WITH KEYBOARD
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(height: 0.5, color: Colors.grey[300]),
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }
}
