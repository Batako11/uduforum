import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';
import 'channel_feed_screen.dart';
import 'create_channel_screen.dart';

class MyChannelsScreen extends StatefulWidget {
  const MyChannelsScreen({super.key});

  @override
  State<MyChannelsScreen> createState() => _MyChannelsScreenState();
}

class _MyChannelsScreenState extends State<MyChannelsScreen> {
  final supabase = Supabase.instance.client;
  bool _loading = true;
  List<Map<String, dynamic>> _channels = [];

  @override
  void initState() {
    super.initState();
    _loadMyChannels();
  }

  Future<void> _loadMyChannels() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('You must be logged in.');
      return;
    }

    try {
      final response = await supabase
          .from('channels')
          .select('id, name, followers, created_at, profile_image_url')
          .eq('creator_id', user.id)
          .order('created_at', ascending: false);

      setState(() {
        _channels = List<Map<String, dynamic>>.from(response);
        _loading = false;
      });
    } catch (e) {
      showToast('Failed to load your channels: $e');
      setState(() => _loading = false);
    }
  }

  Future<void> _openCreateChannel() async {
    final created = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CreateChannelScreen()),
    );
    if (created == true) {
      await _loadMyChannels();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true, // Important for FAB + keyboard

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        iconTheme: const IconThemeData(color: Color(0xFF1DA1F2)),
        title: const Text(
          'My Channels',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontFamily: 'Roboto',
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF1DA1F2),
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('New Channel', style: TextStyle(color: Colors.white)),
        onPressed: _openCreateChannel,
      ),

      // MAIN LIST CONTENT
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              color: const Color(0xFF1DA1F2),
              onRefresh: _loadMyChannels,
              child: _channels.isEmpty
                  ? const Center(
                      child: Text(
                        'You haven’t created any channels yet.',
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.only(
                        bottom: 80,
                      ), // ← Prevents FAB & banner overlap
                      itemCount: _channels.length,
                      itemBuilder: (context, index) {
                        final channel = _channels[index];
                        final followers = (channel['followers'] as List?) ?? [];
                        final imageUrl =
                            channel['profile_image_url'] as String?;

                        return Card(
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ListTile(
                            leading: CircleAvatar(
                              radius: 24,
                              backgroundColor: Colors.grey[300],
                              backgroundImage:
                                  imageUrl != null && imageUrl.isNotEmpty
                                  ? NetworkImage(imageUrl)
                                  : null,
                              child: imageUrl == null || imageUrl.isEmpty
                                  ? Text(
                                      channel['name']?[0].toUpperCase() ?? '?',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                    )
                                  : null,
                            ),
                            title: Text(
                              channel['name'] ?? 'Unnamed Channel',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Roboto',
                              ),
                            ),
                            subtitle: Text(
                              '${followers.length} followers',
                              style: const TextStyle(color: Colors.grey),
                            ),
                            trailing: const Icon(
                              Icons.arrow_forward_ios,
                              size: 16,
                              color: Colors.grey,
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ChannelFeedScreen(
                                    channelId: channel['id'],
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
            ),

      // FIXED BANNER AD AT BOTTOM
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(height: 0.5, color: Colors.grey[300]),
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }
}
