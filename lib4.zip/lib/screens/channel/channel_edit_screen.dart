import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import '../../services/ad_manager.dart'; // ADD THIS
import '../widgets/banner_ad_widget.dart';

class ChannelEditScreen extends StatefulWidget {
  final String channelId;
  const ChannelEditScreen({super.key, required this.channelId});

  @override
  State<ChannelEditScreen> createState() => _ChannelEditScreenState();
}

class _ChannelEditScreenState extends State<ChannelEditScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _channelName;
  String? _channelImageUrl;
  File? _selectedImage;
  bool _isLoading = true;
  bool _isSaving = false;
  bool _isOwner = false;
  final TextEditingController _nameController = TextEditingController();

  // UI knobs
  static const Color channelAccentColor = Color(0xFF1DA1F2);

  @override
  void initState() {
    super.initState();
    _fetchChannelData();
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _fetchChannelData() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        _showError('You must be logged in to edit a channel.');
        Navigator.pop(context);
        return;
      }

      final channelRes = await Supabase.instance.client
          .from('channels')
          .select('name, profile_image_url, creator_id')
          .eq('id', widget.channelId)
          .maybeSingle();

      if (channelRes == null) {
        _showError('Channel not found.');
        if (mounted) Navigator.pop(context);
        return;
      }

      if (channelRes['creator_id'] != userId) {
        _showError('You are not the owner of this channel.');
        if (mounted) Navigator.pop(context);
        return;
      }

      setState(() {
        _channelName = channelRes['name'] as String?;
        _channelImageUrl = channelRes['profile_image_url'] as String?;
        _nameController.text = _channelName ?? '';
        _isOwner = true;
        _isLoading = false;
      });
    } catch (e) {
      _showError('Error fetching channel data: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _pickImage() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        setState(() {
          _selectedImage = File(pickedFile.path);
        });
      }
    } catch (e) {
      _showError('Error picking image: $e');
    }
  }

  Future<void> _saveChanges() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);
    try {
      String? newImageUrl = _channelImageUrl;

      if (_selectedImage != null) {
        final userId = Supabase.instance.client.auth.currentUser!.id;
        final fileName =
            '${widget.channelId}_${DateTime.now().millisecondsSinceEpoch}.jpg';
        final path = 'channel_images/$userId/$fileName';

        final response = await Supabase.instance.client.storage
            .from('public')
            .upload(path, _selectedImage!);

        if (response.isNotEmpty) {
          newImageUrl = Supabase.instance.client.storage
              .from('public')
              .getPublicUrl(path);
        } else {
          throw Exception('Failed to upload image.');
        }
      }

      await Supabase.instance.client
          .from('channels')
          .update({
            'name': _nameController.text.trim(),
            if (newImageUrl != null) 'profile_image_url': newImageUrl,
          })
          .eq('id', widget.channelId);

      showToast('Channel updated successfully.');
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      _showError('Error saving changes: $e');
    } finally {
      setState(() => _isSaving = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        backgroundColor: channelAccentColor,
        title: const Text(
          'Edit Channel',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Roboto',
            fontWeight: FontWeight.w600,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      // MAIN CONTENT
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: channelAccentColor),
            )
          : !_isOwner
          ? const Center(
              child: Text(
                'Access denied.',
                style: TextStyle(fontSize: 16, fontFamily: 'Roboto'),
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: ListView(
                  // Changed from Column → ListView for better scrolling
                  children: [
                    Center(
                      child: GestureDetector(
                        onTap: _pickImage,
                        child: CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.grey[200],
                          backgroundImage: _selectedImage != null
                              ? FileImage(_selectedImage!)
                              : _channelImageUrl?.isNotEmpty == true
                              ? NetworkImage(_channelImageUrl!)
                              : null,
                          child:
                              _selectedImage == null &&
                                  (_channelImageUrl?.isEmpty ?? true)
                              ? const Icon(
                                  Icons.campaign,
                                  size: 50,
                                  color: channelAccentColor,
                                )
                              : null,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Center(
                      child: TextButton(
                        onPressed: _pickImage,
                        child: const Text(
                          'Change Profile Image',
                          style: TextStyle(
                            color: channelAccentColor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    TextFormField(
                      controller: _nameController,
                      decoration: InputDecoration(
                        labelText: 'Channel Name',
                        labelStyle: const TextStyle(fontFamily: 'Roboto'),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(
                            color: channelAccentColor,
                          ),
                        ),
                      ),
                      validator: (value) => value?.trim().isEmpty ?? true
                          ? 'Please enter a channel name'
                          : null,
                    ),
                    const SizedBox(height: 32),
                    Center(
                      child: ElevatedButton(
                        onPressed: _isSaving ? null : _saveChanges,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: channelAccentColor,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 32,
                            vertical: 14,
                          ),
                        ),
                        child: _isSaving
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : const Text(
                                'Save Changes',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(
                      height: 100,
                    ), // Extra space so Save button isn’t hidden behind banner
                  ],
                ),
              ),
            ),

      // FIXED BANNER AD AT BOTTOM – NEVER MOVES WITH KEYBOARD
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(
                    height: 0.5,
                    color: Colors.grey[300],
                  ), // subtle separator
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }
}
