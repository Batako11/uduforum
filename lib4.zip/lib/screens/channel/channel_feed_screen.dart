import 'package:flutter/material.dart';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';
import 'package:share_plus/share_plus.dart' as share_plus;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';
import 'package:oktoast/oktoast.dart';
import '/models/post_model.dart';
import '../feed/post_card.dart';
import '../comment/comment_screen.dart';
import 'channel_follower_screen.dart';
import '../profile/other_user_profile_screen.dart';
import '../profile/profile_screen.dart';
import '../feed/post_create_screen.dart';
import 'channel_edit_screen.dart';
import '../../services/ad_manager.dart';
import '../widgets/native_ad_widget.dart';

class ChannelFeedScreen extends StatefulWidget {
  final String channelId;
  const ChannelFeedScreen({super.key, required this.channelId});

  @override
  State<ChannelFeedScreen> createState() => _ChannelFeedScreenState();
}

class _ChannelCache {
  final String? name;
  final String? imageUrl;
  final List<dynamic> followers;
  final String? creatorId;
  final DateTime? createdAt;
  final int postCount;
  final DateTime cachedAt;

  _ChannelCache({
    required this.name,
    required this.imageUrl,
    required this.followers,
    required this.creatorId,
    required this.createdAt,
    required this.postCount,
    required this.cachedAt,
  });

  bool get isExpired => DateTime.now().difference(cachedAt).inMinutes > 5;
}

class _ChannelFeedScreenState extends State<ChannelFeedScreen> {
  List<Post> _posts = [];
  bool _loading = true;
  bool _hasMorePosts = true;
  String? _channelName;
  String? _channelImage;
  List<dynamic> _followers = [];
  DateTime? _channelCreatedAt;
  int? _postCount;
  final ScrollController _scrollController = ScrollController();
  static final Map<String, _ChannelCache> _cache = {};
  String? _creatorId;
  Post? _lastCursor;
  bool _isFetching = false;
  final int _pageSize = 20;
  bool _isLoadingMore = false;

  // UI knobs
  static const Color channelAccentColor = Color(0xFF1DA1F2);

  @override
  void initState() {
    super.initState();
    _fetchChannelData();
    _scrollController.addListener(_scrollListener);
  }

  bool get _isOwner {
    final currentUserId = Supabase.instance.client.auth.currentUser?.id;
    return currentUserId != null && currentUserId == _creatorId;
  }

  static List<Post> _parsePosts(Map<String, dynamic> input) {
    final List data = input['data'];
    final String? currentUserId = input['currentUserId'];
    return data
        .map((map) => Post.fromMap(map, currentUserId: currentUserId))
        .toList();
  }

  void _showChannelInfo() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundImage: _channelImage?.isNotEmpty == true
                        ? NetworkImage(_channelImage!)
                        : null,
                    child: _channelImage?.isEmpty ?? true
                        ? const Icon(
                            Icons.campaign,
                            size: 30,
                            color: channelAccentColor,
                            semanticLabel: 'Channel icon',
                          )
                        : null,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _channelName ?? 'Channel Info',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Roboto',
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Row(
                        children: [
                          const Icon(
                            Icons.post_add,
                            size: 18,
                            color: Colors.grey,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '${_postCount ?? 0} posts',
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ChannelFollowerScreen(
                                channelId: widget.channelId,
                                followerIds: _followers,
                              ),
                            ),
                          );
                        },
                        child: Row(
                          children: [
                            const Icon(
                              Icons.people_alt,
                              size: 18,
                              color: Colors.blueAccent,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '${_followers.length}',
                              style: const TextStyle(
                                fontSize: 14,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  Row(
                    children: [
                      const Icon(
                        Icons.calendar_today,
                        size: 18,
                        color: Colors.grey,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'Created: ${_formattedCreatedDate()}',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                          fontFamily: 'Roboto',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Center(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.close, size: 20),
                  label: const Text('Close'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey[200],
                    foregroundColor: Colors.black87,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels >
        _scrollController.position.maxScrollExtent - 300) {
      _fetchMorePosts();
    }
  }

  Future<T?> _retry<T>(Future<T> Function() fn, {int retries = 2}) async {
    for (int attempt = 0; attempt <= retries; attempt++) {
      try {
        return await fn();
      } catch (e) {
        if (attempt == retries) {
          _showError('Network error. Please try again.');
          return null;
        }
        await Future.delayed(const Duration(seconds: 1));
      }
    }
    return null;
  }

  Future<void> _fetchChannelData() async {
    // 1. Check cache first
    final cached = _cache[widget.channelId];
    if (cached != null && !cached.isExpired) {
      setState(() {
        _channelName = cached.name;
        _channelImage = cached.imageUrl;
        _followers = List.from(cached.followers);
        _creatorId = cached.creatorId;
        _channelCreatedAt = cached.createdAt;
        _postCount = cached.postCount;
      });
      await _fetchChannelPosts();
      return;
    }

    // 2. Fetch fresh data
    try {
      final channelRes = await Supabase.instance.client
          .from('channels')
          .select('name, profile_image_url, followers, created_at, creator_id')
          .eq('id', widget.channelId)
          .maybeSingle();

      if (channelRes == null) {
        setState(() => _loading = false);
        return;
      }

      final postsRes = await Supabase.instance.client
          .from('posts')
          .select('id')
          .eq('channel_id', widget.channelId);

      final postCount = (postsRes as List).length;

      setState(() {
        _channelName = channelRes['name'] as String?;
        _channelImage = channelRes['profile_image_url'] as String?;
        _followers = (channelRes['followers'] as List?) ?? [];
        _creatorId = channelRes['creator_id'] as String?;
        _channelCreatedAt = channelRes['created_at'] != null
            ? DateTime.tryParse(channelRes['created_at'])
            : null;
        _postCount = postCount;
      });

      // 3. Save to cache
      _cache[widget.channelId] = _ChannelCache(
        name: _channelName,
        imageUrl: _channelImage,
        followers: List.from(_followers),
        creatorId: _creatorId,
        createdAt: _channelCreatedAt,
        postCount: _postCount!,
        cachedAt: DateTime.now(),
      );

      await _fetchChannelPosts();
    } catch (e) {
      debugPrint('Error fetching channel info: $e');
      setState(() => _loading = false);
    }
  }

  Future<void> _fetchChannelPosts() async {
    if (_isFetching) return;
    _isFetching = true;

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;

      final response = await _retry(
        () => Supabase.instance.client
            .from('posts')
            .select(
              '''id, user_id, content, image_url, created_at, poll_options, 
          is_boosted, boost_expires_at, tagged_user_ids, tags, channel_id, 
          users!inner(username, handle, level, profile_image_url, blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry), 
          likes!post_id(count), comments!post_id(count), reposts!post_id(count), 
          liked_by_me:likes!post_id(user_id), poll_votes!post_id(option_index, user_id)''',
            )
            .eq('channel_id', widget.channelId)
            .order('created_at', ascending: false)
            .order('id', ascending: false)
            .limit(_pageSize),
      );
      if (response == null) return;

      final posts = await compute(_parsePosts, {
        'data': response,
        'currentUserId': userId,
      });

      setState(() {
        _posts = posts;
        _lastCursor = posts.isEmpty ? null : posts.last;
        _loading = false;
        _hasMorePosts = posts.length == _pageSize;
      });
    } catch (e) {
      debugPrint('Error fetching channel posts: $e');
      setState(() => _loading = false);
    } finally {
      _isFetching = false;
    }
  }

  Future<void> _fetchMorePosts() async {
    if (_isFetching || !_hasMorePosts) return;
    if (_lastCursor == null) return;

    _isFetching = true;
    setState(() => _isLoadingMore = true);

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;

      final cursorTime = _lastCursor!.createdAt.toIso8601String();
      final cursorId = _lastCursor!.id;

      final query = Supabase.instance.client
          .from('posts')
          .select('''id, user_id, content, image_url, created_at, poll_options, 
          is_boosted, boost_expires_at, tagged_user_ids, tags, channel_id, 
          users!inner(username, handle, level, profile_image_url, blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry), 
          likes!post_id(count), comments!post_id(count), reposts!post_id(count), 
          liked_by_me:likes!post_id(user_id), poll_votes!post_id(option_index, user_id)''')
          .eq('channel_id', widget.channelId)
          .or(
            'created_at.lt.$cursorTime,and(created_at.eq.$cursorTime,id.lt.$cursorId)',
          )
          .order('created_at', ascending: false)
          .order('id', ascending: false)
          .limit(_pageSize);

      final response = await _retry(() => query);

      if (response == null) return;

      final newPosts = await compute(_parsePosts, {
        'data': response,
        'currentUserId': userId,
      });

      if (newPosts.isNotEmpty) {
        _lastCursor = newPosts.last;
      }

      if (newPosts.length < _pageSize) {
        _hasMorePosts = false;
      }

      setState(() {
        _posts.addAll(newPosts);
      });
    } catch (e) {
      debugPrint('Error fetching more posts: $e');
    } finally {
      _isFetching = false;
      setState(() => _isLoadingMore = false);
    }
  }

  Future<void> _openComments(Post post) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CommentScreen(
          post: post,
          currentUserId: Supabase.instance.client.auth.currentUser?.id,
          onLike: _toggleLike,
          onRepost: _repost,
          onShare: _sharePost,
          onEdit: _editPost,
          onDelete: _deletePost,
          onProfileTap: _navigateToProfile,
          onError: _showError,
          onBoost: _onBoost,
          isTrending: false,
        ),
      ),
    );
    await _fetchChannelPosts();
  }

  Future<void> _toggleLike(Post post) async {
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      showToast('You must be logged in to like posts.');
      return;
    }

    try {
      if (post.likedByMe) {
        await supabase.from('likes').delete().match({
          'post_id': post.id,
          'user_id': userId,
        });
      } else {
        await supabase.from('likes').insert({
          'post_id': post.id,
          'user_id': userId,
          'created_at': DateTime.now().toIso8601String(),
        });
      }
      await _fetchChannelPosts();
    } catch (e) {
      _showError('Error updating like: $e');
    }
  }

  Future<void> _repost(Post post) async {
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;
    try {
      await supabase.from('reposts').insert({
        'post_id': post.id,
        'user_id': userId,
        'created_at': DateTime.now().toIso8601String(),
      });
      showToast('✅ Reposted');
    } catch (e) {
      _showError('Failed to repost: $e');
    }
  }

  Future<void> _sharePost(Post post) async {
    final link = 'https://udusforum.com/p/${post.id}';
    // ignore: deprecated_member_use
    await share_plus.Share.share('${post.content}\n\n$link');
  }

  Future<void> _editPost(Post post) async {
    showToast('Edit not available in channel feed.');
  }

  Future<void> _deletePost(Post post) async {
    try {
      await Supabase.instance.client.from('posts').delete().eq('id', post.id);
      await _fetchChannelPosts();
      showToast('Deleted successfully.');
    } catch (e) {
      _showError('Delete failed: $e');
    }
  }

  Future<void> _onBoost(Post post, int hours, int coinCost) async {
    showToast('Boost feature not active yet.');
  }

  void _navigateToProfile(String postUserId) {
    final currentUserId = Supabase.instance.client.auth.currentUser?.id;
    if (postUserId == currentUserId) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfileScreen()),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OtherUserProfileScreen(userId: postUserId),
        ),
      );
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }

  Future<void> _toggleFollow() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) {
      showToast('You must be logged in to follow channels.');
      return;
    }

    // BLOCK OWNER FROM UNFOLLOWING
    if (_isOwner) {
      showToast("You can't unfollow your own channel.");
      return;
    }

    try {
      final updated = List<String>.from(_followers.map((f) => f.toString()));
      final userIdStr = user.id;

      if (updated.contains(userIdStr)) {
        updated.remove(userIdStr);
      } else {
        updated.add(userIdStr);
      }

      await supabase
          .from('channels')
          .update({'followers': updated})
          .eq('id', widget.channelId);

      setState(() {
        _followers = updated;
      });
      _cache.remove(widget.channelId);
      await _fetchChannelPosts();

      showToast(updated.contains(userIdStr) ? 'Following' : 'Unfollowed');
    } catch (e) {
      _showError('Failed to update follow: $e');
    }
  }

  Future<void> _deleteChannel() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Channel?'),
        content: const Text(
          'This will permanently delete the channel and all its posts. This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      setState(() => _loading = true);

      // Delete all posts first
      await Supabase.instance.client
          .from('posts')
          .delete()
          .eq('channel_id', widget.channelId);

      // Then delete channel
      await Supabase.instance.client
          .from('channels')
          .delete()
          .eq('id', widget.channelId);

      if (mounted) {
        showToast('Channel deleted successfully');
        Navigator.pop(context); // Go back
      }
    } catch (e) {
      _showError('Failed to delete channel: $e');
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  String _formattedCreatedDate() {
    if (_channelCreatedAt == null) return 'Unknown';
    final d = _channelCreatedAt!;
    return '${d.day}/${d.month}/${d.year}';
  }

  Future<void> _onRefresh() async {
    await _fetchChannelData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      floatingActionButton: FloatingActionButton(
        backgroundColor: channelAccentColor,
        elevation: 4,
        onPressed: () async {
          final created = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  PostCreateScreen(initialChannelId: widget.channelId),
            ),
          );
          if (created == true) await _fetchChannelPosts();
        },
        child: const Icon(Icons.add, color: Colors.white, size: 28),
      ),
      body: LiquidPullToRefresh(
        onRefresh: _onRefresh,
        color: channelAccentColor,
        backgroundColor: Colors.white,
        showChildOpacityTransition: false,
        child: CustomScrollView(
          controller: _scrollController,
          slivers: [
            // 🔹 Channel Header like X Community Page
            SliverToBoxAdapter(
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.fromLTRB(16, 40, 16, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Avatar
                        CircleAvatar(
                          radius: 34,
                          backgroundColor: Colors.grey[200],
                          backgroundImage: _channelImage?.isNotEmpty == true
                              ? NetworkImage(_channelImage!)
                              : null,
                          child: _channelImage?.isEmpty ?? true
                              ? const Icon(
                                  Icons.campaign,
                                  color: channelAccentColor,
                                  size: 28,
                                )
                              : null,
                        ),
                        const SizedBox(width: 14),

                        // Channel Name + Stats
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _channelName ?? 'Channel',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: 'Roboto',
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              // Wrap stats in IntrinsicWidth to prevent overflow
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  // TAPPABLE: Icon + Count
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => ChannelFollowerScreen(
                                            channelId: widget.channelId,
                                            followerIds: _followers,
                                          ),
                                        ),
                                      );
                                    },
                                    child: Row(
                                      children: [
                                        const Icon(
                                          Icons.people_alt,
                                          size: 20,
                                          color: Colors.blueAccent,
                                        ),
                                        const SizedBox(width: 3),
                                        Text(
                                          '${_followers.length}',
                                          style: const TextStyle(
                                            color: Colors.grey,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Flexible(
                                    child: Text(
                                      _formattedCreatedDate(),
                                      style: const TextStyle(
                                        color: Colors.grey,
                                        fontSize: 14,
                                        fontFamily: 'Roboto',
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        // Info + Menu Buttons (Fixed width)
                        SizedBox(
                          width: 80, // Enough for two icons
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              // Info Button
                              IconButton(
                                icon: const Icon(
                                  Icons.info_outline,
                                  color: Colors.black87,
                                  size: 22,
                                ),
                                onPressed: _showChannelInfo,
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                              ),
                              // Three Dots (Owner only)
                              if (_isOwner)
                                PopupMenuButton<String>(
                                  icon: const Icon(
                                    Icons.more_vert,
                                    color: Colors.black87,
                                    size: 22,
                                  ),
                                  padding: EdgeInsets.zero,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  offset: const Offset(0, 40),
                                  itemBuilder: (context) => [
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Row(
                                        children: [
                                          Icon(Icons.edit, size: 18),
                                          SizedBox(width: 10),
                                          Text(
                                            'Edit Channel',
                                            style: TextStyle(
                                              fontFamily: 'Roboto',
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const PopupMenuItem(
                                      value: 'delete',
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons.delete,
                                            size: 18,
                                            color: Colors.red,
                                          ),
                                          SizedBox(width: 10),
                                          Text(
                                            'Delete Channel',
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontFamily: 'Roboto',
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                  onSelected: (value) async {
                                    if (value == 'edit') {
                                      final updated = await Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => ChannelEditScreen(
                                            channelId: widget.channelId,
                                          ),
                                        ),
                                      );
                                      if (updated == true) {
                                        _cache.remove(widget.channelId);
                                        await _fetchChannelData();
                                      }
                                    } else if (value == 'delete') {
                                      _deleteChannel();
                                    }
                                  },
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _toggleFollow,
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: channelAccentColor),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text(
                              _followers.contains(
                                    Supabase
                                        .instance
                                        .client
                                        .auth
                                        .currentUser
                                        ?.id,
                                  )
                                  ? 'Following'
                                  : 'Follow',
                              style: const TextStyle(
                                color: channelAccentColor,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Roboto',
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => PostCreateScreen(
                                    initialChannelId: widget.channelId,
                                  ),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: channelAccentColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'Post',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Roboto',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 24, thickness: 0.6),
                  ],
                ),
              ),
            ),

            // 🔹 Posts Feed Section
            if (_loading && _posts.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: Center(
                  child: CircularProgressIndicator(
                    color: channelAccentColor,
                    strokeWidth: 2.5,
                  ),
                ),
              )
            else if (_posts.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: Center(
                  child: Text(
                    'No posts yet in this channel.',
                    style: TextStyle(fontSize: 16, fontFamily: 'Roboto'),
                  ),
                ),
              )
            else
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    // === INSERT NATIVE AD ===
                    final contentIndex = index;
                    if (AdManager().shouldShowNativeAd(contentIndex)) {
                      return NativeAdWidget(
                        key: ValueKey(
                          'native_ad_$contentIndex',
                        ), // ← dynamic key
                      );
                    }

                    // Adjust post index after ads
                    final postListIndex =
                        contentIndex -
                        (contentIndex ~/ AdManager().nativeAdFrequency);
                    if (postListIndex >= _posts.length) {
                      return const SizedBox.shrink();
                    }
                    final post = _posts[index];
                    return Column(
                      children: [
                        PostCard(
                          key: ValueKey(post.id),
                          post: post,
                          currentUserId:
                              Supabase.instance.client.auth.currentUser?.id,
                          onComment: _openComments,
                          onLike: _toggleLike,
                          onRepost: _repost,
                          onShare: _sharePost,
                          onEdit: _editPost,
                          onDelete: _deletePost,
                          onProfileTap: _navigateToProfile,
                          onError: _showError,
                          onBoost: _onBoost,
                          isTrending: false,
                        ),
                        if (index != _posts.length - 1)
                          Divider(height: 1, color: Colors.grey[200]),
                      ],
                    );
                  },
                  childCount:
                      _posts.length +
                      (_posts.length ~/ AdManager().nativeAdFrequency),
                ),
              ),

            // 🔹 Loader at end
            if (_isLoadingMore)
              const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: channelAccentColor,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
