import 'package:flutter/material.dart';
import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:oktoast/oktoast.dart';
import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';
import '/models/notification_model.dart' as app;
import '/models/post_model.dart';
import '../profile/profile_screen.dart';
import '../profile/other_user_profile_screen.dart';
import '../comment/comment_screen.dart';
import '../profile/followers_list_screen.dart';
import '../feed/post_create_screen.dart';
import '../channel/channel_feed_screen.dart';
import 'package:share_plus/share_plus.dart' as share_plus;

class NotificationsScreen extends StatefulWidget {
  final int newNotificationCount;
  final VoidCallback onNotificationsViewed;

  const NotificationsScreen({
    super.key,
    this.newNotificationCount = 0,
    required this.onNotificationsViewed,
  });

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final supabase = Supabase.instance.client;
  List<app.Notification> _notifications = [];
  bool _loading = true;
  bool _actionLoading = false;
  String? _error;
  RealtimeChannel? _notificationSubscription;

  @override
  void initState() {
    super.initState();
    _fetchNotifications();
    _setupRealtimeSubscription();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.onNotificationsViewed();
      _markNotificationsAsRead();
    });
  }

  Future<void> _fetchNotifications() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      if (mounted) {
        setState(() {
          _error = 'You must be logged in to view notifications';
          _loading = false;
        });
      }
      return;
    }

    try {
      final response = await supabase
          .from('notifications')
          .select('''
            id,
            user_id,
            actor_id,
            type,
            post_id,
            level,
            created_at,
            is_read,
            users:actor_id!left(username, profile_image_url, blue_tick),
            posts:post_id!left(channel_id),
            channels!left(name)
          ''')
          .eq('user_id', userId)
          .order('created_at', ascending: false);

      final notifications = (response as List).map((map) {
        // ── SAFE READ ─────────────────────────────────────
        final usersMap = map['users'] as Map<String, dynamic>?;
        final channelsMap = map['channels'] as Map<String, dynamic>?;

        return app.Notification(
          id: map['id'] as String,
          userId: map['user_id'] as String,
          actorId: map['actor_id'] as String,
          type: map['type'] as String,
          postId: map['post_id'] as String?,
          frameId: map['frame_id'] as String?,
          commentId: map['comment_id'] as String? ?? '', // ← fallback
          createdAt: DateTime.parse(map['created_at'] as String), // guaranteed
          isRead: map['is_read'] as bool,
          actorUsername:
              usersMap?['username'] as String? ?? 'Someone', // ← fallback
          actorProfileImageUrl: usersMap?['profile_image_url'] as String?,
          level: map['level'] as int?,
          channelName:
              channelsMap?['name'] as String? ?? 'a channel', // ← fallback
        );
      }).toList();

      if (mounted) {
        setState(() {
          _notifications = notifications;
          _loading = false;
          _error = null;
        });
      }
    } catch (e) {
      debugPrint('Error fetching notifications: $e');
      if (mounted) {
        setState(() {
          _error = 'Failed to load notifications: $e';
          _loading = false;
        });
      }
    }
  }

  void _setupRealtimeSubscription() {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    _notificationSubscription = supabase
        .channel('notifications:$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (_) async {
            await _fetchNotifications();
          },
        )
        .subscribe((status, [error]) {
          final String statusStr = status is String
              ? status as String
              : status.toString().toUpperCase();
          if (statusStr.contains('SUBSCRIPTION_ERROR') && error != null) {
            debugPrint('Realtime subscription error: $error');
            if (mounted) {
              setState(() => _error = 'Realtime updates failed: $error');
            }
          }
        });
  }

  Future<void> _markNotificationsAsRead() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    try {
      await supabase
          .from('notifications')
          .update({'is_read': true})
          .eq('user_id', userId)
          .eq('is_read', false);
    } catch (e) {
      debugPrint('Error marking notifications as read: $e');
      if (mounted) showToast('Failed to mark notifications as read');
    }
  }

  Future<void> _toggleLike(Post post) async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      showToast('You must be logged in to like posts.');
      return;
    }

    setState(() => _actionLoading = true);
    try {
      if (post.likedByMe) {
        await supabase.from('likes').delete().match({
          'post_id': post.id,
          'user_id': userId,
        });
      } else {
        final existingLike = await supabase
            .from('likes')
            .select()
            .eq('post_id', post.id)
            .eq('user_id', userId)
            .maybeSingle();

        if (existingLike != null) {
          showToast('You have already liked this post.');
          return;
        }

        await supabase.from('likes').insert({
          'post_id': post.id,
          'user_id': userId,
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });

        if (post.userId != userId) {
          try {
            final ownerData = await supabase
                .from('users')
                .select('xp')
                .eq('id', post.userId)
                .single();
            final currentXp = (ownerData['xp'] as int?) ?? 0;
            await supabase
                .from('users')
                .update({'xp': currentXp + 3})
                .eq('id', post.userId);
            await supabase.from('wallet_transactions').insert({
              'user_id': post.userId,
              'type': 'xp_credit',
              'amount': 3,
              'description': 'XP earned from like on post ${post.id}',
              'created_at': DateTime.now().toUtc().toIso8601String(),
            });
            if (supabase.auth.currentUser?.id == post.userId) {
              showToast("❤️ You earned +3 XP from a like!");
            }
          } catch (e) {
            debugPrint('Error awarding XP for like: $e');
          }
        }
      }
      await _fetchNotifications();
    } catch (e) {
      debugPrint('Error updating like: $e');
      _showError('Failed to update like: $e');
    } finally {
      if (mounted) setState(() => _actionLoading = false);
    }
  }

  Future<void> _repost(Post post) async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      showToast('You must be logged in to repost.');
      return;
    }

    setState(() => _actionLoading = true);
    try {
      final existingRepost = await supabase
          .from('reposts')
          .select()
          .eq('post_id', post.id)
          .eq('user_id', userId)
          .maybeSingle();

      if (existingRepost != null) {
        showToast('You have already reposted this post.');
        return;
      }

      await supabase.from('reposts').insert({
        'post_id': post.id,
        'user_id': userId,
        'created_at': DateTime.now().toIso8601String(),
      });
      showToast('✅ Reposted successfully!');
      await _fetchNotifications();
    } catch (e) {
      debugPrint('Error reposting: $e');
      if (mounted) showToast('Failed to repost: $e');
    } finally {
      if (mounted) setState(() => _actionLoading = false);
    }
  }

  Future<void> _sharePost(Post post) async {
    setState(() => _actionLoading = true);
    try {
      // ignore: deprecated_member_use
      await share_plus.Share.share('${post.content}\n\nShared via UDUS Forum');
    } catch (e) {
      debugPrint('Error sharing post: $e');
      showToast('Failed to share post: $e');
    } finally {
      if (mounted) setState(() => _actionLoading = false);
    }
  }

  Future<void> _editPost(Post post) async {
    setState(() => _actionLoading = true);
    try {
      final result = await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => PostCreateScreen(post: post)),
      );
      if (result == true) {
        showToast('✅ Post updated successfully!');
        await _fetchNotifications();
      }
    } catch (e) {
      debugPrint('Error editing post: $e');
      showToast('Failed to edit post: $e');
    } finally {
      if (mounted) setState(() => _actionLoading = false);
    }
  }

  Future<void> _deletePost(Post post) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Post'),
        content: const Text('Are you sure you want to delete this post?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    setState(() => _actionLoading = true);
    try {
      await supabase
          .from('posts')
          .delete()
          .eq('id', post.id)
          .eq('user_id', supabase.auth.currentUser?.id ?? '');

      if (post.imageUrl != null && post.imageUrl!.isNotEmpty) {
        final filePath = post.imageUrl!.split('/post-images/').last;
        await supabase.storage.from('post-images').remove([filePath]);
      }

      await Future.wait([
        supabase.from('likes').delete().eq('post_id', post.id),
        supabase.from('comments').delete().eq('post_id', post.id),
        supabase.from('reposts').delete().eq('post_id', post.id),
        supabase.from('poll_votes').delete().eq('post_id', post.id),
        supabase.from('notifications').delete().eq('post_id', post.id),
      ]);

      showToast('✅ Post deleted successfully!');
      await _fetchNotifications();
    } catch (e) {
      debugPrint('Error deleting post: $e');
      if (mounted) showToast('Failed to delete post: $e');
    } finally {
      if (mounted) setState(() => _actionLoading = false);
    }
  }

  void _navigateToProfile(String? userId) {
    final currentUserId = supabase.auth.currentUser?.id;
    if (currentUserId == null || userId == null) {
      showToast('Unable to view profile');
      return;
    }

    if (userId == currentUserId) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfileScreen()),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => OtherUserProfileScreen(userId: userId),
        ),
      );
    }
  }

  void _showError(String message) {
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  Future<bool> _isTrendingPost(String postId) async {
    try {
      final response = await supabase
          .from('trending_posts')
          .select('is_trending')
          .eq('post_id', postId)
          .maybeSingle();
      return response != null && (response['is_trending'] as bool?) == true;
    } catch (e) {
      debugPrint('Error checking trending status: $e');
      return false;
    }
  }

  Future<void> _handleNotificationTap(app.Notification notification) async {
    final currentUserId = supabase.auth.currentUser?.id;
    if (currentUserId == null) {
      showToast('You must be logged in');
      return;
    }

    switch (notification.type) {
      case 'profile_visit':
        _navigateToProfile(notification.actorId);
        break;
      case 'post':
      case 'tag':
      case 'report':
      case 'report_admin':
      case 'comment':
      case 'like':
      case 'trending':
        if (notification.postId != null) {
          try {
            final postData = await supabase
                .from('posts')
                .select('''
                id,
                user_id,
                content,
                image_url,
                created_at,
                poll_options,
                is_boosted,
                boost_expires_at,
                tagged_user_ids,
                tags,
                users!inner(username, handle, level, profile_image_url, blue_tick, blue_tick_expiry),
                like_count:likes(count),
                comment_count:comments(count),
                repost_count:reposts(count),
                liked_by_me:likes(user_id)
              ''')
                .eq('id', notification.postId!)
                .single();

            final likedByMe =
                (postData['liked_by_me'] as List?)?.any(
                  (like) => like['user_id'] == currentUserId,
                ) ??
                false;
            final post = Post.fromMap({
              ...postData,
              'liked_by_me': likedByMe,
              'like_count': postData['likes']?.isNotEmpty ?? false
                  ? postData['likes'][0]['count']
                  : 0,
              'comment_count': postData['comments']?.isNotEmpty ?? false
                  ? postData['comments'][0]['count']
                  : 0,
              'repost_count': postData['reposts']?.isNotEmpty ?? false
                  ? postData['reposts'][0]['count']
                  : 0,
              'poll_options': postData['poll_options'] != null
                  ? List<String>.from(postData['poll_options'])
                  : [],
              'poll_votes': postData['poll_votes'] != null
                  ? List<Map<String, dynamic>>.from(postData['poll_votes'])
                  : [],
              'tagged_user_ids': postData['tagged_user_ids'] != null
                  ? List<String>.from(postData['tagged_user_ids'])
                  : [],
              'tags': postData['tags'] != null
                  ? Map<String, dynamic>.from(postData['tags'])
                  : {'hashtags': [], 'cashtags': [], 'customtags': []},
            });

            final isTrending = await _isTrendingPost(post.id);

            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CommentScreen(
                  post: post,
                  currentUserId: currentUserId,
                  onLike: _toggleLike,
                  onRepost: _repost,
                  onShare: _sharePost,
                  onEdit: _editPost,
                  onDelete: _deletePost,
                  onProfileTap: _navigateToProfile,
                  onError: _showError,
                  onBoost: (Post post, int coins, int hours) async {
                    debugPrint(
                      'Boost action ignored from Notifications screen',
                    );
                  },
                  isTrending: isTrending,
                ),
              ),
            );
          } catch (e) {
            debugPrint('Error fetching post for notification: $e');
            showToast('Failed to load post');
          }
        }
        break;
      case 'channel_post':
        if (notification.postId != null) {
          final postRes = await supabase
              .from('posts')
              .select('channel_id')
              .eq('id', notification.postId!)
              .maybeSingle();

          if (postRes != null && postRes['channel_id'] != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    ChannelFeedScreen(channelId: postRes['channel_id']),
              ),
            );
          }
        }
        break;
      case 'follow':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => FollowersListScreen(userId: currentUserId),
          ),
        );
        break;
      case 'comment_like':
        showToast('Comment likes are not fully supported yet.');
        break;
      default:
        showToast('Action not supported for this notification');
    }
  }

  @override
  void dispose() {
    _notificationSubscription?.unsubscribe();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Notifications',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontFamily: 'Roboto',
          ),
        ),
        actions: [
          if (_error != null)
            IconButton(
              icon: const Icon(Icons.refresh, color: Color(0xFF1DA1F2)),
              onPressed: _fetchNotifications,
              tooltip: 'Retry',
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : _error != null
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(_error!, style: const TextStyle(color: Colors.red)),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _fetchNotifications,
                    child: const Text('Retry'),
                  ),
                ],
              ),
            )
          : _notifications.isEmpty
          ? const Center(
              child: Text(
                'No notifications yet',
                style: TextStyle(color: Colors.black87, fontFamily: 'Roboto'),
              ),
            )
          : RefreshIndicator(
              onRefresh: _fetchNotifications,
              child: Stack(
                children: [
                  ListView.builder(
                    // ← Changed from ListView.separated to ListView.builder
                    physics: const BouncingScrollPhysics(),
                    cacheExtent: 1000,
                    padding: const EdgeInsets.all(16),
                    itemCount:
                        _notifications.length +
                        (_notifications.isNotEmpty
                            ? (AdManager().bannerEnabled
                                  ? (_notifications.length / 8).ceil()
                                  : 0)
                            : 0), // Add space for ads
                    itemBuilder: (context, index) {
                      // Insert banner ad every 8 real notifications
                      final adIndex =
                          index ~/ 9; // 0,9,18,... → ad at index 8,17,...
                      final isAdPosition =
                          (index + 1) % 9 == 0 && AdManager().bannerEnabled;

                      if (isAdPosition) {
                        return const Padding(
                          padding: EdgeInsets.symmetric(vertical: 12),
                          child: Center(child: BannerAdWidget(height: 60)),
                        );
                      }

                      // Normal notification item
                      final notificationIndex = index - adIndex;
                      if (notificationIndex >= _notifications.length) {
                        return const SizedBox.shrink();
                      }

                      final notification = _notifications[notificationIndex];

                      return Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                          side: BorderSide(color: Colors.grey[200]!),
                        ),
                        elevation: 0,
                        color: notification.isRead
                            ? Colors.white
                            : Colors.blue[50],
                        child: ListTile(
                          onTap: _actionLoading
                              ? null
                              : () => _handleNotificationTap(notification),
                          leading: CircleAvatar(
                            backgroundColor: Colors.grey[300],
                            backgroundImage:
                                notification.actorProfileImageUrl != null
                                ? NetworkImage(
                                    notification.actorProfileImageUrl!,
                                  )
                                : null,
                            child: notification.actorProfileImageUrl == null
                                ? Text(
                                    notification.actorUsername.isNotEmpty
                                        ? notification.actorUsername[0]
                                              .toUpperCase()
                                        : 'U',
                                    style: const TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Roboto',
                                    ),
                                  )
                                : null,
                          ),
                          title: Row(
                            children: [
                              Flexible(
                                child: Text(
                                  _getNotificationText(notification),
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: notification.isRead
                                        ? FontWeight.normal
                                        : FontWeight.bold,
                                    fontFamily: 'Roboto',
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (notification.actorBlueTick == true)
                                const Padding(
                                  padding: EdgeInsets.only(left: 4),
                                  child: Icon(
                                    Icons.verified,
                                    size: 16,
                                    color: Color(0xFF1DA1F2),
                                  ),
                                ),
                            ],
                          ),
                          subtitle: Text(
                            timeago.format(notification.createdAt),
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 12,
                              fontFamily: 'Roboto',
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  if (_actionLoading)
                    Container(
                      color: Colors.black26,
                      child: const Center(
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    ),
                ],
              ),
            ),
    );
  }

  String _getNotificationText(app.Notification notification) {
    final isVerified = notification.actorBlueTick == true;
    final verifiedBadge = isVerified ? ' ✅' : '';
    switch (notification.type) {
      case 'profile_visit':
        return '${notification.actorUsername}$verifiedBadge visited your profile';
      case 'post':
        return '${notification.actorUsername}$verifiedBadge posted something new';
      case 'follow':
        return '${notification.actorUsername}$verifiedBadge started following you';
      case 'tag':
        return '${notification.actorUsername}$verifiedBadge mentioned you in a post';
      case 'comment':
        return '${notification.actorUsername}$verifiedBadge commented on your post';
      case 'comment_like':
        return '${notification.actorUsername}$verifiedBadge liked your comment';
      case 'like':
        return '${notification.actorUsername}$verifiedBadge liked your post';
      case 'trending':
        return 'Your post is trending! 🌟';
      case 'channel_post':
        final channelName = notification.channelName ?? 'a channel';
        return '${notification.actorUsername}$verifiedBadge posted in #$channelName';
      case 'report':
        return 'Your post was reported by ${notification.actorUsername}$verifiedBadge';
      case 'report_admin':
        return 'A post was reported by ${notification.actorUsername}$verifiedBadge';
      default:
        return 'New notification';
    }
  }
}
