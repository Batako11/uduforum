import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';

class NoticeCreateScreen extends StatefulWidget {
  const NoticeCreateScreen({super.key});

  @override
  State<NoticeCreateScreen> createState() => _NoticeCreateScreenState();
}

class _NoticeCreateScreenState extends State<NoticeCreateScreen> {
  final supabase = Supabase.instance.client;
  final _contentController = TextEditingController();
  bool _loading = false;
  String? _departmentId;

  @override
  void initState() {
    super.initState();
    _fetchUserDepartment();
  }

  Future<void> _fetchUserDepartment() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final userData = await supabase
          .from('users')
          .select('department_id')
          .eq('id', user.id)
          .single();

      if (mounted) {
        setState(() {
          _departmentId = userData['department_id'] as String?;
        });
      }
    } catch (e) {
      debugPrint('Error fetching user department: $e');
    }
  }

  Future<void> _createNotice() async {
    if (_contentController.text.trim().isEmpty || _departmentId == null) {
      showToast('Please enter content and follow a department.');
      return;
    }

    setState(() {
      _loading = true;
    });

    try {
      final user = supabase.auth.currentUser;
      if (user == null) throw Exception('User not logged in');

      await supabase.from('notices').insert({
        'user_id': user.id,
        'department_id': _departmentId,
        'content': _contentController.text.trim(),
      });

      if (mounted) {
        showToast('✅ Notice posted successfully!');
        Navigator.pop(context, true);
      }
    } catch (e) {
      debugPrint('Error posting notice: $e');
      if (mounted) {
        showToast('Failed to post notice: $e');
      }
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Post Notice',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _contentController,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: 'Enter notice content...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loading ? null : _createNotice,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
              child: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Post Notice'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _contentController.dispose();
    super.dispose();
  }
}
