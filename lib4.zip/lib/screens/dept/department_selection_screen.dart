import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../services/ad_manager.dart';
import '../widgets/banner_ad_widget.dart';

class DepartmentSelectionScreen extends StatefulWidget {
  const DepartmentSelectionScreen({super.key});

  @override
  State<DepartmentSelectionScreen> createState() =>
      _DepartmentSelectionScreenState();
}

class _DepartmentSelectionScreenState extends State<DepartmentSelectionScreen> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _departments = [];
  String? _currentDepartmentId;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchDepartments();
    _fetchUserDepartment();
  }

  Future<void> _fetchDepartments() async {
    try {
      final response = await supabase
          .from('departments')
          .select('id, name')
          .order('name', ascending: true);

      if (mounted) {
        setState(() {
          _departments = response;
          _loading = false;
        });
      }
    } catch (e) {
      debugPrint('Error fetching departments: $e');
      if (mounted) {
        setState(() {
          _error = 'Failed to load departments: $e';
          _loading = false;
        });
      }
    }
  }

  Future<void> _fetchUserDepartment() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final userData = await supabase
          .from('users')
          .select('department_id')
          .eq('id', user.id)
          .single();

      if (mounted) {
        setState(() {
          _currentDepartmentId = userData['department_id'] as String?;
        });
      }
    } catch (e) {
      debugPrint('Error fetching user department: $e');
    }
  }

  Future<void> _followDepartment(String departmentId) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      await supabase
          .from('users')
          .update({'department_id': departmentId})
          .eq('id', user.id);

      if (mounted) {
        setState(() {
          _currentDepartmentId = departmentId;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Department followed successfully!')),
        );
      }
    } catch (e) {
      debugPrint('Error following department: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to follow department: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Select Department',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
      ),

      body: _loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : _error != null
          ? Center(child: Text(_error!))
          : ListView.builder(
              padding: const EdgeInsets.only(
                bottom: 80,
              ), // ← Prevents content under banner
              itemCount: _departments.length,
              itemBuilder: (context, index) {
                final department = _departments[index];
                final isSelected = _currentDepartmentId == department['id'];
                return Card(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                    side: BorderSide(color: Colors.grey[200]!),
                  ),
                  elevation: 0,
                  child: ListTile(
                    title: Text(
                      department['name'],
                      style: TextStyle(
                        color: isSelected
                            ? const Color(0xFF1DA1F2)
                            : Colors.black87,
                        fontWeight: isSelected
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                    ),
                    trailing: isSelected
                        ? const Icon(
                            Icons.check_circle,
                            color: Color(0xFF1DA1F2),
                          )
                        : null,
                    onTap: () => _followDepartment(department['id']),
                  ),
                );
              },
            ),

      // FIXED BANNER AD AT BOTTOM
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(height: 0.5, color: Colors.grey[300]),
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }
}
