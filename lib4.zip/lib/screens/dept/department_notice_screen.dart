import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../services/ad_manager.dart';
import '../library/materials_feed_screen.dart';
import '../widgets/banner_ad_widget.dart';
import '/models/notice_model.dart';
import 'notice_create_screen.dart';
import '../comment/notice_comment_screen.dart';

class DepartmentNoticeScreen extends StatefulWidget {
  final int newNoticeCount; // Add this to receive notice count
  final VoidCallback onNoticesViewed; // Callback to clear notice count

  const DepartmentNoticeScreen({
    super.key,
    this.newNoticeCount = 0,
    required this.onNoticesViewed,
  });

  @override
  State<DepartmentNoticeScreen> createState() => _DepartmentNoticeScreenState();
}

class _DepartmentNoticeScreenState extends State<DepartmentNoticeScreen> {
  final supabase = Supabase.instance.client;
  List<Notice> _notices = [];
  bool _loading = true;
  String? _error;
  String? _userRole;
  String? _departmentId;

  @override
  void initState() {
    super.initState();
    _fetchUserData();
    _fetchNotices();
    // Clear the notice count when the screen is viewed
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.onNoticesViewed();
    });
  }

  Future<void> _fetchUserData() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final userData = await supabase
          .from('users')
          .select('role, department_id')
          .eq('id', user.id)
          .single();

      if (mounted) {
        setState(() {
          _userRole = userData['role'] as String?;
          _departmentId = userData['department_id'] as String?;
        });
      }
    } catch (e) {
      debugPrint('Error fetching user data: $e');
    }
  }

  Future<void> _fetchNotices() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    try {
      final userData = await supabase
          .from('users')
          .select('department_id')
          .eq('id', user.id)
          .single();

      final departmentId = userData['department_id'] as String?;
      if (departmentId == null) {
        if (mounted) {
          setState(() {
            _error = 'Please follow a department to view notices.';
            _loading = false;
          });
        }
        return;
      }

      final response = await supabase
          .from('notices')
          .select('''
        id,
        user_id,
        department_id,
        content,
        created_at,
        users(username, profile_image_url),
        like_count:notice_likes(count),
        comment_count:notice_comments(count),
        liked_by_me:notice_likes(user_id)
      ''')
          .eq('department_id', departmentId)
          .order('created_at', ascending: false);

      final notices = (response as List).map((map) {
        final m = map as Map<String, dynamic>;
        final likedByMe =
            (m['liked_by_me'] as List?)?.any(
              (like) => like['user_id'] == user.id,
            ) ??
            false;
        return Notice.fromMap({...m, 'liked_by_me': likedByMe});
      }).toList();

      if (mounted) {
        setState(() {
          _notices = notices;
          _loading = false;
          _error = null;
        });
      }
    } catch (e) {
      debugPrint('Error fetching notices: $e');
      if (mounted) {
        setState(() {
          _error = 'Failed to load notices: $e';
          _loading = false;
        });
      }
    }
  }

  Future<void> _toggleLike(Notice notice) async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    final oldLikedByMe = notice.likedByMe;
    final oldLikeCount = notice.likeCount;

    setState(() {
      if (notice.likedByMe) {
        notice.likedByMe = false;
        notice.likeCount = (notice.likeCount > 0) ? notice.likeCount - 1 : 0;
      } else {
        notice.likedByMe = true;
        notice.likeCount += 1;
      }
    });

    try {
      if (oldLikedByMe) {
        await supabase.from('notice_likes').delete().match({
          'notice_id': notice.id,
          'user_id': userId,
        });
      } else {
        await supabase.from('notice_likes').insert({
          'notice_id': notice.id,
          'user_id': userId,
        });
      }
    } catch (e) {
      setState(() {
        notice.likedByMe = oldLikedByMe;
        notice.likeCount = oldLikeCount;
      });
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Failed to update like: $e')));
      }
    }
  }

  void _openComments(Notice notice) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => NoticeCommentScreen(notice: notice)),
    ).then((newCount) {
      if (newCount != null) {
        setState(() {
          notice.commentCount = newCount;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool isLecturer = _userRole == 'lecturer' && _departmentId != null;

    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        title: const Text(
          'Department Notices',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.auto_stories_outlined,
              color: Colors.black87,
            ),
            tooltip: 'Library',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MaterialsFeedScreen()),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
      ),

      body: _loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : _error != null
          ? Center(child: Text(_error!, style: const TextStyle(fontSize: 16)))
          : _notices.isEmpty
          ? const Center(
              child: Text(
                'No notices yet',
                style: TextStyle(color: Colors.grey),
              ),
            )
          : RefreshIndicator(
              onRefresh: _fetchNotices,
              child: ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: _notices.length,
                separatorBuilder: (_, _) =>
                    Divider(height: 1, color: Colors.grey[300]),
                itemBuilder: (context, index) {
                  final notice = _notices[index];
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                      side: BorderSide(color: Colors.grey[200]!),
                    ),
                    elevation: 0,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundColor: Colors.grey[300],
                                backgroundImage: notice.profileImageUrl != null
                                    ? NetworkImage(notice.profileImageUrl!)
                                    : null,
                                child: notice.profileImageUrl == null
                                    ? Text(
                                        notice.username.isNotEmpty
                                            ? notice.username[0].toUpperCase()
                                            : 'U',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      )
                                    : null,
                              ),
                              const SizedBox(width: 10),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    notice.username,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                    ),
                                  ),
                                  Text(
                                    timeago.format(notice.createdAt),
                                    style: TextStyle(
                                      color: Colors.grey[600],
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            notice.content,
                            style: const TextStyle(fontSize: 15.5, height: 1.5),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              GestureDetector(
                                onTap: () => _openComments(notice),
                                child: _iconText(
                                  Icons.mode_comment_outlined,
                                  notice.commentCount.toString(),
                                ),
                              ),
                              GestureDetector(
                                onTap: () => _toggleLike(notice),
                                child: _iconText(
                                  notice.likedByMe
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  notice.likeCount.toString(),
                                  active: notice.likedByMe,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

      // X-STYLE FAB — ONLY FOR LECTURERS
      floatingActionButton: isLecturer
          ? FloatingActionButton(
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const NoticeCreateScreen()),
                );
                if (result == true) {
                  _fetchNotices();
                }
              },
              elevation: 6,
              highlightElevation: 12,
              backgroundColor: Colors.black,
              foregroundColor: Colors.white,
              shape: const CircleBorder(),
              child: const Icon(Icons.add, size: 32),
            )
          : null,

      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,

      // FIXED BANNER AD AT BOTTOM
      bottomNavigationBar: AdManager().bannerEnabled
          ? Container(
              color: Colors.white,
              height: 66,
              child: Column(
                children: [
                  Container(height: 0.5, color: Colors.grey[300]),
                  const Expanded(child: BannerAdWidget(height: 60)),
                ],
              ),
            )
          : null,
    );
  }

  Widget _iconText(IconData icon, String text, {bool active = false}) {
    return Row(
      children: [
        Icon(icon, size: 20, color: active ? Colors.red : Colors.grey[600]),
        const SizedBox(width: 6),
        Text(text, style: TextStyle(color: Colors.grey[700], fontSize: 13)),
      ],
    );
  }
}
