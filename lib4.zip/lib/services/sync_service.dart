import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/post_model.dart';

class SyncService {
  static final SyncService _i = SyncService._internal();
  factory SyncService() => _i;
  SyncService._internal();

  Timer? _periodicTimer;
  bool _running = false;

  Future<bool> _hasInternet() async {
    try {
      final resp = await http
          .get(Uri.parse('https://clients3.google.com/generate_204'))
          .timeout(const Duration(seconds: 2));
      return resp.statusCode == 204 || resp.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  Future<void> start({Duration periodic = const Duration(minutes: 15)}) async {
    if (_running) return;
    _running = true;

    // Prune at startup
    await pruneOldPosts();

    // Periodic sync
    _periodicTimer = Timer.periodic(periodic, (_) async {
      await _trySyncWithBackoff();
    });
  }

  Future<void> stop() async {
    _periodicTimer?.cancel();
    _running = false;
  }

  Future<void> pruneOldPosts({Duration ttl = const Duration(hours: 24)}) async {
    try {
      final box = Hive.box('post_cache');
      final cutoff = DateTime.now().subtract(ttl);
      final keysToRemove = <dynamic>[];
      for (final key in box.keys) {
        try {
          final value = box.get(key);
          Post? p;
          if (value is Post) {
            p = value;
          } else if (value is Map)
            p = Post.fromMap(Map<String, dynamic>.from(value));
          else if (value is String) {
            final decoded = json.decode(value) as Map<String, dynamic>;
            p = Post.fromMap(decoded);
          }
          if (p != null && p.createdAt.isBefore(cutoff)) {
            keysToRemove.add(key);
          }
        } catch (_) {}
      }
      for (final k in keysToRemove) {
        box.delete(k);
      }
    } catch (e) {
      debugPrint('Prune failed: $e');
    }
  }

  Future<void> _trySyncWithBackoff({int maxAttempts = 5}) async {
    int attempt = 0;
    while (attempt < maxAttempts) {
      final ok = await _hasInternet();
      if (!ok) {
        attempt++;
        final wait = Duration(seconds: 2 << attempt);
        await Future.delayed(wait);
        continue;
      }

      try {
        await _syncLatestBatch();
        return;
      } catch (e) {
        attempt++;
        final wait = Duration(seconds: 2 << attempt);
        await Future.delayed(wait);
      }
    }
  }

  Future<void> _syncLatestBatch({int limit = 50}) async {
    final box = Hive.box('post_cache');
    DateTime? last;
    try {
      for (final v in box.values) {
        try {
          Post p;
          if (v is Post) {
            p = v;
          } else if (v is Map)
            p = Post.fromMap(Map<String, dynamic>.from(v));
          else if (v is String)
            p = Post.fromMap(json.decode(v) as Map<String, dynamic>);
          else
            continue;
          if (last == null || p.createdAt.isAfter(last)) last = p.createdAt;
        } catch (_) {}
      }
    } catch (_) {}

    String? since;
    if (last != null) since = last.toIso8601String();

    // Build the query. `gte` is included only when `since` is provided.
    final client = Supabase.instance.client;
    final query = (since != null)
        ? client
              .from('posts')
              .select()
              .gte('created_at', since)
              .order('created_at', ascending: false)
              .limit(limit)
        : client
              .from('posts')
              .select()
              .order('created_at', ascending: false)
              .limit(limit);

    final resp = await query;
    final list = resp as List?;
    if (list == null || list.isEmpty) return;

    for (final map in list) {
      try {
        final post = Post.fromMap(Map<String, dynamic>.from(map));
        box.put(post.id, post);
      } catch (e) {
        debugPrint('Sync persist failed: $e');
      }
    }
  }
}
