// lib/services/material_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/material_model.dart';

class MaterialService {
  final supabase = Supabase.instance.client;

  Future<List<MaterialModel>> fetchRecentMaterials({int limit = 20}) async {
    final response = await supabase
        .from('materials')
        .select()
        .order('created_at', ascending: false)
        .limit(limit);

    return (response as List)
        .map((json) => MaterialModel.fromMap(json))
        .toList();
  }

  Stream<List<MaterialModel>> streamMaterials() {
    return supabase
        .from('materials')
        .stream(primaryKey: ['id'])
        .order('created_at', ascending: false)
        .map(
          (maps) => maps.map((item) => MaterialModel.fromMap(item)).toList(),
        );
  }

  Stream<List<MaterialModel>> streamTopDownloadsThisWeek() {
    final weekAgo = DateTime.now().subtract(const Duration(days: 7));

    return supabase
        .from('materials')
        .stream(primaryKey: ['id'])
        .gte('created_at', weekAgo.toIso8601String()) // or use a reset column
        .order('downloads_count', ascending: false)
        .limit(7)
        .map(
          (data) => data.map((json) => MaterialModel.fromMap(json)).toList(),
        );
  }

  Future<void> incrementDownload(String materialId) async {
    await supabase.rpc('increment_downloads', params: {'mid': materialId});
  }
}
