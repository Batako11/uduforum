// lib/services/offline_service.dart
import 'dart:io';
import 'dart:isolate';
import 'dart:ui';
import 'package:flutter/foundation.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

// Progress notifiers and task mapping for UI updates
// Map materialId -> ValueNotifier<int> (0..100)
// Map taskId -> materialId for lookup when background callback reports progress

class OfflineService {
  static final Box _box = Hive.box('downloads');

  static final Map<String, ValueNotifier<int>> _progressNotifiers = {};
  static final Map<String, String> _taskToMaterial = {};

  /// Expose a listenable so UI can react to download state changes.
  static ValueListenable<Box<dynamic>> get listenable =>
      Hive.box('downloads').listenable();

  static ValueListenable<int> progressListenable(String materialId) {
    return _progressNotifiers.putIfAbsent(
      materialId,
      () => ValueNotifier<int>(0),
    );
  }

  // CALL THIS IN main() — MUST BE AFTER FlutterDownloader.initialize()
  static void bindBackgroundIsolate() {
    // Register the port name and listen for messages from background isolate
    const String portName = 'downloader_send_port';
    final receivePort = ReceivePort();
    // If a port already exists, remove it first
    try {
      IsolateNameServer.removePortNameMapping(portName);
    } catch (_) {}

    IsolateNameServer.registerPortWithName(receivePort.sendPort, portName);

    receivePort.listen((dynamic message) async {
      // message is expected to be [taskId, status, progress]
      try {
        if (message is List && message.length >= 3) {
          final String taskId = message[0] as String;
          final int status = message[1] as int;
          final int progress = message[2] as int;

          // Update progress notifier if we know material id for this task
          final materialId = _taskToMaterial[taskId];
          if (materialId != null) {
            final notifier = _progressNotifiers[materialId];
            if (notifier != null) notifier.value = progress;
          }

          // If complete, finalize by updating the stored path
          if (progress >= 100) {
            await _handleBackgroundTaskUpdate(taskId, status, progress);
          }
        }
      } catch (e) {
        debugPrint('Error handling download isolate message: $e');
      }
    });

    // Register callback
    FlutterDownloader.registerCallback(downloadCallback);
  }

  static Future<void> _handleBackgroundTaskUpdate(
    String taskId,
    int status,
    int progress,
  ) async {
    // Consider a task complete when progress == 100 or status indicates completion
    if (progress < 100) return;

    try {
      final tasks = await FlutterDownloader.loadTasks();
      dynamic foundTask;
      if (tasks != null) {
        for (final t in tasks) {
          try {
            if (t.taskId == taskId) {
              foundTask = t;
              break;
            }
          } catch (_) {}
        }
      }
      if (foundTask == null) return;

      final savedDir = (foundTask.savedDir ?? '') as String;
      final filename = (foundTask.filename ?? '') as String;
      final fullPath = '$savedDir/$filename';

      // Find the material id in the box by matching task_id
      for (final key in _box.keys) {
        final entry = _box.get(key);
        if (entry is Map && entry['task_id'] == taskId) {
          await _box.put(key, {
            'path': fullPath,
            'title': entry['title'] ?? '',
            'downloaded_at': DateTime.now().toIso8601String(),
            'task_id': taskId,
          });
          break;
        }
      }
    } catch (e) {
      debugPrint('Failed to finalize download task $taskId: $e');
    }
  }

  @pragma('vm:entry-point')
  static void downloadCallback(String id, int status, int progress) {
    final SendPort? send = IsolateNameServer.lookupPortByName(
      'downloader_send_port',
    );
    send?.send([id, status, progress]);
  }

  static Future<void> downloadMaterial(
    String materialId,
    String url,
    String title,
  ) async {
    if (OfflineService.getLocalPath(materialId) != null) return;

    try {
      // Use app-specific documents directory to avoid needing MANAGE_EXTERNAL_STORAGE
      Directory appDir = await getApplicationDocumentsDirectory();
      final saveDir = '${appDir.path}/UDUS_Materials';
      // Ensure directory exists and is writable. If not, fall back to external storage with permission.
      try {
        final d = Directory(saveDir);
        if (!d.existsSync()) d.createSync(recursive: true);
        // Quick writability test
        final testFile = File('${d.path}/.write_test');
        testFile.writeAsStringSync('ok');
        testFile.deleteSync();
      } catch (e) {
        // Attempt external storage with permission (Android fallback)
        if (Platform.isAndroid) {
          final status = await Permission.storage.status;
          if (!status.isGranted) {
            final res = await Permission.storage.request();
            if (!res.isGranted) {
              throw Exception(
                'Storage permission is required to download materials.',
              );
            }
          }
          Directory? externalDir = await getExternalStorageDirectory();
          externalDir ??= await getTemporaryDirectory();
          final fallback = '${externalDir.path}/UDUS_Materials';
          await Directory(fallback).create(recursive: true);
          // replace saveDir
        }
      }
      await Directory(saveDir).create(recursive: true);

      final fileName = 'udus_$materialId.pdf';
      final fullPath = '$saveDir/$fileName';

      final taskId = await FlutterDownloader.enqueue(
        url: url,
        savedDir: saveDir,
        fileName: fileName,
        showNotification: true,
        openFileFromNotification: true,
        requiresStorageNotLow: false,
      );

      if (taskId != null) {
        // store a provisional entry (path will be finalized by background callback)
        await _box.put(materialId, {
          'path': fullPath,
          'title': title,
          'downloaded_at': null,
          'task_id': taskId,
        });

        // Track task -> material mapping and create a progress notifier
        _taskToMaterial[taskId] = materialId;
        _progressNotifiers.putIfAbsent(materialId, () => ValueNotifier<int>(0));
      }
    } catch (e) {
      debugPrint('Download failed: $e');
      rethrow;
    }
  }

  static String? getLocalPath(String materialId) {
    final data = _box.get(materialId);
    if (data == null) return null;
    final path = data['path'] as String;
    return File(path).existsSync() ? path : null;
  }

  static bool isDownloaded(String materialId) =>
      getLocalPath(materialId) != null;

  static Future<void> deleteDownload(String materialId) async {
    final path = getLocalPath(materialId);
    if (path != null) {
      try {
        await File(path).delete();
      } catch (_) {}
    }
    await _box.delete(materialId);
  }
}
