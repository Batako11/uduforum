import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:oktoast/oktoast.dart';
import 'package:flutter/foundation.dart';

Future<void> createChannel({
  required String name,
  required String handle,
  required String description,
  required bool allowPublicPost,
}) async {
  final supabase = Supabase.instance.client;
  final user = supabase.auth.currentUser;
  if (user == null) {
    showToast('⚠ You must be logged in.');
    return;
  }

  try {
    // Fetch user balance
    final userData = await supabase
        .from('users')
        .select('coins')
        .eq('id', user.id)
        .single();

    final userCoins = userData['coins'] ?? 0;
    if (userCoins < 500) {
      showToast('💰 You need at least 500 coins to create a channel.');
      return;
    }

    // Fetch admin balance
    final adminData = await supabase
        .from('admin_balance')
        .select('id, coins')
        .single();
    final adminCoins = adminData['coins'] ?? 0;

    // Deduct and update balances
    await supabase
        .from('users')
        .update({'coins': userCoins - 500})
        .eq('id', user.id);
    await supabase
        .from('admin_balance')
        .update({'coins': adminCoins + 500})
        .eq('id', adminData['id']);

    // Log transaction
    await supabase.from('wallet_transactions').insert({
      'user_id': user.id,
      'type': 'coin_debit',
      'amount': 500,
      'description': 'Channel creation fee',
      'created_at': DateTime.now().toIso8601String(),
    });

    // Create the channel
    final newChannel = await supabase
        .from('channels')
        .insert({
          'name': name.trim(),
          'handle': handle.toLowerCase().trim(),
          'description': description.trim(),
          'owner_id': user.id,
          'allow_public_post': allowPublicPost,
        })
        .select()
        .single();

    // Auto-follow the channel
    await supabase.from('channel_followers').insert({
      'channel_id': newChannel['id'],
      'user_id': user.id,
    });

    showToast('✅ Channel "${newChannel['name']}" created successfully!');
  } catch (e) {
    debugPrint('Error creating channel: $e');
    showToast('❌ Failed to create channel: $e');
  }
}
