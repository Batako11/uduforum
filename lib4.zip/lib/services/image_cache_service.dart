// lib/services/image_cache_service.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart'; // for debugPrint

class ImageCacheService {
  // Singleton
  static final ImageCacheService _instance = ImageCacheService._internal();
  factory ImageCacheService() => _instance;
  ImageCacheService._internal();

  // In-memory tracking of cached URLs
  final Set<String> _cachedUrls = {};
  static const int _maxCacheSize = 100;

  /// Precaches a list of image URLs if not already cached.
  /// Evicts oldest entry if cache exceeds [_maxCacheSize].
  Future<void> precacheImages(List<String?> urls, BuildContext context) async {
    if (!context.mounted) return;

    final uniqueUrls = urls
        .where((url) => url != null && url.isNotEmpty)
        .cast<String>()
        .where((url) => !_cachedUrls.contains(url)) // Skip already cached
        .toSet();

    if (uniqueUrls.isEmpty) return;

    // Capture an ImageConfiguration synchronously while the context is still mounted.
    final config = createLocalImageConfiguration(context);

    for (final url in uniqueUrls) {
      try {
        // Resolve the image with the captured configuration and await completion
        final provider = NetworkImage(url);
        final stream = provider.resolve(config);
        final completer = Completer<void>();
        late final ImageStreamListener listener;
        listener = ImageStreamListener(
          (_, _) {
            completer.complete();
          },
          onError: (dynamic _, _) {
            completer.complete();
          },
        );
        stream.addListener(listener);
        try {
          await completer.future.timeout(const Duration(seconds: 8));
        } catch (_) {
          // ignore timeout / errors
        } finally {
          try {
            stream.removeListener(listener);
          } catch (_) {}
        }

        _cachedUrls.add(url);

        // Evict oldest if over limit
        if (_cachedUrls.length > _maxCacheSize) {
          final oldest = _cachedUrls.first;
          _cachedUrls.remove(oldest);
          try {
            PaintingBinding.instance.imageCache.evict(NetworkImage(oldest));
          } catch (_) {}
        }
      } catch (e) {
        if (kDebugMode) {
          debugPrint('ImageCacheService: Failed to cache $url → $e');
        }
      }
    }
  }

  /// Clears all cached images and tracking
  void clear() {
    _cachedUrls.clear();
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
  }
}
