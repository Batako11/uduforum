import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart'; // ← ADD THIS
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:async';
import '../models/user_model.dart';

class UserService {
  static final supabase = Supabase.instance.client;

  // === USER FETCHING ===
  static Future<UserModel> getUserById(String userId) async {
    final response = await supabase
        .from('users')
        .select(
          'id, email, username, full_name, profile_image_url, bio, department, level, xp, followers, following, streak, coins, blue_tick, blue_tick_expiry, active_tick',
        )
        .eq('id', userId)
        .single();
    return UserModel.fromMap(response);
  }

  static Future<List<UserModel>> getFollowers(String userId) async {
    try {
      final response = await supabase
          .from('follows')
          .select(
            'follower_id, users!follower_id(username, full_name, bio, department, level, followers, following, xp, streak, coins)',
          )
          .eq('followed_id', userId);
      return (response as List)
          .map((map) => UserModel.fromMap(map['users'] as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('Error fetching followers: $e');
      return [];
    }
  }

  // === VERIFICATION CACHE ===
  static bool? _verifiedCache;
  static DateTime? _cacheTime;

  static Future<bool> isUserVerified({String? userId}) async {
    final id = userId ?? supabase.auth.currentUser?.id;
    if (id == null) return false;

    if (_verifiedCache != null &&
        _cacheTime != null &&
        DateTime.now().difference(_cacheTime!).inSeconds < 3) {
      return _verifiedCache!;
    }

    try {
      final data = await supabase
          .from('users')
          .select('blue_tick, blue_tick_expiry, gold_tick, gold_tick_expiry')
          .eq('id', id)
          .single()
          .timeout(const Duration(seconds: 6));

      final blueActive =
          (data['blue_tick'] as bool? ?? false) &&
          (data['blue_tick_expiry'] == null ||
              (DateTime.tryParse(
                    data['blue_tick_expiry'] ?? '',
                  )?.isAfter(DateTime.now()) ??
                  false));

      final goldActive =
          (data['gold_tick'] as bool? ?? false) &&
          (data['gold_tick_expiry'] == null ||
              (DateTime.tryParse(
                    data['gold_tick_expiry'] ?? '',
                  )?.isAfter(DateTime.now()) ??
                  false));

      final result = blueActive || goldActive;
      _verifiedCache = result;
      _cacheTime = DateTime.now();
      return result;
    } on TimeoutException {
      return false;
    } catch (e) {
      debugPrint('ERROR in isUserVerified: $e');
      return false;
    }
  }

  static void invalidateVerificationCache() {
    _verifiedCache = null;
    _cacheTime = null;
  }

  // === FOLLOWING ===
  static Future<List<UserModel>> getFollowing(String userId) async {
    try {
      final response = await supabase
          .from('follows')
          .select(
            'followed_id, users!followed_id(username, full_name, bio, department, level, followers, following, xp, streak, coins)',
          )
          .eq('follower_id', userId);
      return (response as List)
          .map((map) => UserModel.fromMap(map['users'] as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('Error fetching following: $e');
      return [];
    }
  }

  static Future<bool> isFollowing(String followerId, String followedId) async {
    try {
      final response = await supabase
          .from('follows')
          .select()
          .eq('follower_id', followerId)
          .eq('followed_id', followedId)
          .maybeSingle();
      return response != null;
    } catch (e) {
      debugPrint('Error checking follow status: $e');
      return false;
    }
  }
}
