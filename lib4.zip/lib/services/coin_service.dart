import 'package:supabase_flutter/supabase_flutter.dart';

class CoinService {
  final SupabaseClient supabase;

  /// Admin UID used as treasury. Replace if different.
  static const String adminUid = "72a90a21-8d41-4242-a2c8-1baecf93c349";

  CoinService(this.supabase);

  /// Helper to fetch admin row (id + coins). Returns map or throws.
  Future<Map<String, dynamic>> _getAdminRow() async {
    final res = await supabase
        .from('admin_balance')
        .select('id, coins')
        .limit(1)
        .single();
    return Map<String, dynamic>.from(res);
  }

  /// Get user's coin balance
  Future<int> getUserCoins(String userId) async {
    final row = await supabase
        .from('users')
        .select('coins')
        .eq('id', userId)
        .single();
    return (row['coins'] as int?) ?? 0;
  }

  /// Atomically deduct `amount` from user and credit the same amount to admin (treasury).
  ///
  /// Returns true on success, false on insufficient funds or error.
  Future<bool> spendCoinsToAdmin({
    required String userId,
    required int amount,
  }) async {
    if (amount <= 0) return false;

    final userRow = await supabase
        .from('users')
        .select('coins')
        .eq('id', userId)
        .single();
    final userCoins = (userRow['coins'] as int?) ?? 0;
    if (userCoins < amount) return false;

    final adminRow = await _getAdminRow();
    final adminId = adminRow['id'] as String;
    final adminCoins = (adminRow['coins'] as int?) ?? 0;

    // Optional: Prevent negative admin balance (for robustness)
    if (adminCoins + amount < 0) return false;

    await supabase
        .from('users')
        .update({'coins': userCoins - amount})
        .eq('id', userId);
    await supabase
        .from('admin_balance')
        .update({'coins': adminCoins + amount})
        .eq('id', adminId);

    return true;
  }

  /// Transfer coins from one user to another (not used for gifts).
  Future<bool> transferBetweenUsers({
    required String fromUser,
    required String toUser,
    required int amount,
  }) async {
    if (amount <= 0) return false;
    final fromRow = await supabase
        .from('users')
        .select('coins')
        .eq('id', fromUser)
        .single();
    final toRow = await supabase
        .from('users')
        .select('coins')
        .eq('id', toUser)
        .single();

    final fromCoins = (fromRow['coins'] as int?) ?? 0;
    final toCoins = (toRow['coins'] as int?) ?? 0;

    if (fromCoins < amount) return false;

    await supabase
        .from('users')
        .update({'coins': fromCoins - amount})
        .eq('id', fromUser);
    await supabase
        .from('users')
        .update({'coins': toCoins + amount})
        .eq('id', toUser);

    return true;
  }

  /// Transfer coins from one user to another with an admin fee.
  ///
  /// Deducts `amount + adminFee` from `fromUser`, credits `amount` to `toUser`,
  /// and credits `adminFee` to admin_balance.
  /// Returns true on success, false on insufficient funds or error.
  Future<bool> transferBetweenUsersWithFee({
    required String fromUser,
    required String toUser,
    required int amount,
    required int adminFee,
  }) async {
    final response = await supabase.rpc(
      'transfer_between_users_with_fee',
      params: {
        'from_user_id': fromUser,
        'to_user_id': toUser,
        'amount': amount,
        'admin_fee': adminFee,
      },
    );
    return response as bool;
  }

  /// Credit coins from admin to user (e.g., for coin purchases).
  Future<bool> rewardUser({required String userId, required int coins}) async {
    if (coins <= 0) return false;

    final userRow = await supabase
        .from('users')
        .select('coins')
        .eq('id', userId)
        .single();
    final userCoins = (userRow['coins'] as int?) ?? 0;

    final adminRow = await _getAdminRow();
    final adminCoins = (adminRow['coins'] as int?) ?? 0;
    final adminId = adminRow['id'] as String;

    if (adminCoins < coins) return false;

    await supabase
        .from('users')
        .update({'coins': userCoins + coins})
        .eq('id', userId);
    await supabase
        .from('admin_balance')
        .update({'coins': adminCoins - coins})
        .eq('id', adminId);

    return true;
  }
}
