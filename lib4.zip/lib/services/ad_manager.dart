// lib/services/ad_manager.dart
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../screens/widgets/rewarded_ad_widget.dart';

class AdManager {
  // Singleton
  static final AdManager _instance = AdManager._internal();
  factory AdManager() => _instance;
  AdManager._internal();
  final RewardedAdManager rewardedAd = RewardedAdManager();

  final _supabase = Supabase.instance.client;

  // Remote config values (live from Supabase)
  bool adsEnabled = true;

  bool rewardedAdEnabled = true;
  int rewardAmount = 5;
  int minIntervalMinutes = 1;

  bool nativeAdEnabled = true;
  int nativeAdFrequency = 5; // every X items (posts/comments)

  bool bannerEnabled = true;

  bool walletBannerEnabled = true;
  int walletBannerFrequency = 8; // every X transaction logs

  DateTime? _lastRewardedAdTime;

  // Ad Unit IDs (use test IDs in debug, real ones via build flags)
  String get rewardedAdUnitId => kDebugMode
      ? 'ca-app-pub-3940256099942544/5224354917'
      : 'ca-app-pub-3377674838385002/XXXXXXXXXX'; // ← PUT YOUR REAL REWARDED ID HERE LATER

  String get bannerAdUnitId => kDebugMode
      ? 'ca-app-pub-3940256099942544/6300978111'
      : 'ca-app-pub-3377674838385002/XXXXXXXXXX'; // ← YOUR REAL BANNER ID

  String get nativeAdUnitId => kDebugMode
      ? 'ca-app-pub-3940256099942544/2247696110'
      : 'ca-app-pub-3377674838385002/1759526928'; // ← You already have this one!

  /// Call once at app start (in main.dart)
  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    await _loadConfig();
    await _loadLastRewardedTime();
  }

  /// Refresh config (call on app resume or when you want live changes)
  Future<void> refreshConfig() async {
    await _loadConfig();
  }

  void preloadRewardedAd() {
    rewardedAd.loadAd();
  }

  Future<void> _loadConfig() async {
    try {
      final data = await _supabase
          .from('ad_config')
          .select()
          .single()
          .timeout(const Duration(seconds: 8));

      adsEnabled = data['ads_enabled'] as bool? ?? true;
      rewardedAdEnabled = data['rewarded_ad_enabled'] as bool? ?? true;
      rewardAmount = data['reward_amount'] as int? ?? 5;
      minIntervalMinutes = data['min_interval_minutes'] as int? ?? 1;
      nativeAdEnabled = data['native_ad_enabled'] as bool? ?? true;
      nativeAdFrequency = data['native_ad_frequency'] as int? ?? 5;
      bannerEnabled = data['banner_enabled'] as bool? ?? true;
      walletBannerEnabled = data['wallet_banner_enabled'] as bool? ?? true;
      walletBannerFrequency = data['wallet_banner_frequency'] as int? ?? 8;
    } catch (e) {
      debugPrint('AdManager: Config load failed → $e (using defaults)');
      // Keep current values — safe fallback
    }
  }

  Future<void> _loadLastRewardedTime() async {
    final prefs = await SharedPreferences.getInstance();
    final timeStr = prefs.getString('last_rewarded_ad_time');
    if (timeStr != null) {
      _lastRewardedAdTime = DateTime.tryParse(timeStr);
    }
  }

  Future<void> recordRewardedAdWatched() async {
    _lastRewardedAdTime = DateTime.now();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'last_rewarded_ad_time',
      _lastRewardedAdTime!.toIso8601String(),
    );
  }

  bool canWatchRewardedAd() {
    if (!adsEnabled || !rewardedAdEnabled) return false;
    if (_lastRewardedAdTime == null) return true;
    final minutesSince = DateTime.now()
        .difference(_lastRewardedAdTime!)
        .inMinutes;
    return minutesSince >= minIntervalMinutes;
  }

  /// Should we show a native ad at this index? (0-based)
  bool shouldShowNativeAd(int index) {
    if (!adsEnabled || !nativeAdEnabled || nativeAdFrequency <= 0) return false;
    return (index + 1) % nativeAdFrequency == 0 &&
        (index + 1) >= nativeAdFrequency;
  }

  /// Should we show banner in wallet after this transaction index?
  bool shouldShowWalletBanner(int transactionIndex) {
    if (!adsEnabled || !walletBannerEnabled || walletBannerFrequency <= 0) {
      return false;
    }
    return (transactionIndex + 1) % walletBannerFrequency == 0;
  }

  int getCurrentReward() => rewardAmount;
}
