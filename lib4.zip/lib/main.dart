import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:oktoast/oktoast.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/feed/splash_screen.dart';
import '../services/offline_service.dart';
import 'services/ad_manager.dart';
import 'models/post_adapter.dart';
import 'services/sync_service.dart';
import 'package:hive_flutter/hive_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  // Register typed adapters
  try {
    Hive.registerAdapter(PostAdapter());
  } catch (_) {}
  await Hive.openBox('downloads');
  await Hive.openBox('post_cache');
  await FlutterDownloader.initialize(debug: kDebugMode);
  OfflineService.bindBackgroundIsolate();

  // 1. Load .env (fast)
  await dotenv.load(fileName: ".env");

  // 2. Initialize Supabase FIRST (fast & required)
  await Supabase.initialize(
    url: 'https://jzvvzyrtafqmxpnxyvgn.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp6dnZ6eXJ0YWZxbXhwbnh5dmduIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM2MzUyOTksImV4cCI6MjA2OTIxMTI5OX0.jrMW2oVh-XmJ2VifmWXQU9p5EcrGwFYTwmcb5PKTALU',
  );

  // 3. Start AdMob init in BACKGROUND (don't await!)
  MobileAds.instance.initialize();

  // 4. Start your AdManager in BACKGROUND (don't await here!)
  unawaited(
    AdManager().initialize().then((_) {
      AdManager().preloadRewardedAd(); // Preload only after config is ready
    }),
  );

  // 5. Reduce image cache (optional but good)
  PaintingBinding.instance.imageCache.maximumSize = 50;
  PaintingBinding.instance.imageCache.maximumSizeBytes = 30 << 20; // 30 MB

  // inside main(), before runApp(MyApp());
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light, // or Brightness.dark
    ),
  );

  // RUN APP IMMEDIATELY — DO NOT WAIT FOR ADS!
  // Start SyncService after app initialization
  unawaited(SyncService().start());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return OKToast(
      position: ToastPosition.bottom,
      textStyle: const TextStyle(fontSize: 14, color: Colors.white),
      backgroundColor: Colors.black87,
      radius: 8,
      duration: const Duration(seconds: 3),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'UDUS Forum',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          useMaterial3: true, // ← Recommended for modern look
          scaffoldBackgroundColor: Colors.white,
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.white,
            elevation: 0.5,
            titleTextStyle: TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
            iconTheme: IconThemeData(color: Color(0xFF1E88E5)),
            systemOverlayStyle: SystemUiOverlayStyle.dark,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1E88E5),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
          cardTheme: CardThemeData(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: const BorderSide(color: Color(0xFFE0E0E0)),
            ),
            elevation: 2,
            clipBehavior: Clip.antiAlias,
          ),
        ),
        home: const SplashScreen(),
      ),
    );
  }
}
