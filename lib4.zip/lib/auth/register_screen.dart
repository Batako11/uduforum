// register_screen.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _departmentController = TextEditingController();
  final _levelController = TextEditingController();

  bool _isLoading = false;
  String? _error;

  late AnimationController _shakeController;
  late Animation<double> _shakeAnimation;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _shakeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticIn),
    );
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) {
      _shake();
      return;
    }

    setState(() {
      _isLoading = true;
      _error = null;
    });

    final supabase = Supabase.instance.client;
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();
    final username = _usernameController.text.trim().toLowerCase();
    final fullName = _fullNameController.text.trim();
    final department = _departmentController.text.trim().isEmpty
        ? null
        : _departmentController.text.trim();
    final level = _levelController.text.trim().isEmpty
        ? null
        : _levelController.text.trim();

    try {
      final authResponse = await supabase.auth.signUp(
        email: email,
        password: password,
        data: {
          'full_name': fullName,
          'username': username,
          'department': department,
          'level': level,
        },
      );

      final user = authResponse.user;
      if (user == null) throw Exception('Signup failed');

      await _upsertUserProfile(
        user.id,
        username,
        fullName,
        email,
        department,
        level,
      );

      _showSuccess();
    } catch (e) {
      _handleError(e);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _upsertUserProfile(
    String userId,
    String username,
    String fullName,
    String email,
    String? department,
    String? level,
  ) async {
    final profileData = {
      'id': userId,
      'username': username,
      'full_name': fullName,
      'email': email,
      'department': department,
      'department_id': null,
      'level': level,
      'bio': null,
      'xp': 0,
      'coins': 0,
      'streak': 0,
      'followers': 0,
      'following': 0,
      'profile_image_url': null,
      'handle': null,
      'role': ['user'],
      'blue_tick': false,
      'blue_tick_expiry': null,
      'active_tick': null,
      'gold_tick': false,
      'gold_tick_expiry': null,
      'banned': false,
      'ban_reason': null,
      'ban_expires_at': null,
      'banned_at': null,
      'last_active': DateTime.now().toUtc().toIso8601String(),
      'last_active_date': DateTime.now()
          .toUtc()
          .toIso8601String()
          .split('T')
          .first,
      'thirty_day_reward_given': false,
    };

    await Supabase.instance.client
        .from('users')
        .upsert(profileData, onConflict: 'id');
  }

  void _showSuccess() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Account created! Check your email to verify.'),
      ),
    );
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  void _handleError(dynamic e) {
    debugPrint('Error: $e');
    setState(() {
      _error = e is PostgrestException
          ? 'DB: ${e.message}'
          : e is AuthException
          ? 'Auth: ${e.message}'
          : 'Error: ${e.toString()}';
    });
    _shake();
  }

  void _shake() {
    _shakeController.forward().then((_) => _shakeController.reset());
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _departmentController.dispose();
    _levelController.dispose();
    _shakeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final primaryColor = Colors.blue;

    return Scaffold(
      backgroundColor: isDark ? Colors.black : Colors.white,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: AnimatedBuilder(
              animation: _shakeAnimation,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(
                    10 *
                        _shakeAnimation.value *
                        (2 * _shakeAnimation.value - 1),
                    0,
                  ),
                  child: child,
                );
              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'UDUS Forum',
                    style: TextStyle(
                      fontSize: 37,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Create your account',
                    style: TextStyle(
                      fontSize: 16,
                      color: isDark
                          ? Colors.grey.shade400
                          : Colors.grey.shade700,
                    ),
                  ),
                  const SizedBox(height: 40),

                  // === FORM ===
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        if (_error != null)
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(12),
                            margin: const EdgeInsets.only(bottom: 16),
                            decoration: BoxDecoration(
                              color: Colors.red.shade50,
                              border: Border.all(color: Colors.red),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              _error!,
                              style: const TextStyle(color: Colors.red),
                            ),
                          ),

                        _textField(
                          _fullNameController,
                          'Full Name',
                          Icons.person,
                        ),
                        const SizedBox(height: 14),
                        _textField(
                          _usernameController,
                          'Username',
                          Icons.alternate_email,
                        ),
                        const SizedBox(height: 14),
                        _textField(
                          _emailController,
                          'Email',
                          Icons.email,
                          keyboard: TextInputType.emailAddress,
                        ),
                        const SizedBox(height: 14),
                        _textField(
                          _passwordController,
                          'Password',
                          Icons.lock,
                          obscure: true,
                        ),
                        const SizedBox(height: 14),
                        _textField(
                          _departmentController,
                          'Department',
                          Icons.school,
                        ),
                        const SizedBox(height: 14),
                        _textField(_levelController, 'Level', Icons.bar_chart),

                        const SizedBox(height: 24),

                        SizedBox(
                          width: double.infinity,
                          height: 48,
                          child: ElevatedButton(
                            onPressed: _isLoading ? null : _register,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: _isLoading
                                ? const SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text(
                                    'Create Account',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 32),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Already have an account? ",
                        style: TextStyle(
                          color: isDark
                              ? Colors.grey.shade400
                              : Colors.grey.shade600,
                        ),
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const LoginScreen(),
                          ),
                        ),
                        child: Text(
                          'Login',
                          style: TextStyle(
                            color: primaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _textField(
    TextEditingController controller,
    String label,
    IconData icon, {
    bool obscure = false,
    TextInputType? keyboard,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboard,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        filled: true,
        fillColor: Theme.of(context).brightness == Brightness.dark
            ? Colors.grey.shade900
            : Colors.grey.shade50,
        contentPadding: const EdgeInsets.symmetric(
          vertical: 18,
          horizontal: 16,
        ),
      ),
      validator: (v) => v!.trim().isEmpty ? 'Required' : null,
    );
  }
}
  