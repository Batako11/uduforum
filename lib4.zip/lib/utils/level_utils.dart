import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Returns all relevant level data (title, level, icon, font, color) based on XP points.
Map<String, dynamic> getLevelInfo(int points) {
  if (points >= 30000) {
    return _buildLevel(
      'Legend',
      12,
      Colors.red,
      Icons.emoji_events,
      GoogleFonts.permanentMarker(fontSize: 20.0, fontWeight: FontWeight.bold),
    );
  } else if (points >= 25000) {
    return _buildLevel(
      'Mythic',
      11,
      Colors.deepPurple,
      Icons.auto_awesome,
      GoogleFonts.pacifico(fontSize: 20.0, fontStyle: FontStyle.italic),
    );
  } else if (points >= 20500) {
    return _buildLevel(
      'Grandmaster',
      10,
      Colors.pink,
      Icons.verified,
      GoogleFonts.merriweather(fontSize: 18.0, fontWeight: FontWeight.w700),
    );
  } else if (points >= 16500) {
    return _buildLevel(
      'Elite',
      9,
      Colors.blueAccent,
      Icons.star,
      GoogleFonts.righteous(fontSize: 18.0),
    );
  } else if (points >= 13000) {
    return _buildLevel(
      'Veteran',
      8,
      Colors.teal,
      Icons.shield,
      GoogleFonts.robotoSlab(fontSize: 18.0, fontWeight: FontWeight.w600),
    );
  } else if (points >= 10000) {
    return _buildLevel(
      'Pro',
      7,
      Colors.orange,
      Icons.sports_esports,
      GoogleFonts.bungee(fontSize: 16.0),
    );
  } else if (points >= 7500) {
    return _buildLevel(
      'Master',
      6,
      Colors.deepOrange,
      Icons.school,
      GoogleFonts.indieFlower(fontSize: 16.0),
    );
  } else if (points >= 5000) {
    return _buildLevel(
      'Expert',
      5,
      Colors.indigo,
      Icons.science,
      GoogleFonts.cabin(fontSize: 16.0, fontWeight: FontWeight.w500),
    );
  } else if (points >= 3000) {
    return _buildLevel(
      'Intermediate',
      4,
      Colors.cyan,
      Icons.extension,
      GoogleFonts.lato(fontSize: 15.0),
    );
  } else if (points >= 1600) {
    return _buildLevel(
      'Rookie',
      3,
      Colors.green,
      Icons.fitness_center,
      GoogleFonts.nunito(fontSize: 15.0),
    );
  } else if (points >= 800) {
    return _buildLevel(
      'Novice',
      2,
      Colors.lightBlue,
      Icons.lightbulb_outline,
      GoogleFonts.firaSans(fontSize: 14.0),
    );
  } else if (points >= 400) {
    return _buildLevel(
      'Newbie',
      1,
      Colors.grey,
      Icons.hourglass_empty,
      GoogleFonts.firaSans(fontSize: 14.0, fontWeight: FontWeight.w400),
    );
  } else {
    return _buildLevel(
      'Newbie',
      0,
      Colors.grey,
      Icons.hourglass_empty,
      GoogleFonts.firaSans(fontSize: 14.0, fontWeight: FontWeight.w400),
    );
  }
}

/// Packages the level attributes into a map.
Map<String, dynamic> _buildLevel(
  String title,
  int level,
  Color color,
  IconData icon,
  TextStyle font,
) {
  final currentXp = getLevelThresholdForLevel(level);
  final nextXp = getLevelThresholdForLevel(_getNextLevel(level));
  return {
    'title': title,
    'level': level,
    'color': color,
    'icon': icon,
    'font': font,
    'currentXp': currentXp,
    'nextXp': nextXp,
  };
}

/// Returns the next level after the given level.
int _getNextLevel(int level) {
  if (level >= 12) return 12; // Max level
  return level + 1;
}

/// Looks up full level info by title.
Map<String, dynamic> getLevelInfoFromTitle(String title) {
  final allLevels = [
    getLevelInfo(0), // Newbie (Level 0)
    getLevelInfo(400), // Newbie
    getLevelInfo(800), // Novice
    getLevelInfo(1600), // Rookie
    getLevelInfo(3000), // Intermediate
    getLevelInfo(5000), // Expert
    getLevelInfo(7500), // Master
    getLevelInfo(10000), // Pro
    getLevelInfo(13000), // Veteran
    getLevelInfo(16500), // Elite
    getLevelInfo(20500), // Grandmaster
    getLevelInfo(25000), // Mythic
    getLevelInfo(30000), // Legend
  ];

  return allLevels.firstWhere(
    (levelData) => levelData['title'] == title,
    orElse: () => {'font': GoogleFonts.roboto(fontSize: 16.0)},
  );
}

/// Returns the font style for a given level title.
TextStyle getFontStyleForLevel(String title) {
  return getLevelInfoFromTitle(title)['font'] ??
      GoogleFonts.roboto(fontSize: 16.0);
}

/// Returns the icon for a given level title.
IconData getTitleIcon(String title) {
  return getLevelInfoFromTitle(title)['icon'] ?? Icons.person;
}

/// Returns the color for a given level title.
Color getTitleColor(String title) {
  return getLevelInfoFromTitle(title)['color'] ?? Colors.grey;
}

/// Returns the XP threshold required for a specific level.
int getLevelThresholdForLevel(int level) {
  switch (level) {
    case 12:
      return 30000;
    case 11:
      return 25000;
    case 10:
      return 20500;
    case 9:
      return 16500;
    case 8:
      return 13000;
    case 7:
      return 10000;
    case 6:
      return 7500;
    case 5:
      return 5000;
    case 4:
      return 3000;
    case 3:
      return 1600;
    case 2:
      return 800;
    case 1:
      return 400;
    default:
      return 0; // For Level 0 or invalid levels
  }
}
