class UserModel {
  final String id;
  final String username;
  final String fullName;
  final String? bio;
  final String? department;
  final String? level;
  final int followers;
  final int following;
  final int xp;
  final int streak;
  final int coins;
  final String? profileImageUrl;
  final bool blueTick;
  final DateTime? blueTickExpiry;
  final String? activeTick;
  final bool goldTick;
  final DateTime? goldTickExpiry;

  UserModel({
    required this.id,
    required this.username,
    required this.fullName,
    this.bio,
    this.department,
    this.level,
    required this.followers,
    required this.following,
    required this.xp,
    required this.streak,
    required this.coins,
    this.profileImageUrl,
    required this.blueTick,
    this.blueTickExpiry,
    required this.goldTick,
    this.goldTickExpiry,
    this.activeTick,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'] ?? '',
      username: map['username'] ?? 'Unknown',
      fullName: map['full_name'] ?? '',
      bio: map['bio'],
      department: map['department'],
      level: map['level'],
      followers: map['followers'] ?? 0,
      following: map['following'] ?? 0,
      xp: map['xp'] ?? 0,
      streak: map['streak'] ?? 0,
      coins: map['coins'] ?? 0,
      profileImageUrl: map['profile_image_url'],
      blueTick: map['blue_tick'] ?? false,
      blueTickExpiry: map['blue_tick_expiry'] != null
          ? DateTime.parse(map['blue_tick_expiry'])
          : null,
      goldTick: map['gold_tick'] ?? false,
      goldTickExpiry: map['gold_tick_expiry'] != null
          ? DateTime.parse(map['gold_tick_expiry'])
          : null,
      activeTick: map['active_tick'] as String?,
    );
  }

  UserModel copyWith({
    String? id,
    String? username,
    String? fullName,
    String? bio,
    String? department,
    String? level,
    int? followers,
    int? following,
    int? xp,
    int? streak,
    int? coins,
    String? profileImageUrl,
    bool? blueTick,
    DateTime? blueTickExpiry,
    bool? goldTick,
    DateTime? goldTickExpiry,
    String? activeTick,
  }) {
    return UserModel(
      id: id ?? this.id,
      username: username ?? this.username,
      fullName: fullName ?? this.fullName,
      bio: bio ?? this.bio,
      department: department ?? this.department,
      level: level ?? this.level,
      followers: followers ?? this.followers,
      following: following ?? this.following,
      xp: xp ?? this.xp,
      streak: streak ?? this.streak,
      coins: coins ?? this.coins,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      blueTick: blueTick ?? this.blueTick,
      blueTickExpiry: blueTickExpiry ?? this.blueTickExpiry,
      goldTick: goldTick ?? this.goldTick,
      goldTickExpiry: goldTickExpiry ?? this.goldTickExpiry,
      activeTick: activeTick ?? this.activeTick,
    );
  }
}
