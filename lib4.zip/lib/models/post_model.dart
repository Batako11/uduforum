class Post {
  final String id;
  final String userId;
  final String content;
  final String? imageUrl;
  final DateTime createdAt;
  final List<String>? pollOptions;
  final List<Map<String, dynamic>> pollVotes; // raw
  final Map<int, int> pollVoteCounts; // aggregated
  final int? userVoteIndex;
  final bool isBoosted;
  final DateTime? boostExpiresAt;
  final String username;
  final String handle;
  final int level;
  final String? profileImageUrl;
  final bool blueTick;
  final DateTime? blueTickExpiry;
  final bool goldTick;
  final DateTime? goldTickExpiry;
  final List<String>? taggedUserIds;
  final Map<String, dynamic>? tags;
  int likeCount;
  int commentCount;
  int repostCount;
  bool likedByMe;
  bool repostedByMe;
  final String? channelName;
  final bool isTrending;
  final String? channelId;
  final String? channelImageUrl;
  Post({
    required this.id,
    required this.userId,
    required this.content,
    this.imageUrl,
    required this.createdAt,
    this.pollOptions,
    required this.pollVotes,
    required this.pollVoteCounts,
    this.userVoteIndex,
    required this.isBoosted,
    this.boostExpiresAt,
    required this.username,
    required this.handle,
    required this.level,
    this.profileImageUrl,
    required this.likeCount,
    required this.commentCount,
    required this.repostCount,
    required this.likedByMe,
    required this.blueTick,
    this.blueTickExpiry,
    required this.goldTick,
    this.goldTickExpiry,
    this.taggedUserIds,
    this.tags,
    required this.repostedByMe,
    this.channelName,
    required this.isTrending,
    this.channelId,
    this.channelImageUrl,
  });
  factory Post.fromMap(Map<String, dynamic> map, {String? currentUserId}) {
    // === Poll Vote Aggregation ===
    final rawPollVotes = _safeList(map['poll_votes'] as List<dynamic>?);
    final voteCounts = <int, int>{};
    int? userVoteIndex;

    for (final vote in rawPollVotes) {
      final index = vote['option_index'] as int;
      voteCounts[index] = (voteCounts[index] ?? 0) + 1;

      if (currentUserId != null && vote['user_id'] == currentUserId) {
        userVoteIndex = index;
      }
    }

    // === Like / Repost Checks ===
    final likedByMeList = _safeList(map['liked_by_me'] as List<dynamic>?);
    final repostedByMeList = _safeList(map['reposted_by_me'] as List<dynamic>?);

    final bool likedByMe = currentUserId != null
        ? likedByMeList.any((like) => like['user_id'] == currentUserId)
        : false;

    final bool repostedByMe = currentUserId != null
        ? repostedByMeList.any((repost) => repost['user_id'] == currentUserId)
        : false;

    return Post(
      id: map['id'] as String,
      userId: map['user_id'] as String,
      content: map['content'] as String,
      imageUrl: map['image_url'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      pollOptions:
          (map['poll_options'] as List?)?.map((e) => e.toString()).toList() ??
          [],
      pollVotes: rawPollVotes,
      pollVoteCounts: voteCounts,
      userVoteIndex: userVoteIndex,
      isBoosted: map['is_boosted'] as bool? ?? false,
      isTrending:
          (map['trending_posts'] as Map?)?['is_trending'] as bool? ?? false,
      boostExpiresAt: map['boost_expires_at'] != null
          ? DateTime.tryParse(map['boost_expires_at'] as String)
          : null,
      username: map['users']['username'] as String? ?? 'Unknown',
      handle: map['users']['handle'] as String? ?? '@unknown',
      level: _parseLevel(map['users']['level']),
      profileImageUrl: map['users']['profile_image_url'] as String?,
      likeCount: _parseCount(map['likes']),
      commentCount: _parseCount(map['comments']),
      repostCount: _parseCount(map['reposts']),
      likedByMe: likedByMe,
      repostedByMe: repostedByMe,
      blueTick: map['users']['blue_tick'] as bool? ?? false,
      blueTickExpiry: map['users']['blue_tick_expiry'] != null
          ? DateTime.tryParse(map['users']['blue_tick_expiry'] as String)
          : null,
      goldTick: map['users']['gold_tick'] as bool? ?? false,
      goldTickExpiry: map['users']['gold_tick_expiry'] != null
          ? DateTime.tryParse(map['users']['gold_tick_expiry'] as String)
          : null,
      taggedUserIds: map['tagged_user_ids'] != null
          ? List<String>.from(map['tagged_user_ids'])
          : [],
      tags: map['tags'] != null
          ? Map<String, dynamic>.from(map['tags'])
          : {'hashtags': [], 'cashtags': [], 'customtags': []},
      channelId: map['channel_id'] as String?,
      channelName: map['channels']?['name'] as String?,
      channelImageUrl: map['channels']?['profile_image_url'] as String?,
    );
  }
  static int _parseLevel(dynamic levelData) {
    if (levelData == null) return 1;
    if (levelData is int) return levelData;
    if (levelData is String) return int.tryParse(levelData) ?? 1;
    return 1;
  }

  static int _parseCount(dynamic countData) {
    if (countData == null) return 0;
    if (countData is int) return countData;
    if (countData is String) return int.tryParse(countData) ?? 0;
    if (countData is List && countData.isNotEmpty) {
      final countValue = countData[0]['count'];
      if (countValue is int) return countValue;
      if (countValue is String) return int.tryParse(countValue) ?? 0;
    }
    return 0;
  }

  static List<Map<String, dynamic>> _safeList(List<dynamic>? input) {
    if (input == null) return [];
    return input
        .whereType<Map<String, dynamic>>()
        .where((m) => m.isNotEmpty)
        .toList();
  }

  Post copyWith({
    String? id,
    String? userId,
    String? content,
    String? imageUrl,
    DateTime? createdAt,
    List<Map<String, dynamic>>? pollVotes,
    Map<int, int>? pollVoteCounts,
    int? userVoteIndex,
    String? channelImageUrl,
    bool? isBoosted,
    DateTime? boostExpiresAt,
    String? username,
    String? handle,
    int? level,
    String? profileImageUrl,
    bool? blueTick,
    DateTime? blueTickExpiry,
    bool? goldTick,
    DateTime? goldTickExpiry,
    List<String>? taggedUserIds,
    Map<String, dynamic>? tags,
    int? likeCount,
    int? commentCount,
    int? repostCount,
    bool? likedByMe,
    bool? isTrending,
    bool? repostedByMe,
    String? channelId,
    String? channelName,
  }) {
    return Post(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      content: content ?? this.content,
      imageUrl: imageUrl ?? this.imageUrl,
      createdAt: createdAt ?? this.createdAt,
      pollVotes: pollVotes ?? this.pollVotes,
      pollVoteCounts: pollVoteCounts ?? this.pollVoteCounts,
      userVoteIndex: userVoteIndex ?? this.userVoteIndex,
      channelImageUrl: channelImageUrl ?? this.channelImageUrl,
      isBoosted: isBoosted ?? this.isBoosted,
      boostExpiresAt: boostExpiresAt ?? this.boostExpiresAt,
      username: username ?? this.username,
      handle: handle ?? this.handle,
      level: level ?? this.level,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      blueTick: blueTick ?? this.blueTick,
      blueTickExpiry: blueTickExpiry ?? this.blueTickExpiry,
      goldTick: goldTick ?? this.goldTick,
      goldTickExpiry: goldTickExpiry ?? this.goldTickExpiry,
      taggedUserIds: taggedUserIds ?? this.taggedUserIds,
      tags: tags ?? this.tags,
      likeCount: likeCount ?? this.likeCount,
      commentCount: commentCount ?? this.commentCount,
      repostCount: repostCount ?? this.repostCount,
      likedByMe: likedByMe ?? this.likedByMe,
      isTrending: isTrending ?? this.isTrending,
      repostedByMe: repostedByMe ?? this.repostedByMe,
      channelId: channelId ?? this.channelId,
      channelName: channelName ?? this.channelName,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'content': content,
      'image_url': imageUrl,
      'created_at': createdAt.toIso8601String(),
      'poll_options': pollOptions ?? [],
      'poll_votes': pollVotes,
      'likes': [
        {'count': likeCount},
      ],
      'comments': [
        {'count': commentCount},
      ],
      'reposts': [
        {'count': repostCount},
      ],
      'users': {
        'username': username,
        'handle': handle,
        'level': level,
        'profile_image_url': profileImageUrl,
        'blue_tick': blueTick,
        'blue_tick_expiry': blueTickExpiry?.toIso8601String(),
        'gold_tick': goldTick,
        'gold_tick_expiry': goldTickExpiry?.toIso8601String(),
      },
      'is_boosted': isBoosted,
      'boost_expires_at': boostExpiresAt?.toIso8601String(),
      'tagged_user_ids': taggedUserIds ?? [],
      'tags': tags ?? {},
      'trending_posts': {'is_trending': isTrending},
      'channel_id': channelId,
      'channels': {'name': channelName, 'profile_image_url': channelImageUrl},
    };
  }
}
