class Notification {
  final String id;
  final String userId;
  final String actorId;
  final String type;
  final String? postId;
  final String? frameId;
  final String? commentId;
  final DateTime createdAt;
  final bool isRead;
  final String actorUsername;
  final String? actorProfileImageUrl;
  final int? level;
  final String? channelName;

  Notification({
    required this.id,
    required this.userId,
    required this.actorId,
    required this.type,
    this.postId,
    this.frameId,
    required this.createdAt,
    required this.isRead,
    required this.commentId,
    required this.actorUsername,
    this.actorProfileImageUrl,
    this.level,
    required this.channelName,
  });

  factory Notification.fromMap(Map<String, dynamic> map) {
    return Notification(
      id: map['id'] as String,
      userId: map['user_id'] as String,
      actorId: map['actor_id'] as String,
      type: map['type'] as String,
      postId: map['post_id'] as String?,
      commentId: map['comment_id'] as String?,
      frameId: map['frame_id'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
      isRead: map['is_read'] as bool,
      actorUsername: map['users']?['username'] as String? ?? 'Unknown',
      actorProfileImageUrl: map['users']?['profile_image_url'] as String?,
      level: map['level'] as int?,
      channelName: map['chennels']?['name'] as String,
    );
  }

  Null get actorBlueTick => null;
}
