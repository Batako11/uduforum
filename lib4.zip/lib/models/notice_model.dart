class Notice {
  final String id;
  final String userId;
  final String departmentId;
  final String content;
  final DateTime createdAt;
  final String username;
  final String? profileImageUrl;
  int likeCount;
  int commentCount;
  bool likedByMe;

  Notice({
    required this.id,
    required this.userId,
    required this.departmentId,
    required this.content,
    required this.createdAt,
    required this.username,
    this.profileImageUrl,
    required this.likeCount,
    required this.commentCount,
    required this.likedByMe,
  });

  factory Notice.fromMap(Map<String, dynamic> map) {
    return Notice(
      id: map['id'] as String,
      userId: map['user_id'] as String,
      departmentId: map['department_id'] as String,
      content: map['content'] as String,
      createdAt: DateTime.parse(map['created_at'] as String),
      username: map['users']['username'] as String? ?? 'Unknown',
      profileImageUrl: map['users']['profile_image_url'] as String?,
      likeCount: (map['like_count'] as List).isNotEmpty
          ? (map['like_count'][0]['count'] as int?) ?? 0
          : 0,
      commentCount: (map['comment_count'] as List).isNotEmpty
          ? (map['comment_count'][0]['count'] as int?) ?? 0
          : 0,
      likedByMe: map['liked_by_me'] as bool,
    );
  }
}
