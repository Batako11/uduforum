import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';

import 'post_model.dart';

class PostAdapter extends TypeAdapter<Post> {
  @override
  final int typeId = 1;

  @override
  Post read(BinaryReader reader) {
    final jsonStr = reader.readString();
    try {
      final map = json.decode(jsonStr) as Map<String, dynamic>;
      return Post.fromMap(map);
    } catch (e) {
      // Fallback: empty minimal post to avoid crashes
      return Post(
        id: 'unknown',
        userId: 'unknown',
        content: '',
        createdAt: DateTime.now(),
        pollVotes: [],
        pollVoteCounts: {},
        isBoosted: false,
        username: 'Unknown',
        handle: '@unknown',
        level: 1,
        likeCount: 0,
        commentCount: 0,
        repostCount: 0,
        likedByMe: false,
        blueTick: false,
        goldTick: false,
        repostedByMe: false,
        isTrending: false,
      );
    }
  }

  @override
  void write(BinaryWriter writer, Post obj) {
    final map = obj.toMap();
    final jsonStr = json.encode(map);
    writer.writeString(jsonStr);
  }
}
