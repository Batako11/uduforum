class MaterialModel {
  final String id;
  final String faculty;
  final String department;
  final int level;
  final String courseCode;
  final String? courseTitle;
  final String title;
  final String type; // handout, past_question, slides, textbook, assignment
  final String fileUrl;
  final String fileName;
  final int? fileSizeKb;
  final String uploaderId;
  final String uploaderName;
  final String? uploaderAvatar;
  final int downloadsCount;
  final int bookmarksCount;
  final DateTime createdAt;

  MaterialModel({
    required this.id,
    required this.faculty,
    required this.department,
    required this.level,
    required this.courseCode,
    this.courseTitle,
    required this.title,
    required this.type,
    required this.fileUrl,
    required this.fileName,
    this.fileSizeKb,
    required this.uploaderId,
    required this.uploaderName,
    this.uploaderAvatar,
    this.downloadsCount = 0,
    this.bookmarksCount = 0,
    required this.createdAt,
  });

  factory MaterialModel.fromMap(Map<String, dynamic> map) {
    return MaterialModel(
      id: map['id'],
      faculty: map['faculty'],
      department: map['department'],
      level: map['level'],
      courseCode: map['course_code'],
      courseTitle: map['course_title'],
      title: map['title'],
      type: map['type'],
      fileUrl: map['file_url'],
      fileName: map['file_name'],
      fileSizeKb: map['file_size_kb'],
      uploaderId: map['uploader_id'],
      uploaderName: map['uploader_name'],
      uploaderAvatar: map['uploader_avatar'],
      downloadsCount: map['downloads_count'] ?? 0,
      bookmarksCount: map['bookmarks_count'] ?? 0,
      createdAt: DateTime.parse(map['created_at']),
    );
  }
}
